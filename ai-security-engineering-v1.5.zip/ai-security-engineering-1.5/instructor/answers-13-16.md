# Instructor Answers: Modules 13–16

Use this key to assess explanations and evidence, not to award a production-security credential. Modules use isolated synthetic mechanisms. Accept equivalent implementations when assumptions, denominators, and negative tests are explicit. Never substitute the expected observations below for a learner's actual logs.

## Module 13: Model Privacy and Extraction

### Quiz answers and reasoning

1. **Model extraction, specifically functional approximation.** Reproducing labels concerns decision behavior. It does not establish weight recovery, membership knowledge, or reconstruction of training examples. Require the learner to name the evaluation distribution and query budget before accepting an agreement claim.
2. **False positives can outnumber true positives.** Precision depends on membership prevalence as well as sensitivity and false-positive rate. In the chapter's hypothetical example, the true-positive mass is `0.01*0.8=0.008`; false-positive mass is `0.99*0.1=0.099`. Their ratio yields approximately 7.5 percent precision. This is a calculated hypothetical, not an observed attack performance.
3. **Investigate alternative channels and training origin.** Check retrieval traces, prompt contents, caches, tool outputs, public availability, and synthetic source lineage. Disappearance after disabling retrieval supports a retrieval-mediated explanation. It does not prove that weights never memorized the sequence, but it does not support attributing the observed leak to memorization alone.
4. **Labels still reveal decision boundaries.** Bisection or substitute learning can exploit them. Removing probabilities defeats the exact two-equation example, not all extraction. Cost, architecture knowledge, input access, and deployment controls determine the remaining exposure.

### Lab reasoning and assessment

The logistic example yields coefficients 4 and -1 within floating-point tolerance because its family and exact scores are stipulated. The decision threshold is 0.25. Eight bisection queries narrow a valid starting interval to width `1/256`; tie handling affects endpoint placement. Do not award credit for claiming slope recovery from label queries.

At membership threshold 0.70, there are two true positives, two false negatives, one false positive, and three true negatives. Sensitivity is 0.5, specificity 0.75, and precision `2/3`. These are hand-derived fixture counts. Changing thresholds on the same fixture explores a tradeoff but is not independent validation. A holdout reused for tuning is no longer a holdout.

The dictionary canary is explicit lookup leakage. Suppression demonstrates an application output control, not private training or machine unlearning. Require invalid-logit rejection, unknown-key behavior, a high-confidence nonmember, benign utility, and a failed bisection precondition. The mastery gate fails if a learner treats a threshold score as proof of membership or calls a lookup fixture an LLM extraction experiment.

## Module 14: Adversarial Machine Learning

### Quiz answers and reasoning

1. **Evasion changes inference inputs; training poisoning changes what is learned.** In the toy evasion test the centers stay fixed. In the poisoning tests retraining changes centers. Some attacks combine both stages, but the capabilities should be stated separately.
2. **Ordinary validation may never activate the trigger.** A conditional malicious behavior can coexist with correct unmarked predictions. Two clean cases therefore cannot certify absence of a backdoor. A trigger-dependent behavior also needs comparison against the clean-trained model on the same marked input.
3. **No.** A malicious retrieved record can alter runtime context while weights remain unchanged. That is knowledge/corpus poisoning. Reusing the record in fine-tuning introduces a separate training-data path. Instruction manipulation may additionally constitute prompt injection.
4. **A norm budget alone does not preserve meaning.** A changed measurement, label-defining feature, or categorical value might change the true task rather than cause a valid adversarial error. The chapter stipulates a latent label independent of the editable proxy within a small range; production domains need a defensible constraint model.

### Lab reasoning and assessment

Clean centers are `(0.15, 0)` and `(0.85, 0)`, with a boundary at 0.50 on the unmarked axis. Moving 0.45 to 0.55 crosses it under the stated 0.10 budget. Floating-point comparisons need tolerance. The distant point 0.15 does not cross under the same positive change.

Ordinary poisoning adds three mislabeled points. The class-1 proxy center becomes `(0.8+0.9+3*0.15)/5=0.43`, shifting the boundary to 0.29. Thus the stipulated class-0 point at 0.35 changes prediction. Three of seven training rows are altered additions; this is an unusually large toy capability, not a realistic prevalence estimate.

For the separate backdoor dataset the centers are `(0.15, 0)` and `(0.50, 0.50)`. The clean evaluation points retain labels 0 and 1. At `(0.15, 1)`, distance to class 0 is 1, while squared distance to class 1 is `0.35**2+0.5**2`, so the marked point predicts class 1. The clean-trained model still chooses class 0 on that same input. Marker 0.1 is an important irrelevant-trigger check, not proof that all other markers are safe.

For RAG, accepted newest-record selection changes evidence without retraining. Filtering the unapproved record tests a policy fixture; approval does not prove the fact's truth. Reject claims that these centroid exercises replicate gradient attacks, neural training dynamics, or realistic stealthy poisoning. Require separate clean and targeted outcome counts and evidence that the interventions were not accidentally compounded.

## Module 15: Secure MLOps and the Model Supply Chain

### Quiz answers and reasoning

1. **An attacker can replace both artifact and checksum.** Identity must be compared with an expectation controlled outside the candidate's authority. A digest alone establishes neither authorship nor approval.
2. **Loading can execute reconstruction code.** The risk arises before inference and before a prediction-based evaluation gate. The optional harmless callback illustrates that boundary without shell, filesystem, or network effects. It is not necessary to load a suspicious real artifact to establish the risk.
3. **No.** Valid provenance authenticates claims about origin or production under specified trust assumptions. It can describe a compromised builder, poisoned dataset, or backdoored artifact accurately. Behavioral testing and execution isolation are separate controls.
4. **Serving should not approve or publish releases or hold training/deployment administration credentials.** It normally needs read access to approved artifacts and narrowly scoped operational permissions. Exact privileges depend on architecture; assess separation of authority rather than one product's role names.

### Lab reasoning and assessment

The clean JSON loads to `(1.0, 2.0)`. Any byte change changes the digest expectation unless the independent approval set is also changed through an authorized release process. Recomputing an adjacent checksum does not authorize the modified file. Locally pin malformed fixtures only to reach parser negative tests; this must not be presented as approving malformed production releases.

Require strict format and field checks, two floating-point weights, finite numeric bounds, and byte-size enforcement. Test booleans explicitly because Python treats them as integer subclasses. The artifact contract intentionally excludes integers; that is a design choice, not a universal model-format requirement.

Gate tests must reject an unexpected builder, missing evaluation identifier, mismatched artifact binding, and absent approval. A failed gate cannot mutate the active serving identity. Rollback requires a known prior approved release, not merely a mutable tag. Require the learner to distinguish local metadata labels from authenticated attestations and acknowledge that the toy gate provides no production registry, identity provider, or signing infrastructure.

## Module 16: Evaluation Design and Statistics

### Quiz answers and reasoning

1. **Pairing controls case mix.** Compare the same case IDs and expected outcomes under both versions. A difference between unrelated case sets may reflect difficulty instead of the fix. Pairing does not remove scorer bias, leakage, or environmental differences.
2. **Repeated outputs share cases and often mechanisms.** Treating every row as an independent draw exaggerates coverage and can underestimate uncertainty. Resample whole paired cases, or template/document clusters when those are the independent units. More repeats estimate variability for existing cases, not diversity of new attacks.
3. **It establishes zero observed events under the tested conditions.** Under independent identical Bernoulli trials, the one-sided 95 percent upper bound is `1-0.05**(1/100)`, approximately 0.0295. It does not prove zero probability, cover unseen categories, or justify treating correlated repeats as independent trials.
4. **Blocking everything reduces harmful completions but destroys utility.** Benign false-positive rate, task completion, latency, and availability make the tradeoff visible. Also distinguish harmful proposals from harmful executions when an authorization layer intervenes.

### Lab reasoning and assessment

The simulator probabilities are author-selected inputs. They must never appear as measured defense performance. Shared uniforms impose a particular synthetic coupling. Different empirical seeds can change counts; accept any reproducible run whose calculations match its records.

Calculate paired differences as baseline minus fix for attack events. Preserve whole case pairs during bootstrapping and disclose the small five-case category sample. Do not manufacture a universal threshold for statistical significance. A narrow interval can coexist with poor threat coverage, scorer errors, selection bias, or model drift. Wilson intervals in the teaching step use one designated trial per case; treating all repeats as independent requires an additional justified model.

Require rejection of zero denominators, invalid event counts, missing pairs, and duplicate rows. Shuffling rows must not alter results. All-block controls must expose benign harm. Check that holdout outcomes were not used to tune the fix and that unknown categories were retained for investigation. A limitations paragraph is a required part of passing, not optional humility.

## General grading rule

Use reproducible calculations, correct causal distinctions, and demonstrated negative tests as the standard. A learner passes these modules by showing bounded applied competence, not by claiming comprehensive model privacy, universal adversarial robustness, safe artifacts, or statistically proven production security.
