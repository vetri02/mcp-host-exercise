# Instructor answers: Modules 21-24

Use after attempting the questions and labs. These are reasoning guides, not exact wording to memorize. Accept equivalent answers that identify the mechanism, the authoritative boundary, and the evidence. These four modules involve a real local model, so a learner's numbers will differ from any example; grade the measurement design and the separation of claims, not the rate.

## Module 21

1. Proposal-steered rate is a property of the model under one prompt, temperature, and case set; unauthorized-execution rate is a property of the executor and must be zero regardless of the model. Conflating them either blames the model for a gateway bug or credits the gateway with model robustness. Reporting both shows where a fix belongs.
2. It supports the claim that the prompt change lowered the steering rate on this case set, for this model, within the reported interval. It does not support any claim about a bound: the attacker chooses the next case, and a prompt is text the model may weigh or ignore. The executor's denial remains the only security property.
3. Repeats of the same case share everything except sampling noise; they estimate variance for that case, not coverage of the attack space. Thirty cases are the independent units; the cluster bootstrap in Module 16 resamples cases with their repeats attached for this reason.
4. Nothing quantitative. A local four-billion-parameter model and a hosted frontier model differ in training, safety tuning, and tooling. The learner may claim that the executor's behavior is model-independent, since that was tested with both a fake and a real model, and may state the local rate as a documented observation with its metadata.

Lab grading: the frozen plan must predate the runs; parse failures and timeouts appear as outcome categories; the held-out set is reported once. A submission with no model available passes with the deterministic run and the explicit "generative evaluation not performed" label. Any unauthorized execution reported as a model result rather than a defect fails.

## Module 22

1. The harness parses the file as configuration and executes what it names (hooks, servers, tasks), and the model reads the same bytes as text that can steer it. The executing reading is the dangerous one because it runs before any trust decision and with the user's local privileges; the steering reading needs a later action to cause harm.
2. Any observable external effect is a sink. A DNS query carries attacker-chosen bytes in its labels to a server the attacker names; the allowlist judged the command by its purpose instead of by its side effects. The same error would allowlist a command that writes a log file to a synced folder.
3. Separating the triage job's reach from the release pipeline: read-only repository access, no cache write, and no publishing credential on the runner that processes untrusted issue text. A fully steered model in that job could still only produce a wrong label. Accept answers that name not interpolating untrusted input into the prompt as a contributing fix, but it is a filter, not the boundary.
4. A category approval ("run shell commands," "edit files in this repo") is a standing capability whose scope the user did not review; the 2025 skills research showed a benign approval carrying to a harmful related action. Binding to exact action identity makes each consequential action a separate decision the page or file cannot pre-satisfy.

Lab grading: the surface inventory names the agent version and distinguishes "read as text" from "executed"; the scanner has a negative test for ordinary non-ASCII; the triage harness has no shell; the credential-reach table shows the publishing credential unreachable from the triage job. A scanner whose silence is reported as safety fails.

## Module 23

1. The agent runs in a browser profile that already holds authenticated sessions (private data), reads arbitrary pages (untrusted content), and can submit forms or navigate to any origin (channel out). All three legs exist before the first action; the task does not add them, it only chooses which page is read first.
2. A separate agentic profile removes the private-data leg for everything outside the task. Request-action consistency and origin allowlists remove or narrow the channel out and bound actions to the request's classes. Confirmation on sensitive classes inserts a human on the remaining consequential actions. None of the four removes the untrusted-content leg: the page must be read to do the task, so steering remains possible and must be measured, not assumed away.
3. A screenshot contains everything rendered, including text no DOM filter sees: low-contrast text, images of text, tooltips, alt text. The model decodes it all. A text pipeline can at least enumerate elements; a pixel pipeline has one undifferentiated input. Screenshots also sample the page at one moment, so what was seen and what is clicked can differ.
4. It describes one product, one date, one suite of attack cases the vendor assembled, after that vendor's mitigations, and the vendor said the number was not acceptable for autonomous use. The decision it supports is that structural controls (profile separation, confirmation, origin policy) must carry the security, with the model's steering rate treated as a measured residual that could be worse on other cases.

Lab grading: hostile and benign pages are paired by shape; the policy tests deny every hostile carrier with no model involved; the quoted-discussion page completes; the screenshot variant identifies which carriers text controls missed. A harness whose only defense is a prompt or a classifier fails.

## Module 24

1. Mechanically it is a tool result appended to the receiver's context; the receiver's model has no way to distinguish a peer's genuine summary from text the peer was steered into emitting. Authentication of the peer proves which component spoke, not that what it says is safe to obey. An agent that read a hostile document becomes a hostile source with a trusted voice.
2. Authority must attenuate: each hop receives a capability scoped to its task, never the caller's ambient credential, and its outputs return as data. The usual violation is credential forwarding (token passthrough across hops) and letting a sub-agent inherit the orchestrator's tools, which gives the least-reviewed component the widest reach; the 2026 protocol analysis also found context identifiers unbound to a client and capability claims nothing attested.
3. Defense in depth requires independent failure modes. A second prompt to the same or a similar model shares training, hallucination patterns, and susceptibility to the same injected text; if the first was steered, the second is likely steered by the same content. A deterministic verifier, a retrieval of the cited source, or a human check does not share the failure.
4. A single loop has one budget it spends. A multi-agent system has a tree: budgets must be divided and passed down, a child may never report more remaining than it received, depth and fan-out are themselves resources, and a cycle is a budget attack. A hostile sub-agent can keep an orchestrator working indefinitely unless the parent's budget, not the child's cooperation, ends the task.

Lab grading: the budget trace shows monotone decrease down the tree; attenuation tests cover tool, ticket, budget inflation, and cycle; the infection table has per-hop denominators; the protocol review answers the four questions (principal, credential, reach, hostile peer) for a named protocol. Sub-agents inheriting the orchestrator's full credential fails.

## Scoring guidance

Across these modules the learner must keep three numbers apart: how often the model was steered, how often any hop or policy let a steered proposal through, and how often an unauthorized effect occurred. The third must be zero and is a defect otherwise. The first is reported with metadata and intervals. The second is the learner's own control working or not. Full credit requires all three stated separately with denominators; a single "attack success rate" without saying which of the three it measures earns at most half.
