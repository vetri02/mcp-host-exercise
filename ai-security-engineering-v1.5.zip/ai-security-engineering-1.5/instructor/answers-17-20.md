# Instructor Answers and Assessment Guidance: Modules 17-20

These notes explain reasoning, not only expected labels. Learners assess an isolated, deterministic Python authorization simulation. No supplied model adapter, actual MCP transport, service endpoint, cloud environment, real email delivery, or production authentication should be assumed. See the [reference contract](../reference-lab/CONTRACT.md). Evaluate truthfulness and reproducibility alongside technical correctness.

The answers below cover the baseline quizzes. Accept alternative implementations when they preserve the stated invariants, demonstrate meaningful positive and negative controls, and disclose remaining uncertainty. Do not reward a polished report that cannot identify the exact tested baseline.

## Module 17

[Chapter](../modules/17-automated-red-teaming.md)

### Quiz answers

1. A deny-all target preserves some denial outcomes by destroying legitimate functionality. Owned reads and independently approved writes are positive controls. Security assessment must check permitted behavior as well as prohibited behavior; a denial fraction without a case catalogue can conceal a broken system.
2. Replay prevention concerns reuse of a previously valid authorization. If the first operation failed because the token was invalid, the second denial tells us nothing about single-use enforcement. The successful first call and denied second call must share state. Resetting between those calls invalidates the experiment.
3. A scorer may judge refusal language while the application has already performed an unauthorized side effect. It may also flag harmless quotations or misclassify ambiguous output. The invariant oracle inspects authorization outcomes and state; a response scorer evaluates a different observable. Preserve both and investigate disagreement.
4. Count target inference, attack generation, scoring, multi-turn continuation, retries, and uncertain timeout reservations. Include input and output tokens, concurrency, elapsed time, and current provider prices. In the illustrative six-objective plan, 24 target plus 24 judge plus 12 generation calls equals 60 calls before retries. Local inference still consumes finite compute.

### Lab observations and marking

The baseline campaign emits six JSONL records. `read-owned` and `write-approved` allow. `read-foreign`, `write-unapproved`, `reader-write`, and `approval-replay` deny. These are expected fixture outcomes, not observed performance claims for a production product. An unexpected exception must stop or explicitly invalidate the campaign rather than becoming a defensive success.

Require case identifiers, expected and actual observations, positive controls, side-effect checks, baseline metadata, and coverage gaps. Unknown tool and caller-supplied tenant cases should reject. Accept distinct validation and authorization categories; encourage retaining reason codes for diagnosis.

The oracle mutation must create a mismatch. A deny-all test double must fail permitted-use controls. Argument-binding and expiry evidence must name real supplied tests or transparently identify a gap. Timing sleeps do not establish robust distributed expiry behavior. Mastery fails if the learner calls these LLM attack-success rates or claims a framework adapter exists when it was not implemented.

## Module 18

[Chapter](../modules/18-detection-and-incident-response.md)

### Quiz answers

1. Denials show attempted operations rejected by the observed control. A burst could result from malicious exploration, a broken client, or confusing user experience. Confirmed leakage needs evidence of unauthorized data returned or otherwise exposed. An alert is a triage signal, not the incident conclusion.
2. Integrity means evidence matches a retained baseline or authenticated record. Authenticity concerns who produced it and whether that source was trusted. A plain digest alone proves neither source identity nor truth. Replacing both an event and an unprotected digest defeats that comparison.
3. With no expected final sequence number or heartbeat, the detector does not know another record should exist. Interior deletion can reveal a gap; tail truncation cannot. A separately trusted endpoint, source checkpoint, or monitored heartbeat is needed to support that claim.
4. Restore writes only after a corrected control passes targeted negative and legitimate-use regressions, required logging works, affected approval state is handled, and an accountable reviewer accepts residual risk. Merely restarting or receiving a refusal message is not sufficient.

### Lab observations and marking

The ordered fixture produces `deny_burst` at E5, `approval_replay` at E7, and `cross_tenant_allow` at E8. There are no baseline sequence gaps. Bob's event is a separate tenant/actor window. Appending the identical E5 record does not alter the result. Removing E6 creates a gap between 5 and 7. E8 is explicitly injected synthetic detector input, not an exploited service.

Require benign controls, window-boundary tests, duplicate handling, gap/truncation discussion, schema validation, and bounded memory. Out-of-order input exposes the example's assumption; a learner must not report reliable real-time detection from it. Conflicting duplicate payloads need explicit handling in an improved design.

The runbook should preserve originals, constrain affected workflow, distinguish suspicion from established impact, and describe recovery criteria. Simulated containment must remain local or documentary. No production revocation or email is part of this exercise. Logging failure should have a risk-based policy, not an unconditional availability slogan.

## Module 19

[Chapter](../modules/19-cloud-governance-and-risk.md)

### Quiz answers

1. A workload identity authorizes the application to use infrastructure, while end-user context determines which user's resources and actions are permitted. Broad workload access cannot override tenant boundaries. Control-plane and runtime permissions also require separation to limit compromise.
2. A passed control has relevant inspected and tested evidence for the declared scope. Unknown means the evidence is missing or inconclusive. Nonapplicability needs a documented reason linked to the actual architecture and use. A provider-retention question may be inapplicable locally yet critical for a proposed provider extension.
3. AISVS provides verifiable technical security requirements. NIST AI RMF organizes governance and risk management through GOVERN, MAP, MEASURE, and MANAGE. They complement each other, but neither classroom mapping establishes legal compliance or issues a certificate.
4. The function checks declared critical evidence states, not whether those states are truthful, complete, or adequate. An authorized reviewer must still evaluate applicability, residual risks, evidence freshness, operating safeguards, and release scope. REVIEW deliberately prevents automatic deployment approval.

### Lab observations and marking

Owned approved retrieval succeeds; foreign, missing-identity, and missing-workload-permission requests fail. Unapproved documents and unauthorized roles reject. A literal wildcard is not recognized by the miniature policy, but actual platform wildcard behavior remains untested. The proposed migration returns NO_GO because supplier-retention evidence is unknown.

A missing record must be detected through a required-control catalogue; the sample function alone cannot discover a removed item. Insist on an inventory separating implemented, simulated, and proposed components, five accountable risk records, and a bounded release decision. Critical isolation and approval failures must not disappear inside a generic exception.

The public AISVS project page and repository showed different stable-version descriptions at authoring. Learners should preserve their chosen release artifact and exact text when mapping requirements. Do not require invented identifiers, draft-to-stable equivalence, or a claim that every chapter has been verified.

## Module 20

[Chapter](../modules/20-assessment-and-portfolio.md)

### Quiz answers

1. Connect the scoped requirement, inspected implementation, and reproducible observations, including positive and negative tests. Preserve baseline, method, expected result, actual result, evidence location, and limitations. No single code comment, screenshot, or scanner summary provides that complete argument.
2. The campaign labels are supplied data. Editing expected and observed together can make a broken invariant appear consistent. Review against the independent case catalogue and actual state transition is essential. The evidence checker is intentionally not a full security oracle.
3. An untested critical production dependency remains a no-go for the release that depends on it. A restricted synthetic demonstration might still be reviewable if its scope does not use that dependency. Document the distinction, reviewer, compensating constraints, and revisit condition.
4. Claim deterministic authorization testing, synthetic detection exercises, governance review, and assessment documentation that you actually performed. Disclose fixture authentication, in-memory approvals, lexical retrieval, and absent model/network/cloud/MCP integration. Do not imply real-model robustness, production assurance, client experience, or certification.

### Lab observations and marking

Complete files and matching unique baseline cases lead to HUMAN_REVIEW_REQUIRED, never automatic release. Missing outputs, duplicate case identifiers, mismatches, or malformed campaign JSON produce blockers. Byte changes alter digests but do not establish malicious tampering. Detection and governance outputs still require semantic review.

Require all five local claim mappings, original/retest separation, two honestly labeled findings, exact reproduction instructions, and a defensible release boundary. An assurance gap is a legitimate finding when its consequence and closure evidence are specific. Penalize concealed unknowns and fabricated achievements more heavily than an honestly documented blocked test.

## Pacing and final review

For each ten-hour week, spend two hours discussing principles, five running and extending the safe lab, two evaluating cases and peer reproduction, and one writing conclusions. The five practice hours include test design, failure analysis, fixture expansion, and evidence handling, not five hours of unattended scanning.

The final reviewer should ask: What was tested? What was not? What evidence could falsify the conclusion? Who accepts the remaining risk? Which conditions prohibit release? A learner passes by making those answers reproducible and proportionate, not by collecting the largest tool output or claiming perfect security.
