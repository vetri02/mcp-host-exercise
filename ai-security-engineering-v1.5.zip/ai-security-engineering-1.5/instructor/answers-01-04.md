# Instructor answers: Modules 01-04

Use after attempting the questions and labs. These are reasoning guides, not exact wording to memorize. Accept equivalent answers that identify the mechanism, authoritative boundary, and evidence. A learner who gives only a keyword needs a follow-up question.

## Module 01

1. A body field is controlled by the request sender. It can name another user without proving control of that identity. Authentication middleware must derive a principal from a validated session or token, and application policy must evaluate that principal. Header names alone are also insufficient without a trusted proxy boundary.
2. The test fails. The security invariant concerns the protected effect, not a response string. Inspect row values, versions, outbox entries, files, or other authoritative state. A denial printed after a write is not prevention.
3. Confidential content crosses from the data store into the model's processing context. That may also cross an organizational boundary if the model is hosted by a provider. Filtering the final user-visible answer does not undo that exposure.
4. The evaluator reproduces a known synthetic broken-authorization behavior and demonstrates specific deterministic checks in the defended simulator. It does not measure real LLM behavior, prompt resistance, production authentication, infrastructure isolation, or universal security.

Lab grading: verify commands run in the correct directory; new tests check state; the learner names missing production components; and the intentional vulnerable fixture is isolated. Ask what would change if a tool result were cached between tenants.

## Module 02

1. Object-level authorization decides whether a caller may access a particular resource; function-level authorization decides whether the caller may invoke an operation. Both are required. A role that permits reading support records does not permit every tenant's record, and tenant membership does not grant every operation.
2. Read-only accounts can disclose sensitive information. They prevent modifications but do not necessarily restrict rows, objects, schemas, exports, or metadata. Data confidentiality depends on scoped access, not only write protection.
3. Derive identity at a trusted authentication boundary from a verified session or appropriately validated access token. Preserve the initiating user's authority through service calls. Do not derive role or tenant from model output or caller-controlled fields.
4. Approval is supplemental to valid authorization. A supervisor must not approve an action outside the actor's tenant or role. Re-evaluate live policy and relevant resource state at execution; approval cannot turn forbidden access into permitted access.

Lab grading: the matrix includes role and tenant separately; foreign and nonexistent records share a generic response; direct tool calls are tested; approvals do not override ownership; and denied writes preserve versions and outbox length. Discuss timing side channels separately rather than claiming the generic message solves them all.

## Module 03

1. Fine-tuning changes model parameters through training. RAG adds retrieved material during inference without necessarily changing weights. Training poisoning and retrieval poisoning differ in attacker capabilities, persistence, mitigation, and removal. Deleting a retrieved file does not erase information learned during training.
2. Similarity ranks related content. It does not certify factual truth, trustworthy authorship, current permission, or safe instructions. Eligibility and provenance decisions need independent controls before content is supplied to the model.
3. A fake-model test deterministically produces a chosen proposal, allowing the executor's invariant to be tested without model randomness. A live-model test studies how often risky proposals occur and how useful outputs remain. It cannot replace direct authorization tests, and a fake model cannot measure injection resistance.
4. Self-hosting changes provider and infrastructure boundaries. It does not prevent malicious retrieved instructions, broad tool credentials, cross-tenant access, unsafe model artifacts, or resource abuse. Local and hosted designs need threat-specific controls.
5. Memorisation of a secret is introduced at pretraining (stage 4) on whatever survived data filtering (stage 1); obeying instruction-shaped text is learned at pretraining and then strengthened by supervised fine-tuning (stage 5), which teaches the assistant format; refusal is introduced by preference and reinforcement training (stage 6). None creates a trusted channel because every stage adjusts parameters so that the model continues token sequences; role markers are tokens or learned delimiters, attention mixes all positions, and the serving layer applies the same weights to every request. Trust is a property of the application layer (stage 8), which must derive the principal from the session and authorise each proposed action.
6. The assertion shows that the model's prediction depends only on the tokens it conditions on, not on who supplied them: the "user:" and "tool:" prefixes are earlier tokens with no special status, so the conditional distribution after "ignore" is identical. For it to fail, the architecture would need a per-token provenance input that changes the computation, for example a trust tag embedded alongside each token and used by attention, trained so that low-trust spans cannot act as instructions. No deployed transformer has such an input; research prototypes that approximate it are learned tendencies, so the course keeps authorisation outside the model. Changing the prompt cannot make the assertion fail because the prompt is more tokens.

Lab grading: the orchestrator clearly separates retrieval, proposal, validation, execution, and trace; foreign context is absent; malicious fake proposals are denied; and model/provider access not performed is marked not tested. Do not award credit for simulated outputs described as real-model results.

## Module 04

1. The attacker then controls a trusted authorization source, not merely chat or document input. That is an administrator/control-plane compromise scenario. It may be a valid threat, but findings must state the stronger precondition and not attribute the result solely to prompt injection.
2. Injection may cause an unwanted model proposal that the executor rejects. That is model steering without the tested unauthorized effect. There may still be safety, availability, or answer-integrity harm, which needs its own oracle and report.
3. Correct permissions can still allow false or misleading information to influence a permitted business decision. Other risks include availability, cost, unsafe rendering, provider exposure, and trusted-component compromise. Authorization is necessary but not the entire defense.
4. A useful threat model maps actual assets, attacker capabilities, flows, boundaries, control owners, executable tests, and residual risk. It changes with architecture and supports explicit release/no-go criteria. An unprioritized attack-name list does not support a defensible decision.

Lab grading: eight causal threat records; three executable or exact test procedures; one direct-executor test; one unchanged-state denial; one legitimate-task control; and explicit residual risk. A diagram without identity, credential, or effect boundaries is incomplete.

## Scoring guidance

For each quiz answer, score 0 for incorrect or missing, 1 for a correct label without explanation, 2 for a sound mechanism, and 3 for mechanism plus control/evidence and limitations. Four questions yield twelve points per module. A suggested quiz pass is ten of twelve, but every practical mastery gate must also pass.

When learners disagree with the reference design, ask them to state a policy, show a counterexample, and provide tests. Security reasoning is not agreement with an instructor. A different architecture can be valid if its assumptions, threat scope, and evidence are clear.
