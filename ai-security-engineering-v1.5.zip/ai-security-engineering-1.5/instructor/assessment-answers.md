# Instructor key: diagnostic and final exam

Attempt assessments first. These notes emphasize causal reasoning and evidence; equivalent defensible designs are acceptable. Do not award points for unsupported production guarantees or fabricated measurements.

## Diagnostic

1. Equality compares values according to an object's behavior; identity checks whether two references point to the same object. Neither authenticates a remote caller. The reference fixture uses identity only as a local teaching guard.
2. An annotation documents expected types and supports tooling, but ordinary Python does not enforce it automatically. Validate untrusted inputs at runtime.
3. Authentication establishes a subject; authorization determines whether that subject may perform an action on a resource under current policy.
4. The caller can choose the field. Derive tenant from trusted identity/authorization context, not request data or model output.
5. Parameters bind data separately from SQL syntax, reducing injection for values. They do not authorize rows, validate arbitrary identifiers, or make arbitrary generated SQL safe.
6. Inspect actual protected state: row values/version, outbox, files, or other effect records. A denied message is not sufficient.
7. Read-only permissions may still expose all tenants, metadata, or sensitive columns. Scope confidentiality separately from write protection.
8. RAG supplies retrieved context during inference; fine-tuning changes weights through training. Attack surface, persistence, and removal differ.
9. A hash compares bytes to an expected value. Without independent control of that expectation, it is weak evidence; even a trusted match does not prove authorship or truth.
10. The sample is finite and scope-limited, may be biased or dependent, and cannot cover all attacks. Under justified independent-trial assumptions a bound may be estimated, not zero universal risk.

Practical tasks pass when malformed input is rejected without mutation, tenant scope is authoritative, denied writes preserve state, and a deliberate regression is observed and restored in version control. Vocabulary alone is insufficient.

## Final exam 1: poisoned policy

The candidate may have supplied or replaced its own expected hash; alternatively, a trusted publisher may have approved false content. Integrity is not authority or truth. The executor must independently enforce export permissions and scope, regardless of retrieved claims. Measure malicious-document selection, proposal steering, backend execution, and data exposure as distinct outcomes. Test both rejected unauthorized export and legitimate own-tenant tasks. Mention ingestion review, provenance, freshness, and residual answer-integrity risks.

## Final exam 2: changing action

Bind approval to actor, tenant, tool, normalized/detached arguments, resource identity and relevant version, expiry, and use count. Recheck live authorization and resource state at execution. Consume approval atomically with an appropriate transactional/idempotent effect design. Reject altered details and stale version; assert unchanged status/version and outbox. Snapshot caller-owned data so concurrent changes cannot alter the approved effect. Distributed external effects require more than an in-memory lock; include retry/failure behavior.

## Final exam 3: read-only SQL

Read-only prevents some modifications, not unauthorized reads. Use narrow parameterized operations and authoritative tenant/object filters, constrained views/roles where appropriate, and minimal columns. Avoid arbitrary SQL execution. Directly test foreign identifiers, alternate queries, joins/exports, missing scope, and caller-supplied tenant. Separate syntax injection from authorization. Do not claim a keyword check or read-only transaction solves all generated-SQL risks.

## Final exam 4: MCP confusion

Validate credentials for the intended issuer/audience/resource and reject unrelated tokens. Preserve the initiating user's delegated authority rather than forwarding a broadly privileged credential blindly. Apply application resource policy even after valid authentication. Bind reviewed tool definitions to server identity/version and review changes. Offline token/schema fixtures establish only policy logic; signature validation, transport, issuer discovery, delegation, and downstream acceptance require actual integration tests. No requirement for homegrown OAuth cryptography.

## Final exam 5: safe classifier

The classifier measures a text-level detection criterion, not authorized effects. A legitimate-looking query can still read forbidden rows. Test goals that require crossing user permissions and inspect backend results. Keep classifier filtering as one layer, compare with independent execution policy, and manually validate findings. Include benign tasks and false positives so blocking everything is not scored as success. Fail open/closed behavior needs an explicit policy.

## Final exam 6: private training data

A similar phrase alone is inconclusive: it may be common, retrieved, inferred, or memorized. Membership inference asks whether a specific example was in training and needs calibrated member/nonmember evaluation under stated knowledge. Memorization/extraction of data requires evidence of reproduced protected content and controlled provenance. Model extraction seeks a surrogate of behavior/parameters, usually through query access. Define separate objectives, baselines, splits, and utility/privacy limitations. Formal differential privacy requires its own mechanism/accounting assumptions, not merely low empirical attack success.

## Final exam 7: supply chain

Check identity against independently controlled expectations; an attacker-controlled adjacent checksum is not enough. Verify intended signer/builder and artifact/source binding when actual attestations exist. Use approved safer formats and avoid untrusted deserialization. Require reproducible environment, source/data/model/evaluation versions, scoped identities, behavioral acceptance, and approved rollback artifacts. A signature can authenticate a harmful or compromised build. Labels are not authenticated provenance, and hashes do not assess semantics.

## Final exam 8: zero failures

Report zero observed harmful effects in the specified fifty attempts under the given configuration, with limited category coverage. Forty related variants may be correlated and do not represent forty independent attack families. Define denominators by category and effect; keep deterministic invariant checks separate from model trials. Under independent identically distributed Bernoulli assumptions, a zero-event upper bound can be estimated, but those assumptions may not fit adaptive attacks. Use held-out categories, repeated runs, paired baseline/fix comparisons, utility tests, and explicit uncertainty. Never infer universal 100% security.

## Final exam 9: incident response

Contain high-impact execution, preserve access-controlled redacted evidence, reconcile actual backend effects, identify the originating user/doc/tool/policy versions, and quarantine implicated content or credentials as needed. Missing result evidence is unknown, not proof of no execution. Investigate duplicates/retries and cross-tenant effects. Repair controls, expire affected approvals/memory where justified, validate normal tasks, and add regression cases before recovery. Follow a retention/deletion policy rather than destroying investigative evidence indiscriminately.

## Final exam 10: release

A narrow synthetic scope may pass educational review if its tested boundaries and limitations are explicit. Production should remain no-go where authentication, deployment, export, or critical evidence are untested. Matching labels and complete files need semantic review; hashes only preserve identity relative to a baseline. Name the owner, deadline, required test, acceptance criterion, and residual-risk decision for each gap. Block release on reproduced cross-tenant access, unauthorized writes, approval bypass, credential exposure, or uncontrolled execution. Passing a finite suite is not complete proof.

## Final exam 11: three-agent pipeline

A signature authenticates the sender, not the content. The summariser is honest and still relays the attacker's text, so a valid signature from it says nothing about whether the task carries authority (Module 24: who is the principal at each hop). The control is attenuation: each hop holds at most the capabilities of the hop before it, minus what its task does not need, so an executor acting on a summary of untrusted content holds no credential that can install a package or post to a URL. The budget trace must be monotone across hops. The infection trace must show the instruction's path from README to summary to proposal, marked untrusted at every step, with the proposal denied at the executor by policy rather than by the model's judgement. Test first with fixed messages and no model: the hostile README must produce a denied proposal and no side effect, and a benign README must complete the task. Then repeat with the local model (Module 21), reporting rates over repeated runs with a denominator, and state that the deterministic test proves the boundary while the model run only samples proposal behaviour. Credit the Module 22 point that a cloned repository is executable input and the Module 23 point that a carrier can be ordinary text. Deduct mechanism credit for an answer that keeps the signature and adds a classifier.

## Scoring and feedback

Each final scenario: six points for correct mechanisms and control placement; two for a suitable oracle/reproducible evidence; two for honest scope and limitations. Deduct mechanism credit when the answer substitutes prompting, classifier scores, encryption, or a certificate for authorization. Ask practical follow-ups when written reasoning sounds memorized.

At milestone and capstone review, reward a learner who finds and reports a limitation rather than hiding it. A not-tested label is honest, but does not earn empirical-result credit. Every critical practical gate still requires evidence or a narrower explicit scope.
