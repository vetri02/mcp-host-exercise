"""Reference solutions for the hands-on targets."""
