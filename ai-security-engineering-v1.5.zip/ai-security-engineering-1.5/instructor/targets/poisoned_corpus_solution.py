"""Reference solution for targets/poisoned_corpus. Read it after you have
passed the grader, or after a genuine attempt that stalled.

    python3 -m targets.poisoned_corpus.check --solution instructor.targets.poisoned_corpus_solution
"""
import re

from targets.poisoned_corpus.corpus import digest
from targets.poisoned_corpus.target import Answer, tokens


class HardenedAssistant:
    def __init__(self, manifest):
        self.manifest = manifest        # the reviewer's registry, consulted live
        self.docs = {}                  # (id, version) -> document
        self._rejected = []
        self.cache = {}

    # -- admission ------------------------------------------------------
    def _reason(self, d):
        entry = self.manifest.get(d.get("id"))
        if entry is None:
            return "no manifest entry"
        if entry["tenant"] != d.get("tenant"):
            return "tenant mismatch"
        if entry["version"] != d.get("version"):
            return "version not approved"
        if entry["source"] != d.get("source"):
            return "source mismatch"
        if entry["digest"] != digest(d.get("body", "")):
            return "digest mismatch"
        return None

    def index(self, docs):
        for d in docs:
            try:
                reason = self._reason(d)
            except Exception:
                reason = "malformed document"
            if reason:
                self._rejected.append((d.get("id"), reason))
            else:
                self.docs[(d["id"], d["version"])] = dict(d)
        self.cache.clear()

    def rejected(self):
        return list(self._rejected)

    # -- eligibility, then ranking -------------------------------------
    def _eligible(self, tenant):
        """Re-check against the manifest on every call, so a later
        approval or revocation takes effect without re-indexing."""
        out = []
        for d in self.docs.values():
            if d["tenant"] == tenant and self._reason(d) is None:
                out.append(d)
        return out

    def search(self, tenant, query, k=5):
        q = tokens(query)
        scored = [(len(q & tokens(d["body"])), d["id"], d)
                  for d in self._eligible(tenant)]
        scored.sort(key=lambda t: (-t[0], t[1]))
        return [d for score, _, d in scored[:k] if score]

    def _snapshot(self, tenant):
        return tuple(sorted((d["id"], d["version"], digest(d["body"]))
                            for d in self._eligible(tenant)))

    def answer(self, tenant, question):
        key = (tenant, question, self._snapshot(tenant))
        if key in self.cache:
            return self.cache[key]
        hits = self.search(tenant, question)
        if not hits:
            ans = Answer("No approved source covers this question.", [], None)
        elif "retention" in question.lower():
            m = re.search(r"(\d+) days", hits[0]["body"])
            text = ("%s days" % m.group(1)) if m else hits[0]["body"]
            ans = Answer(text, [hits[0]["id"]], None)
        else:
            ans = Answer(hits[0]["body"], [hits[0]["id"]], None)
        self.cache[key] = ans
        return ans

    def cite(self, doc_id):
        entry = self.manifest.get(doc_id)
        if entry is None:
            return None
        return self.docs.get((doc_id, entry["version"]))

    def revoke(self, doc_id):
        self.manifest.pop(doc_id, None)
        for key in [k for k in self.docs if k[0] == doc_id]:
            del self.docs[key]
        self.cache.clear()


ASSISTANT = HardenedAssistant
