"""Reference solution for targets/model_loader.

    python3 -m targets.model_loader.check --solution instructor.targets.model_loader_solution
"""
import hashlib
import io
import json
import math
import os
import zipfile

EXPECTED_BUILDER = "local-builder-A"
MAX_ARTEFACT_BYTES = 2048
MAX_INFLATED_BYTES = 1 << 20
FORMAT = "toy-linear-v1"


def _reject_constant(value):
    raise ValueError("nonstandard JSON constant %r" % value)


class HardenedLoader:
    def __init__(self, approved):
        self.approved = approved
        self.current_record = None
        self.previous_record = None

    # -- loading --------------------------------------------------------
    def load(self, blob, checksum=None):
        # 1. identity first; the adjacent checksum is ignored on purpose
        if not isinstance(blob, (bytes, bytearray)) or len(blob) > MAX_ARTEFACT_BYTES:
            raise ValueError("invalid artefact size or type")
        if hashlib.sha256(blob).hexdigest() not in self.approved:
            raise ValueError("artefact is not approved")
        # 2. one parser, chosen by policy, never by sniffing the bytes.
        #    pickle is not on the list, so an approved pickle is still refused.
        try:
            obj = json.loads(blob, parse_constant=_reject_constant)
        except (ValueError, UnicodeDecodeError) as e:
            raise ValueError("not a valid JSON artefact: %s" % e)
        # 3. schema, with exact types
        if type(obj) is not dict or set(obj) != {"format", "weights"}:
            raise ValueError("unexpected schema")
        if obj["format"] != FORMAT:
            raise ValueError("unsupported format")
        w = obj["weights"]
        if type(w) is not list or len(w) != 2:
            raise ValueError("expected two weights")
        if any(type(v) is not float or not math.isfinite(v) or abs(v) > 100 for v in w):
            raise ValueError("invalid numeric values")
        return (w[0], w[1])

    # -- archives -------------------------------------------------------
    def extract(self, archive, dest):
        root = os.path.realpath(dest)
        plan = []
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            for info in z.infolist():
                name = info.filename
                if name.startswith(("/", "\\")) or os.path.isabs(name):
                    raise ValueError("absolute member name %r" % name)
                parts = name.replace("\\", "/").split("/")
                if any(p in ("", ".", "..") for p in parts):
                    raise ValueError("unsafe member name %r" % name)
                target = os.path.realpath(os.path.join(root, *parts))
                if os.path.commonpath([root, target]) != root:
                    raise ValueError("member %r escapes the root" % name)
                if info.file_size > MAX_INFLATED_BYTES:
                    raise ValueError("member %r inflates past the limit" % name)
                plan.append((info, target))
            # every check passed; only now write anything
            for info, target in plan:
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with z.open(info) as src, open(target, "wb") as dst:
                    dst.write(src.read(MAX_INFLATED_BYTES + 1)[:MAX_INFLATED_BYTES])
        return [info.filename for info, _ in plan]

    # -- release gate ---------------------------------------------------
    def promote(self, record):
        required = ("digest", "builder", "source_revision", "evaluation_id", "approved")
        if type(record) is not dict or any(not record.get(k) for k in required):
            raise ValueError("release record incomplete")
        if record["digest"] not in self.approved:
            raise ValueError("digest not in the consumer's approved set")
        if record["builder"] != EXPECTED_BUILDER:
            raise ValueError("unexpected builder")
        if record["approved"] is not True:
            raise ValueError("not approved")
        # all checks passed; switch atomically
        self.previous_record, self.current_record = self.current_record, dict(record)

    def current(self):
        return self.current_record["digest"] if self.current_record else None

    def rollback(self):
        if self.previous_record is None:
            raise ValueError("nothing to roll back to")
        self.current_record, self.previous_record = self.previous_record, None


LOADER = HardenedLoader
