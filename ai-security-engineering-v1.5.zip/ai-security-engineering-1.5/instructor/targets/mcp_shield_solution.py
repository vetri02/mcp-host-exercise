"""Reference solution for the MCP shield target. Instructor use.

    python3 -m targets.mcp_shield.check --solution instructor.targets.mcp_shield_solution
"""
import copy
import itertools
import re
from collections import namedtuple

from targets.mcp_shield import servers as srv, tokens

ToolResult = namedtuple("ToolResult", "server tool content trusted followups")
SUBJECT = "user-1"
TYPES = {"string": str, "integer": int, "number": (int, float), "boolean": bool,
         "object": dict, "array": list}


def validate(schema, args):
    """Enough JSON Schema for the pinned tools: object, required, additionalProperties,
    type, maxLength, pattern (anchored at both ends)."""
    if schema.get("type") != "object" or not isinstance(args, dict):
        raise ValueError("arguments must be an object")
    props = schema.get("properties", {})
    for k in schema.get("required", []):
        if k not in args:
            raise ValueError("missing required argument %r" % k)
    if schema.get("additionalProperties") is False:
        extra = set(args) - set(props)
        if extra:
            raise ValueError("undeclared arguments %s" % sorted(extra))
    for k, v in args.items():
        spec = props.get(k)
        if spec is None:
            raise ValueError("undeclared argument %r" % k)
        t = TYPES.get(spec.get("type"))
        if t is None or not isinstance(v, t) or (t is int and isinstance(v, bool)):
            raise ValueError("argument %r has the wrong type" % k)
        if "maxLength" in spec and len(v) > spec["maxLength"]:
            raise ValueError("argument %r too long" % k)
        if "pattern" in spec and not re.fullmatch(spec["pattern"], v):
            raise ValueError("argument %r does not match the declared pattern" % k)


class HardenedHost:
    def __init__(self, servers, pins, signing_key):
        self.servers = servers
        self.pins = pins
        self.signing_key = signing_key
        self._ids = itertools.count(1)
        self._kept = {}        # "server/tool" -> definition
        self._rejected = {}
        self.refresh()

    def _rpc(self, server, method, params, scopes):
        tok = tokens.mint(SUBJECT, server, scopes, ttl=120, key=self.signing_key)
        req = {"jsonrpc": "2.0", "id": next(self._ids), "method": method, "params": params}
        resp = self.servers[server].handle(req, {"authorization": "Bearer " + tok})
        if "error" in resp:
            raise RuntimeError("%s: %s" % (server, resp["error"].get("message")))
        return resp["result"]

    def refresh(self):
        kept, rejected = {}, {}
        for name in self.servers:
            listing = self._rpc(name, "tools/list", {}, scopes=[])
            for t in listing.get("tools", []):
                q = "%s/%s" % (name, t.get("name"))
                pin = self.pins.get(q)
                if pin is None:
                    rejected[q] = "not pinned by the administrator"
                elif srv.digest(t) != pin["digest"]:
                    rejected[q] = "definition changed since it was pinned (digest mismatch)"
                else:
                    kept[q] = copy.deepcopy(t)
        self._kept, self._rejected = kept, rejected

    def tools_for_model(self):
        return [{"name": q, "description": t["description"], "inputSchema": copy.deepcopy(t["inputSchema"])}
                for q, t in sorted(self._kept.items())]

    def rejected(self):
        return dict(self._rejected)

    def call(self, server, tool, arguments):
        q = "%s/%s" % (server, tool)
        if q not in self._kept:
            raise ValueError("%s is not an approved tool: %s" % (q, self._rejected.get(q, "unknown")))
        validate(self._kept[q]["inputSchema"], arguments)
        result = self._rpc(server, "tools/call", {"name": tool, "arguments": copy.deepcopy(arguments)},
                           scopes=self.pins[q]["scopes"])
        content = [c["text"] for c in result.get("content", [])
                   if isinstance(c, dict) and c.get("type") == "text" and isinstance(c.get("text"), str)]
        return ToolResult(server, tool, content, False, [])


HOST = HardenedHost
