# Instructor Answers and Assessment: Modules 05-08

## How to use this key

Assess reasoning and executable evidence, not memorized attack vocabulary. Each module represents ten hours: concepts two, practice five, evaluation two, and writeup one. The reference lab is a deterministic authorization simulator with trusted identity fixtures. It does not test actual LLM behavior, implement MCP transport, execute SQL, or deliver email. SQLite appears only in the learner-built Module 08 extension.

Require positive controls as well as denials. A service that rejects every request is unavailable, not a successful authorized workflow. Check that students record expected outcomes before running tests and distinguish an intended policy denial from an unrelated crash. Use synthetic fixtures throughout. Do not request actual credentials, approval handles, document bodies, or customer data as evidence.

## Module 05: prompt injection

See [the learner chapter](../modules/05-prompt-injection.md).

### Quiz answers and reasoning

1. A document can be authorized evidence without being an authorized instruction source. Read permission lets the caller inspect its content; it does not let its author appoint an administrator, grant tool permissions, or change the authenticated principal. The distinction is about authority, not whether the text sounds trustworthy.
2. At a summary sink, injection may contaminate an answer. At a tool executor, it can attempt a consequential action using the application's privileges. The application must authorize the specific resource and effect independently, even when a model's proposal is fluent and well structured. A proposal reaching a tool does not itself establish that exploitation succeeded.
3. The proposals are fixed fixtures and the gateway is deterministic. Tests demonstrate that these inputs cannot cross the implemented boundary. They say nothing about how often a real model follows adversarial content, whether it leaks information through an answer, or what untested proposals might do. Real-model evaluation requires an adapter, a defined dataset, and an explicit success criterion.
4. A model-provided role would let untrusted output select its own authority. The principal must be supplied by the application's trusted identity path. Even a proposal originating from an otherwise legitimate user must not overwrite that principal.

### Lab assessment and mastery gate

The unsafe function should return Birch's note when its forged fixture supplies Birch's tenant. This is an intentionally unsafe local demonstration, not evidence of a model vulnerability. The protected function should return Cedar's authorized document and reject foreign identifiers, unexpected fields, unknown tools, invalid types, and unauthorized roles.

Accept the legitimate document containing suspicious vocabulary. Reject submissions that solve the exercise with a keyword ban or fabricate a model attack success rate. Require metadata-only decision records, a diagram separating retrieved content from principal identity, and an explicit remaining answer-integrity risk. The gate is conjunctive: both useful authorized behavior and denied unauthorized behavior must hold.

## Module 06: RAG authorization

See [the learner chapter](../modules/06-rag-authorization.md).

### Quiz answers and reasoning

1. The query is caller-controlled content. Allowing it to choose tenant scope would turn an assertion into authority. A trusted session or equivalent verified identity must bind the scope; the fixture principal merely simulates that condition in this course.
2. If global ranking selects only foreign documents, removing them before context construction protects confidentiality but can leave an empty result despite available authorized documents. Selecting eligible candidates first avoids that particular completeness loss. If forbidden content reaches the model before filtering, the confidentiality boundary has already been crossed.
3. A query-only cache can return one tenant's answer to another tenant making the same request. The key must include all permission-relevant context, and cached data must remain eligible when served. In the toy policy, tenant separation is sufficient for scope, but revocation still requires rechecking or reliable invalidation. Richer policies need more than tenant.
4. A citation introduces a document-serving or redirect boundary. An answer can be filtered correctly while its link exposes an unguarded document endpoint. Citation identifiers and document bodies must resolve through current authorization checks, not direct access to a shared store.

### Lab assessment and mastery gate

Expected search identifiers are A1 for Alpha and B1 for Beta. Alpha must not retrieve B1 or unpublished A2. The direct-lookup extension must apply the same publication and tenant predicate. A nonexistent identifier should not disclose whether a foreign record exists.

The unsafe cache should demonstrate a synthetic cross-tenant return after Bob warms it. The repaired cache must separate scopes and reject revoked A1 even if previously cached. Confirm citation lookup shares the resource check. Require the supplied ticket test to deny Alice access to B-200. Passing lexical-search tests does not establish authorization for embeddings, exports, distributed caches, or all production endpoints.

## Module 07: knowledge poisoning

See [the learner chapter](../modules/07-knowledge-poisoning.md).

### Quiz answers and reasoning

1. Poisoning can supply false evidence that the assistant summarizes faithfully. It need not issue instructions or override the task. An incorrect retention statement can change the answer through factual contamination alone. Some documents combine this mechanism with prompt injection, so students should identify each separately.
2. The expected digest must be bound to the intended document version and protected from unauthorized replacement. Comparing a body against an attacker-supplied digest establishes no independent integrity boundary. Byte encoding and version handling must also be consistent between approval and retrieval.
3. Authentication identifies a publisher under a trust assumption; a digest verifies correspondence with approved bytes. An authorized publisher can make a mistake, become compromised, or approve an obsolete claim. Neither property establishes truth. Content review, corroboration, and freshness checks address different risks.
4. Downstream copies may survive source revocation: retrieval indexes, answer caches, summaries, exported artifacts, and existing contexts. Recovery needs an inventory of those derivatives and a way to invalidate or replace them. Removing the source alone cannot undo an action already taken from its content.

### Lab assessment and mastery gate

The original manifest accepts the original document and rejects changed body, tenant, source, or version. A manifest deliberately rewritten for the false note accepts it. That result is expected and must be explained as compromised or mistaken publication authority, not a hash collision.

Require independent fixture approval, rejection of self-approval and forged input approval flags, current-version retrieval, and citation revocation. The incident timeline should identify publication, discovery, revocation, derivative cleanup, and restoration. Claims that dictionary changes implement distributed rollback should fail review. A useful report separately states the demonstrated integrity property and unresolved truth or publisher-authentication questions.

## Module 08: tools and SQL

See [the learner chapter](../modules/08-tool-and-sql-security.md).

### Quiz answers and reasoning

1. Schema validity establishes shape, not permission. A valid request can target a foreign resource or an operation outside the caller's role. The tool gateway must bind identity, authorize resources, validate values, and enforce approval requirements independently of JSON parsing.
2. Otherwise an approval for one operation could be reused with another target or effect. Canonical validated arguments let the system recognize the exact authorized request despite harmless key-order changes. Actor, tenant, expiry, and single-use binding are also necessary; tool-name binding alone is insufficient.
3. Parameter binding prevents supplied values from being interpreted as SQL syntax within the developer-controlled statement. It does not authorize statement structure, table access, tenant selection, or resource consumption. An arbitrary model-generated SELECT can still disclose data even if some values are bound.
4. Single use prevents a token from authorizing multiple executions. Idempotency prevents repeated application attempts from creating multiple effects for the same logical operation. Crashes or retries can require idempotency even when each approval is consumed correctly. Distributed execution needs durable coordination beyond the simulator's single-process behavior.

### Lab assessment and mastery gate

The approved A-100 update succeeds once, then replay fails. Missing or mismatched approvals, foreign resources, reader writes, unknown tools, and unexpected argument fields must fail without changing tickets or the simulated outbox. A different actor must not reuse Alice's approval.

The SQLite extension returns only A-100 for Alpha's open-ticket query and only B-200 for Beta's. The malicious-looking status remains a literal and matches nothing; the function's status allowlist rejects it. Invalid limits must fail, including booleans. `query_only` adds a write restriction but is not a complete arbitrary-SQL sandbox. Require the student to identify trusted tenant binding and the fixed template as the central application controls, and to label proposed authorizers, read-only connections, and resource budgets as extensions rather than supplied features.
