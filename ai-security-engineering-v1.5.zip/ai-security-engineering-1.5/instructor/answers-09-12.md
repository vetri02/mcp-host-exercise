# Instructor Answers and Assessment Notes: Modules 09-12

These answers accompany four ten-hour modules. Grade reasoning and executable evidence, not vocabulary alone. The supplied reference lab is a deterministic Python authorization simulation. It does not implement authentication, a language model, OAuth, MCP transport, networking, production persistence, or an OS sandbox. Learner-built extensions must remain separate and use synthetic, local-only fixtures. Do not request production secrets or external probes as evidence.

## Module 09: Memory, approvals, and workflows

See [Module 09](../modules/09-agent-memory-and-approvals.md).

### Quiz answers

1. **Remembered statements are evidence, not capabilities.** Memory may contain untrusted, stale, misattributed, or summarized text. The execution component must obtain independently established approval for the current operation. An old supervisor statement cannot supply actor, tenant, exact arguments, expiry, and single-use state for a new request. Presentation preferences also cannot override tool policy.
2. **Check current policy and every approval binding.** Validate the authenticated actor, current role and resource authorization, tenant, tool, schema-valid canonical arguments, expiry, independent authorized approver, and unused status. Consume the approval atomically at execution. Token opacity makes guessing harder but does not replace these checks. Unknown tools or extra identity arguments must fail closed.
3. **Binding prevents substitution, not every stale decision.** A token issued for closing A-100 cannot authorize changing its target to B-200 or another status. A mutable record may still change while approval waits. Where the business decision depends on the reviewed record state, bind an expected version and recheck current authorization. The simulator does not supply resource-version binding or distributed transactional execution.
4. **A timeout does not reveal whether the effect occurred.** A downstream service may have committed before its response was lost. Reusing approval can duplicate the effect, while assuming failure can mislead the user. Use an idempotency/reconciliation design that preserves attribution and reports uncertainty. Single-use approval controls consent reuse; it is not an exactly-once delivery guarantee.

### Lab assessment

Require positive memory and update controls, user and tenant isolation, argument reordering, and all binding mutations. Negative requests should leave tickets and outbox unchanged. Students may use documented missing-value behavior for absent memory; do not insist on a particular exception if the implementation returns an empty value.

Expiry tests must exercise the actual clock lookup. Mocking an unrelated clock and obtaining a passing test is not evidence. Concurrency tests must hit the consume path; a sequential replay test alone is not a race test. Accept a clear statement that atomicity is single-process and in-memory. Reject any claim that fixtures authenticate users or that a model-issued flag supplies approval.

## Module 10: MCP authorization and supply chain

See [Module 10](../modules/10-mcp-security.md).

### Quiz answers

1. **Signature and scope do not establish the intended recipient.** A valid token may be issued for another resource or by an issuer not trusted by this deployment. It may also be expired or the wrong token type. MCP Authorization, Token Handling, requires validation and audience binding to the MCP server. RFC 9068 section 4 supplies JWT access-token profile validation requirements. Scope does not substitute for audience or object-level authorization.
2. **Subject and client are different identities.** RFC 9068 section 2.2 defines `sub` and `client_id`. With a resource owner involved, the subject should identify that owner; with client credentials, it should identify the client application under the issuer's policy. The client identifier names the OAuth client. Do not invent a human identity from service credentials or take actor/tenant from JSON arguments. Map validated identities through trusted application policy.
3. **Passthrough erases an audience boundary.** MCP Security Best Practices, Token Passthrough, and MCP Authorization, Token Handling, prohibit accepting or transiting tokens not valid for the MCP server's own resources. Obtain downstream-audience credentials independently through an authorized delegation or service-identity flow. Preserve caller attribution, constrain privileges, and never log the bearer credential. Editing the audience field is not delegation.
4. **Review security-relevant tool identity and semantics.** Changes in server identity, description, argument schema, returned content behavior, destinations, or permitted effects can invalidate prior review. Use a server-qualified registry and reviewed manifest version. A digest shows equivalence to the reviewed artifact, not trustworthy authorship or harmlessness. A different server with the same tool name does not inherit approval.

### Lab assessment

Require fixture-only tests for issuer, audience, expiry, scope, principal mapping, foreign resources, forbidden identity fields, and manifest drift. The fake downstream recorder must never receive incoming bearer credentials. Correctly distinguish invalid credentials from insufficient application permission.

The offline harness deliberately trusts a local fixture registry. It must not be represented as cryptographic verification, an OAuth issuer, or an MCP implementation. A separately built stdio transport needs its own protocol/version evidence. No external network or production credentials are acceptable. Bearer-token identity attribution is not proof that a token was not stolen.

## Module 11: Leakage and contextual handling

See [Module 11](../modules/11-leakage-and-output-security.md).

### Quiz answers

1. **Unauthorized context is already a disclosure risk.** Once foreign data enters a context, it can affect responses, tool arguments, memory, or logs. Filtering the final answer cannot reliably reverse those paths. Enforce retrieval access before constructing context, minimize included data, and separately authorize destinations. Hash matching does not establish truth or rightful disclosure.
2. **Consumers interpret different languages.** HTML text escaping prevents interpretation in that text context; SQL needs fixed query structure and parameter binding, while URLs need scheme and destination validation. Script and CSS contexts require different treatment and are best avoided for dynamic untrusted values. JSON serialization makes syntax valid but does not make embedded values authoritative or safe in another context.
3. **Permitted operations can carry forbidden data.** A tool may place information in a query, link, subject, remote image reference, error, or telemetry event. Enforce resource and destination authorization, argument constraints, and egress policy before execution. Merely approving the tool name or scanning the final answer misses these channels.
4. **A canary test establishes only the tested observation.** Finding a synthetic canary demonstrates that path disclosed it. Not finding it only shows that the detector did not observe its recognized representation in those cases. Splitting, transformation, alternate sinks, and unfamiliar sensitive values remain possible. Report misses and near-match false positives without replacing authorization with detector confidence.

### Lab assessment

Require valid reads and local drafts alongside cross-tenant and recipient denials. The altered recipient case must preserve the original approval binding and leave the outbox unchanged. No real email is sent. Evaluate actual values in the parameterized SQLite row and context-specific escaped strings, not claims about a browser that was never run.

Logs and deliverables must not contain approval tokens or real secrets. A proposed-output wrapper adds controls outside the supplied simulator; grade its schema checks separately. The lab demonstrates deterministic boundary cases, not a measured real-model leakage rate.

## Module 12: Isolation, SSRF, and quotas

See [Module 12](../modules/12-isolation-and-resource-limits.md).

### Quiz answers

1. **Configuration determines isolation.** A privileged container, writable host mount, management socket, unrestricted network, or inherited secret can invalidate the intended boundary. Assess identity, capabilities, filesystem, environment, syscall policy, egress, resource limits, and patching. A Python wrapper is not an OS sandbox.
2. **The eventual destination can differ from the initial URL.** Redirects can leave an allowed service; alternate DNS answers or mapped addresses can reach forbidden networks. Validate all candidate addresses and every hop under the actual deployment policy. An approved hostname string alone does not validate a connection.
3. **Check and use may resolve differently.** DNS can produce an allowed address at validation and a forbidden one at connection. Couple the validated address to the actual connection while preserving hostname/TLS checks, and enforce independent network egress restrictions. The fake resolver tests policy logic only, not the behavior of a real client, proxy, or connection pool.
4. **Separate counters invite quota bypass.** A retry that resets usage or concurrent workers reading the same remaining capacity can exceed the aggregate limit. Reserve atomically before effects, share accounting across the relevant workflow/user/tenant boundary, retain consumed usage on cancellation, and reconcile unused reservations. OS limits and business quotas address different resources.

### Lab assessment

All SSRF cases must use in-memory URLs, fake DNS, and canned responses with no sockets or external network. Documentation-range fixture allowances must be labeled test-only. Require redirect, mixed-address, mapped-address, and DNS-change negatives plus a valid fixture control.

Require quota denials before simulator effects, multibyte-aware byte accounting, bounded retries, invalid-reservation rejection, and a real shared-counter contention test. Do not accept a benchmark or production containment claim based on these fixtures. A future actual transport or sandbox test is a separately built authorized extension with local-only targets and independently enforced egress denial.

## Overall mastery decision

For each module, require the positive path, all specified negative categories, unchanged-state evidence after rejection, and an honest limitations section. A missing safety boundary is a failed gate even if the prose is polished. Ask the learner to revise that boundary and rerun the relevant tests; never compensate by testing against an unowned external system.
