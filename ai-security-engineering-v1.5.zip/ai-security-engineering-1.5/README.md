# AI Security Engineering: Build, Break, Defend

A practical self-study course for securing AI applications, agents, and model lifecycles.

I built it after seeing how easy AI makes it to build a product, and realising the same is true on the other side: hacking is much easier than it was, and bad actors are equipped with advanced systems too. Old systems built without this attack vector in mind have to adapt, and new ones have to make it the standard. The [course guide](COURSE-GUIDE.md#why-this-course-exists) has the longer version.

**Version:** 1.5 | **Prepared:** 6 November 2026 | **Core workload:** 280 estimated hours: 14 weeks at 20 hours/week, or 28 weeks at 10.

## Start here

1. Read [the course guide](COURSE-GUIDE.md), then complete [the diagnostic](assessments/diagnostic.md).
2. If needed, use [the optional foundation bridge](FOUNDATION-BRIDGE.md).
3. Use [the media index](MEDIA-INDEX.md) and [curated resource library](MEDIA-LIBRARY.md) for verified videos, blogs, Reddit discussions, and optional X posts.
4. Get the course folder: [ai-security-engineering-v1.5.zip](https://github.com/vetri02/mcp-host-exercise/raw/main/ai-security-engineering-v1.5.zip) holds the lab, the targets, the templates and the tutor skill. Unzip it and open a terminal in the extracted folder. If you are reading this inside that folder, you already have it. Then run the offline lab using [its README](reference-lab/README.md).
5. Begin [Module 01](modules/01-python-http-and-testing.md). Complete modules in order and pass the mastery gates.
6. Finish [the two-week capstone](CAPSTONE.md), then choose an [advanced extension](ADVANCED-TRACK.md).

Not sure yet whether to commit to the whole course? [One target on its own](https://github.com/vetri02/mcp-host-exercise), the MCP host from Module 10, is a small public repository that needs only Python: watch a host trust the wrong server, then fix it until five flags print. It takes an afternoon.

The package includes 24 authored lessons, labs, 98 module quiz questions, instructor answer keys, six milestone assessments, a capstone rubric, editable evidence templates, and a standard-library reference lab. Modules 21-24 (version 1.2) add a hands-on real-model lab using a free local runtime, and cover coding agents, browser and computer-use agents, and multi-agent systems. Version 1.3 adds a [first principles map](FIRST-PRINCIPLES.md), an end-to-end account of how a language model is built in Module 03 with a runnable toy model, and twenty verified recordings including Andrej Karpathy's build-it-yourself lectures. Version 1.4 adds two hands-on [targets](targets/README.md) with flag-printing graders for Modules 07 and 15, a [peer-review protocol](assessments/peer-review.md) with a twenty-point rubric, and four DEF CON recordings served from the conference's own archive. Version 1.5 adds two more targets, an [MCP host](targets/mcp_shield/README.md) for Module 10 and a [multi-turn guard with a supplied fuzzer](targets/multi_turn/README.md) for Module 17, and a [build-projects list](ADVANCED-TRACK.md#build-projects) for self-directed work after the core. The handbook PDF and the website carry the reading material; the runnable parts (reference lab, targets, tutor skill, templates) live in the course folder, which downloads as [a zip from the public GitHub repository](https://github.com/vetri02/mcp-host-exercise/raw/main/ai-security-engineering-v1.5.zip). The course also builds as a single-page site with the recordings embedded; the `deploy/cloudflare` folder in the repository publishes it to Cloudflare in three commands.

## Important boundaries

The supplied lab runs offline with synthetic records. It simulates authorization, retrieval, approval, memory, and audit controls. It is not a live LLM, authentication service, MCP server, SQL executor, production security product, or proof of injection resistance. Real model, MCP, cloud, and infrastructure work is explicitly labelled as learner-built extensions.

Use only your own isolated systems or explicitly authorized labs. No production data or credentials. No live email, payments, destructive commands, or scanning unrelated services. Review [sources and version notes](SOURCES.md). Model/API usage in extensions may cost money; the baseline lab requires no API key. Modules 21-24 use a small open-weight model run locally with Ollama or llama.cpp, which is free but needs roughly 8 GB of memory; each of their examples also runs without a model and says so.

This course is not affiliated with its referenced organizations and does not confer an accredited certificate, compliance status, or guaranteed employment.

## Studying with an AI assistant

If you work with Claude Code or a similar agent open beside the course, the repository tells it how to behave: `AGENTS.md` at the root sets the rules (Claude Code reads it through `CLAUDE.md`) (it may explain, quiz and grade; it may not write your `hardened.py` or open the answer keys before the gate), and the `/aisec-tutor` skill in `.claude/skills/` gives it the tutor routine: where you are in the path, one quiz question at a time, grader output explained from the module text, milestone reviews scored with the peer-review rubric. The deployed site also publishes `llms.txt` for assistants that read the web. [Study with an AI assistant](ASSISTANT.md) explains the setup and the habits that keep the assistant useful.

## How this was written

This course was drafted with AI assistance (Anthropic's Claude, through Claude Code) under the author's direction. Every command, test and grader result it cites was executed rather than imagined, and every recording and source was fetched and checked on the dates recorded in [VERIFICATION.md](VERIFICATION.md) and [MEDIA-LIBRARY.md](MEDIA-LIBRARY.md), which also say what was not watched or read in full. If a passage reads wrong or a source has moved, tell the author.

## Licence

Free to use. Code is MIT; the writing and the handbook are CC BY 4.0; linked and embedded third-party material stays under its owners' terms. [LICENSE.md](LICENSE.md) has both licences and the terms of use.
