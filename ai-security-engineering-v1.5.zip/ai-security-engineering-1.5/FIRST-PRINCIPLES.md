# First principles map

Version 1.5, 5 November 2026 (first published in version 1.3). This page lists the small set of principles the whole course rests on, where each one is taught, which recording explains it best, and a question you should be able to answer from the principle alone. Use it three ways: as a pre-course orientation, as a checklist before each milestone, and as the fastest route back to the fundamental when a new product or incident looks confusing.

A first principle here means a fact you can derive from how the component is built, not from a vendor claim, a benchmark, or a framework list. If a control cannot be traced back to one of these, treat it as an assumption to be tested.

## The build path: watch a language model get built

The course's security argument depends on knowing what a language model is, mechanically. The quickest honest way to learn that is to watch one being built, which is what Andrej Karpathy's lecture series does. The path below is ordered; total viewing is about fourteen hours and is spread across Modules 03, 13, 14 and 15 rather than taken in one sitting. Only the first two items are core for the main track; the rest are for learners who want to be able to reason about training and serving, not only application boundaries.

| Order | Recording | What to take from it for security | Where it is used |
|---|---|---|---|
| 1 | [V24 Intro to Large Language Models](MEDIA-LIBRARY.md#v24) (about 1 h) | Weights are a file; pretraining compresses the internet; fine-tuning teaches a format; the model has no trusted channel. | Module 03, core |
| 2 | [V25 Let's build GPT from scratch](MEDIA-LIBRARY.md#v25) (about 2 h) | Tokens become vectors; attention mixes every position in the window; the output is a distribution over the next token and nothing else. | Module 03, core |
| 3 | [V26 Let's build the GPT tokenizer](MEDIA-LIBRARY.md#v26) (about 2 h 15 min) | Byte-pair encoding; why a filter on characters and a model on tokens disagree; why odd strings behave oddly. | Module 03, recommended; Module 05 |
| 4 | [V29 Building makemore](MEDIA-LIBRARY.md#v29) (about 2 h) | A count-based bigram model is a language model; sampling, loss and the idea that training data is the behaviour. | Module 03, optional; pairs with the course's own toy model |
| 5 | [V28 Building micrograd](MEDIA-LIBRARY.md#v28) (about 2 h 25 min) | Gradients and backpropagation in a hundred lines; the same gradient that trains a model finds adversarial inputs. | Module 14, core |
| 6 | [V03 Deep dive into LLMs like ChatGPT](MEDIA-LIBRARY.md#v03) (about 3 h 30 min) | Pretraining, supervised fine-tuning and reinforcement learning as three stages with different data; hallucination and "tool use" as learned behaviours. | Module 03 and 13, optional |
| 7 | [V27 Let's reproduce GPT-2](MEDIA-LIBRARY.md#v27) (about 4 h) | A full training run: dataset, checkpoints, evaluation, cost. Where supply-chain artifacts come from. | Module 15, optional |

The 3Blue1Brown chapters ([V30](MEDIA-LIBRARY.md#v30), [V31](MEDIA-LIBRARY.md#v31), [V32](MEDIA-LIBRARY.md#v32), then [V01](MEDIA-LIBRARY.md#v01), [V02](MEDIA-LIBRARY.md#v02), [V33](MEDIA-LIBRARY.md#v33)) are the visual companion: shorter, no code, and the best place to start if the lecture format is new to you.

## Principles, by layer

Each entry gives the principle, the modules that teach it, the best recording, and a self-check. If you cannot answer the self-check without looking it up, re-read the module section first and watch the recording second.

### A. Computation and learning

**1. A model is a function with parameters, fitted by gradient descent on a loss.** There is no rule engine inside; every behaviour, including refusals, is a region of parameter space found by optimisation. Taught in Module 14 (geometry and optimisation) and the glossary. Watch V28, V30, V31. Self-check: why does the gradient that trains a classifier also point toward an input that fools it?

**2. Training data is the behaviour.** Whatever the corpus contains can be learned, including instructions, secrets, biases and planted triggers; a small number of examples can be enough for a narrow behaviour. Taught in Modules 07, 14 and 15 (B06 Anthropic poisoning study). Watch V29, V24. Self-check: why does removing a poisoned document from the retrieval index not undo its effect if it was also in training data?

**3. Memorisation and generalisation are outcomes of one objective.** The model is not told which strings to memorise; rare, repeated or high-loss sequences are memorised as a side effect, which is why training data can be extracted. Taught in Module 13 (information crosses an interface). Watch V33, V09. Self-check: what makes a sequence more likely to be extractable?

### B. Language models

**4. The model reads tokens, not characters.** A tokenizer splits text into subword units learned from data; filters that inspect characters and models that inspect tokens can disagree about what was "read". Taught in Module 03 (how generation works) and Module 05. Watch V26, V34. Self-check: give two ways the same instruction can be spelled so a character-level denylist misses it.

**5. Generation is sampling from a conditional distribution.** The output at each step is a probability distribution over the next token; temperature and the sampler choose from it. One safe output is one draw, not a guarantee. Taught in Module 03 and the course's toy model, measured in Module 16. Watch V25, V29. Self-check: why is "we tested the prompt and it refused" not evidence of a control?

**6. Context is one undifferentiated sequence.** System prompt, user turn, retrieved document and tool result are concatenated tokens; role markers are tokens too. Nothing in the architecture marks text as trusted. Taught in Modules 03 and 05 (trust boundaries) and Module 10 (tool descriptions). Watch V24, V01, V13. Self-check: what does the toy model in Module 03 show when the same token arrives from a "user" and from a "tool"?

**7. Instruction following is a learned tendency with a failure rate.** Supervised fine-tuning and preference training reward obeying instruction-shaped text wherever it appears. Jailbreaks and injections are the same mechanism viewed from the attacker's side. Taught in Module 03 (pretraining versus instruction tuning), Module 05 and Module 17. Watch V03, V13, V36. Self-check: why is a stronger system prompt not a boundary?

**8. The objective rewards plausibility, not truth.** A fluent false citation and a true one score the same during pretraining; a claim of an action taken is text, not an event. Taught in Module 03 (hallucination) and Modules 01 and 16 (execution oracle, model-as-judge error). Watch V35, V03. Self-check: what artefact proves a tool actually ran?

**9. Attention mixes every position in the window.** The mechanism by which an injected sentence influences the output is the same mechanism that makes the model useful; it cannot be switched off for untrusted spans. Taught in Module 03. Watch V01, V02, V25. Self-check: why does placing instructions "above" a document not isolate them from it?

### C. Systems and security

**10. The security boundary is where data becomes authority.** Text, however fluent, is data until a component with authority acts on it; that component, not the model, is where the control lives. Taught in Module 01 (the lesson), Module 03 (the model proposes, the executor authorises) and Module 08. Watch V13. Self-check: in the reference lab, which function decides whether a proposed read happens?

**11. Kerckhoffs's principle: assume the prompt, schemas and model are known.** A design that fails when read has already failed; security rests on a verified session and server-side policy. Taught in Module 03. Self-check: list three things an attacker can obtain from a deployed assistant without any vulnerability.

**12. Least privilege, and capabilities versus ambient authority.** A tool should carry only the authority its caller holds for this request; broad credentials turn one manipulated step into a large impact. Taught in Modules 02, 08, 10 and 24 (attenuation). Watch V38 for how OAuth expresses delegated, scoped authority. Self-check: what is the difference between a token that names a scope and a model that promises to stay in scope?

**13. Complete mediation: policy outside the model, checked on every action.** Validate the shape of a proposal, then authorise it against the trusted principal, every time, including retries and alternate paths. Taught in Modules 03, 06, 08 and 09. Self-check: name an alternate retrieval path the lab tests for.

**14. Defence in depth and separation of duties.** No single control is assumed to hold; the component that proposes is never the component that approves or records. Taught in Module 04 and Module 09 (approvals). Watch V04. Self-check: which two lab components must both fail for an unauthorised export to occur?

**15. Trust boundaries and the lethal trifecta.** Private data, untrusted content and an outbound channel together make exfiltration possible regardless of model quality; remove one leg or mediate the channel. Taught in Modules 04 and 11, with Modules 22 and 23 as case studies. Watch V07, V17, V19. Self-check: in the Claude Code DNS case (B15), which leg was the outbound channel?

**16. Integrity primitives are different tools.** A hash detects change, a signature binds a change to a key holder, encryption hides content; none of them establishes truth or authorisation. Taught in Module 07 (provenance) and Module 15. Self-check: what does a verified signature on a model file tell you, and what does it not?

**17. Isolation and bounded resources.** Every loop needs step, time, token and spend limits; every sandbox has an egress policy or it is not a sandbox. Taught in Module 12. Watch V21. Self-check: why is a request-rate limit not a spend limit?

**18. Weights and adapters are executable artefacts.** Model files, serialisation formats and adapters run code or change behaviour; they need the same provenance, scanning and promotion gates as software. Taught in Module 15, with B07 (safetensors audit). Watch V27 for where a checkpoint comes from. Self-check: why is a scanner that has to deserialise an artefact in order to validate it already too late?

### D. Measurement

**19. One output is one sample; report rates with uncertainty.** Security claims about generative behaviour are statistics over runs, with a denominator and a confidence interval. Taught in Module 16. Watch V11, V12. Self-check: how many independent attack families are ten paraphrases of one attack?

**20. Base rates decide whether a detector is usable.** A detector with a small false-positive rate on a stream dominated by benign traffic still produces mostly false alerts. Taught in Module 18. Watch V11, V41. Self-check: at a 1% attack rate and a 95%-accurate detector, what fraction of alerts are real?

**21. Evaluation needs held-out and negative tests.** A control is proven by a test that would fail without it, on inputs the control was not tuned on. Taught in Modules 01, 16 and 17. Watch V06, V22. Self-check: what is the positive control in the foundation bridge's Git exercise?

## Coverage audit, version 1.3

Every principle above is taught in at least one module and has at least one recording. The gaps closed in this release are:

- The end-to-end account of how a language model is built (data, tokenizer, architecture, pretraining, fine-tuning, preference training, serving, application layer) now has its own section in Module 03, with the security consequence of each stage, instead of being spread across three paragraphs.
- Module 03 gains a runnable sixty-line language model so that principles 5 and 6 are demonstrated, not asserted.
- Modules 01, 02, 06, 08, 10, 18 and 19 previously had no recording; they now do (Module 01: V37; 02: V38; 06 and 08: V39; 10: V42; 18: V40 and V41; 19: V43).
- Gradients and backpropagation (principle 1) are now taught with recordings in Module 14 (V28, V30, V31, V32) rather than by reading only.

Known remaining gap, updated in version 1.4: the model-file gap is closed by V44 and V45 (DEF CON 30 and 33) and the model-loader target; Module 07 now has a practitioner recording (V46) and the poisoned-corpus target, but no public recording of the PoisonedRAG presentation itself exists on the USENIX Security 2025 page, so the paper remains the primary source for the attack. Version 1.5 closes two grading gaps rather than recording gaps: the MCP boundary (Module 10) and multi-turn evaluation (Module 17) now have targets with graders.
