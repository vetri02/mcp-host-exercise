# Threat model template

## System and scope
- Purpose, owners, environment, release/version, authorization to test.
- Included components and explicitly excluded integrations.
- Assets and confidentiality/integrity/availability requirements.

## Data flows and trust boundaries
- Identity origin and delegation at each hop.
- Sources entering model context; plaintext and credential visibility.
- Model proposal, executor policy, approval, effects, and logs.
- Trusted control-plane stores and who can change them.

## Threat record
- Identifier and asset:
- Attacker capabilities and knowledge:
- Entry point and preconditions:
- Desired effect and causal chain:
- Existing control and authoritative owner:
- Test oracle, positive control, and negative cases:
- Expected vs actual observation:
- Residual risk and untested assumptions:
- Owner, priority, next test, review date:
