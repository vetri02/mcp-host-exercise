# AI security incident runbook template

## Trigger and scope
- Alert, trace ID, affected tenant/user/tool/document/model versions.
- Known observations vs unknown effects; severity and incident owner.

## Contain
- Disable risky writes or tool; limit egress; quarantine implicated version.
- Preserve access-controlled redacted evidence; do not erase needed traces.
- Reconcile actual effects and retries before assuming no impact.

## Investigate
- Identity, context source, proposal, policy, approval and effect timeline.
- Credential or data exposure; related tenants/paths; missing events.

## Eradicate and recover
- Patch independent control; expire affected state; rotate compromised credentials.
- Validate regression and legitimate tasks; restore service in bounded stages.
- Owners, approval, rollback, communication and review date.

## Learn
- Root cause, detection gap, durable test, architecture/policy update.
