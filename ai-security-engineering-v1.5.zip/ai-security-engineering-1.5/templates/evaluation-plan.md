# Evaluation plan template

## Objective and scope
- Assets/effects; attacker control; target/model/prompt/tool/data versions.
- Deterministic invariant checks separated from probabilistic model trials.

## Case design
- Categories, independent families, variations, heldouts, positive controls.
- Attack and legitimate cases; exact expected effects and oracles.
- Model settings, repeats, seed limitations, concurrency, run IDs.

## Budget and safety
- Synthetic-only inputs, owned target, one selected probe category.
- Monetary/token/request/time/loop limits; stop conditions.

## Metrics
- Proposal steering, retrieval selection, unauthorized reads/writes.
- Answer integrity, task utility, false positives, latency and cost.
- Numerators/denominators by category; uncertainty assumptions.

## Comparison and adjudication
- Paired baseline/fix configurations; manual effect validation.
- Judge disagreement process and calibration; no automatic impact claim.
- Zero-event interpretation, coverage gaps, not-tested labels.
