# Peer review form

Milestone: ____  Author: ____  Reviewer: ____  Review date: ____

## Part A, filled by the author

Bundle location and the exact commands to run it:

~~~bash
# e.g. python3 -m unittest discover -s tests -v
~~~

Claims, one per line, each with the test or file that supports it:

1.
2.
3.
4.
5.

Self-score (0-4 per criterion, five criteria):  ____ / 20

Known limits (what the evidence does not show):

## Part B, filled by the reviewer

Run log (what passed, what failed, what would not run, time spent):

Attempts to break each claim, including unsuccessful ones:

| Claim | Attempt | Result |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |

Scores with a one-sentence reason each:

| Criterion | Score | Reason (file, test, or attempt) |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |

Total: ____ / 20   Mastery gate: passed / failed (state the demonstration if failed)

What held:

What broke:

What was not claimed but should have been:

## Part C, filled by the author

Accept / contest / fix and resubmit, per criterion, with evidence:
