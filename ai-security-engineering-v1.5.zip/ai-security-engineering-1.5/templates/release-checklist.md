# Release review checklist

- [ ] Scope and authorization are explicit; synthetic and deployed claims separated.
- [ ] Identity and delegation are authoritative, not caller/model fields.
- [ ] Every retrieval/tool/export path enforces role/object/tenant policy.
- [ ] Context and output sinks do not disclose unauthorized content.
- [ ] Tools are narrow, schemas reviewed, changes versioned.
- [ ] Approval binds actor/action/arguments/state/expiry/use and rechecks live policy.
- [ ] Denied actions leave state unchanged; retries and concurrency are tested.
- [ ] Memory, caches, documents and deletion have defined scope/lifecycle.
- [ ] Artifact expectations and release approvals are independently controlled.
- [ ] Budgets, egress, isolation, secrets and kill switches are tested or marked unknown.
- [ ] Logs support effect reconstruction without raw credentials.
- [ ] Held-out attacks and legitimate tasks are evaluated with honest uncertainty.
- [ ] Incident containment, recovery and regression tests are exercised.
- [ ] Evidence maps to pinned requirements; critical gaps have owners.
- [ ] No-go conditions are clear; human review completes release decision.

Any cross-tenant disclosure, unauthorized effect, approval bypass, exposed credential, unsupported privileged tool, unbounded loop, or missing critical evidence blocks the affected release scope. Passing finite tests is not a complete security proof.
