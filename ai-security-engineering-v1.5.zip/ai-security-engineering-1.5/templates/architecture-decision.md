# Architecture decision record

- ID, date, owner, status and affected release.
- Context, assets, threat model and constraints.
- Options considered and why rejected.
- Decision and authoritative control location.
- Failure behavior, identity propagation and operational owner.
- Verification method and actual evidence.
- Residual risks, assumptions, cost/utility tradeoffs and review trigger.
