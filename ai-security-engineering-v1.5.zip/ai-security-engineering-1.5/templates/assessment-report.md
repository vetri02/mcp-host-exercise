# Security assessment report template

## Executive summary
- Scope, key demonstrated risks, deployment recommendation.
- Distinguish synthetic course approval from production release.

## Authorization and methodology
- Systems owned/authorized; dates; versions; data handling; budget.
- Attacker model, coverage, direct invariant tests and generative tests.

## Architecture and permissions
- Trust-boundary diagram; identity/delegation; tool/data permissions.

## Findings and evidence
- ID, root cause, impact, reproducibility, remediation, retest.
- Evidence-to-requirement map with pinned source versions.

## Evaluation
- Per-category numerator/denominator, heldouts, repeats, uncertainty.
- False positives, legitimate-task success, latency, cost, limitations.

## Operations and residual risk
- Incident exercise, containment, recovery, owners and review dates.
- Unknown or untested integrations remain visible.

## Release/no-go decision
- Mandatory blockers; required evidence; next actions.
- Human reviewer decision, not automatic file/label approval.
