# Finding report template

## Summary
- ID, title, affected version/scope, reviewer.
- Root cause and demonstrated consequence, not only attack name.

## Preconditions and authorization
- Owned/authorized target, synthetic data statement.
- Attacker control and required privileges.

## Reproduction
1. Exact setup and configuration.
2. Input or action.
3. Actual backend state or effect.

## Evidence
- Expected vs observed behavior; trace/case IDs; artifact path and digest.
- Separate retrieval, model steering, execution and disclosure.
- Repetition and uncertainty if probabilistic.

## Remediation and retest
- Independent control at the execution/data boundary.
- Baseline/fix comparison; legitimate-task behavior; regression test.
- Residual risk, owner, due date, status.

## Limitations
- What was not tested; no unsupported whole-system guarantee.
