"""Target 1: a poisoned retrieval corpus (Module 07)."""
