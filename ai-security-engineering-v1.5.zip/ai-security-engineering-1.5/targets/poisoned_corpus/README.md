# Target: the poisoned corpus

Module 07 companion. Time: four to six hours.

## Scenario

A support assistant answers questions from a document store. An independent reviewer approves documents and records each approval in a manifest: tenant, version, source label, and content digest. A contributor then submits an ingestion batch. It contains every approved document and six that nobody approved:

- an unapproved version two of the retention policy that copies the trusted source label and says 365 days instead of 30;
- a note addressed to the assistant rather than the reader, telling it what to answer and to export records;
- three "FAQ" copies of the false claim, all derived from the same unapproved version;
- an approved-looking document for a different tenant that reuses the id of the retention policy.

One approved document is a training note that quotes the attacker's phrase, and it must keep working, because an assistant that rejects every document mentioning an attack has traded one failure for another.

## Watch it fail

~~~bash
python3 -m targets.poisoned_corpus.target
~~~

The vulnerable assistant ranks before it checks eligibility, counts copies as corroboration, turns text found in documents into a proposed action, and keeps serving a cached answer after the document behind it is revoked. Read `target.py` before you run it and write down which line causes each failure.

## Your task

Implement `HardenedAssistant` in `hardened.py`, following the contract in its docstring, then run:

~~~bash
python3 -m targets.poisoned_corpus.check
~~~

| Stage | Invariant | Hint |
| --- | --- | --- |
| 1 | Eligibility before ranking | Decide what may be retrieved before you score anything. The manifest is the only authority; a source label is a string anyone can type. |
| 2 | One approved witness beats four copies | If stage 1 is right this is free. If you solved it by voting, you have not solved it. |
| 3 | Text is data, not an instruction | The training note is approved and must be served. Its quoted imperative must never become an action. Actions are not derived from document text at all. |
| 4 | Latest approved version only | The grader updates the manifest and indexes a reviewed version two. Version one must retire at once, and any cached answer with it. Consult the manifest at query time, not only at index time. |
| 5 | Revocation reaches the cache and citations | After `revoke`, retrieval, `cite`, and `answer` all stop serving the document. If your cache key does not include what was served, the cache is a second copy of the corpus with no reviewer. |

## Deliverables

1. `hardened.py` passing all five stages, with your name on it.
2. The prediction list you wrote before running the vulnerable build, marked right or wrong.
3. Three negative tests the grader does not run. Suggestions: a document whose body matches the digest but whose tenant field was changed; a manifest entry with a digest of the wrong length; a revoke of a document that was never indexed.
4. A limits paragraph. What does a passing grader not prove? At minimum: the manifest does not establish truth or authorship, the reviewer could be wrong, an answer already in a model context cannot be recalled, and lexical overlap is not relevance.

## What this target does not do

Retrieval is lexical, answer extraction is a regular expression over the top document, and the corpus is ingested from a Python list, which is enough to show that the retrieval boundary decides the answer. An embedding model and an ingestion pipeline would add realism without moving that boundary. Module 21 puts the same injected text in front of a real local model, with the executor rather than the retriever as the boundary.
