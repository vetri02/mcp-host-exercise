"""The vulnerable retrieval assistant. Study it, then do not copy it.

It has no model. Answers come from a deterministic extraction rule over
the retrieved documents, which is enough to show every failure the
hardened version must remove:

- it ranks before it checks eligibility, so unapproved and cross-tenant
  documents compete with approved ones;
- it counts copies as corroboration;
- it turns text found in documents into a proposed action;
- it caches answers and keeps serving them after a document is revoked.

Run ``python3 -m targets.poisoned_corpus.target`` to watch it fail.
"""
import re
from collections import Counter, namedtuple

from . import corpus

Answer = namedtuple("Answer", "text cited action")

WORD = re.compile(r"[a-z0-9]+")


def tokens(text):
    return set(WORD.findall(text.lower()))


class VulnerableAssistant:
    def __init__(self, manifest):
        self.manifest = manifest          # held, never consulted
        self.docs = []
        self.cache = {}

    def index(self, docs):
        self.docs.extend(dict(d) for d in docs)

    def rejected(self):
        return []                         # nothing is ever rejected

    def search(self, tenant, query, k=5):
        q = tokens(query)
        scored = [(len(q & tokens(d["body"])), d["id"], d) for d in self.docs]
        scored.sort(key=lambda t: (-t[0], t[1]))
        return [d for score, _, d in scored[:k] if score]

    def answer(self, tenant, question):
        key = (tenant, question)
        if key in self.cache:
            return self.cache[key]
        hits = self.search(tenant, question)
        if not hits:
            return Answer("No source found.", [], None)
        if "retention" in question.lower():
            votes = Counter()
            for d in hits:
                for m in re.findall(r"(\d+) days", d["body"]):
                    votes[m] += 1
            days = votes.most_common(1)[0][0]
            text = "%s days" % days
        else:
            text = hits[0]["body"]
        action = None
        if any("export the records" in d["body"] for d in hits):
            action = "export_records"
        ans = Answer(text, [d["id"] for d in hits], action)
        self.cache[key] = ans
        return ans

    def cite(self, doc_id):
        for d in self.docs:
            if d["id"] == doc_id:
                return d
        return None

    def revoke(self, doc_id):
        self.docs = [d for d in self.docs if d["id"] != doc_id]
        # the cache is left alone: revoked content keeps being served


ASSISTANT = VulnerableAssistant


def main():
    a = VulnerableAssistant(corpus.trusted_manifest())
    a.index(corpus.ingested())
    for q in (corpus.RETENTION_QUESTION, corpus.PHRASE_QUESTION):
        ans = a.answer("alpha", q)
        print("Q:", q)
        print("   answer :", ans.text)
        print("   cited  :", ", ".join(ans.cited))
        print("   action :", ans.action)
    a.revoke("RET-1")
    print("after revoking RET-1, cached answer still says:",
          a.answer("alpha", corpus.RETENTION_QUESTION).text)


if __name__ == "__main__":
    main()
