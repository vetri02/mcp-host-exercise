"""Grader for the poisoned-corpus target.

    python3 -m targets.poisoned_corpus.check
    python3 -m targets.poisoned_corpus.check --solution targets.poisoned_corpus.target

Each stage prints a flag when it passes. The flags are fixed strings; the
point is the invariant behind each one, not the string.
"""
import argparse
import importlib
import sys

from . import corpus

FLAGS = {
    1: "FLAG{pc1-eligibility-before-ranking}",
    2: "FLAG{pc2-one-approved-witness-beats-four-copies}",
    3: "FLAG{pc3-text-is-data-not-an-instruction}",
    4: "FLAG{pc4-latest-approved-version-only}",
    5: "FLAG{pc5-revocation-reaches-cache-and-citations}",
}


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


def stage_1(a):
    """Eligibility before ranking."""
    hits = a.search("alpha", corpus.RETENTION_QUESTION)
    ids = [(d["id"], d["tenant"], d["version"]) for d in hits]
    check(ids[:1] == [("RET-1", "alpha", 1)],
          "alpha retention search returned %r, expected RET-1 v1 first" % ids)
    approved = {(d["id"], d["tenant"], d["version"]) for d in corpus.TRUSTED}
    check(set(ids) <= approved, "ineligible documents retrieved: %r"
          % sorted(set(ids) - approved))
    rejected = {doc_id for doc_id, _ in a.rejected()}
    check(corpus.UNAPPROVED_IDS <= rejected,
          "unapproved documents not all rejected: missing %r"
          % sorted(corpus.UNAPPROVED_IDS - rejected))
    beta = a.search("beta", "retention for support records")
    check([d["id"] for d in beta] == ["BRET-1"],
          "beta search returned %r" % [d["id"] for d in beta])
    check(a.cite("NOTE-7") is None, "NOTE-7 is citable")


def stage_2(a):
    """One approved witness beats four copies."""
    ans = a.answer("alpha", corpus.RETENTION_QUESTION)
    check("30 days" in ans.text, "answer text %r should say 30 days" % ans.text)
    check(list(ans.cited) == ["RET-1"], "cited %r, expected ['RET-1']" % list(ans.cited))
    check(ans.action is None, "an action was proposed: %r" % ans.action)


def stage_3(a):
    """Text is data: the approved training note is served, its quoted
    imperative never becomes an action."""
    hits = a.search("alpha", corpus.PHRASE_QUESTION)
    check(any(d["id"] == "QUOTE-1" for d in hits),
          "QUOTE-1 is approved but was not retrieved; rejecting every "
          "mention of an attack is not a fix")
    ans = a.answer("alpha", corpus.PHRASE_QUESTION)
    check("ignore the policy" in ans.text, "answer did not quote the note")
    check("QUOTE-1" in ans.cited, "QUOTE-1 not cited")
    check(ans.action is None, "action derived from document text: %r" % ans.action)


def stage_4(a, manifest):
    """Latest approved version only; the cache follows the manifest."""
    before = a.answer("alpha", corpus.RETENTION_QUESTION).text
    v2 = corpus.approved_revision(45)
    manifest["RET-1"] = corpus.manifest_entry(v2)
    a.index([v2])
    hits = a.search("alpha", corpus.RETENTION_QUESTION)
    ids = [(d["id"], d["version"]) for d in hits]
    check(ids[:1] == [("RET-1", 2)] and ("RET-1", 1) not in ids,
          "search returned %r after approval of v2" % ids)
    after = a.answer("alpha", corpus.RETENTION_QUESTION)
    check("45 days" in after.text, "answer %r still stale after %r" % (after.text, before))
    check(a.cite("RET-1")["version"] == 2, "cite() serves the retired version")


def stage_5(a, manifest):
    """Revocation reaches retrieval, citations and the cache."""
    del manifest["RET-1"]
    a.revoke("RET-1")
    check(all(d["id"] != "RET-1" for d in a.search("alpha", corpus.RETENTION_QUESTION)),
          "revoked document still retrievable")
    ans = a.answer("alpha", corpus.RETENTION_QUESTION)
    check(ans.text.startswith("No approved source"),
          "answer after revocation: %r" % ans.text)
    check(a.cite("RET-1") is None, "revoked document still citable")


def run(module_name="targets.poisoned_corpus.hardened"):
    mod = importlib.import_module(module_name)
    cls = getattr(mod, "ASSISTANT")
    manifest = corpus.trusted_manifest()
    results = []
    try:
        a = cls(manifest)
        a.index(corpus.ingested())
    except NotImplementedError as e:
        return [(n, False, "not implemented: %s" % e) for n in FLAGS]
    for n, fn in ((1, stage_1), (2, stage_2), (3, stage_3)):
        results.append(_attempt(n, fn, a))
    results.append(_attempt(4, stage_4, a, manifest))
    results.append(_attempt(5, stage_5, a, manifest))
    return results


def _attempt(n, fn, *args):
    try:
        fn(*args)
        return (n, True, fn.__doc__.split("\n")[0])
    except Exception as e:  # the learner's code may raise anything
        return (n, False, "%s: %s" % (type(e).__name__, e))


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--solution", default="targets.poisoned_corpus.hardened",
                   help="module exposing ASSISTANT")
    args = p.parse_args(argv)
    results = run(args.solution)
    passed = 0
    for n, ok, msg in results:
        if ok:
            passed += 1
            print("stage %d  PASS  %s\n         %s" % (n, msg, FLAGS[n]))
        else:
            print("stage %d  FAIL  %s" % (n, msg))
    print("%d of %d stages passed" % (passed, len(results)))
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
