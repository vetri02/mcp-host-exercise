"""Your hardened assistant. Replace every ``NotImplementedError``.

Keep the public interface exactly as below; the grader in ``check.py``
calls only these methods. You may add private helpers and attributes.

Contract:

- ``__init__(manifest)``: ``manifest`` maps document id to the reviewer's
  entry ``{"tenant", "version", "source", "digest"}``. Hold the reference;
  the grader updates it when a reviewer approves a new version or revokes
  a document, and your assistant must honour the current state.
- ``index(docs)``: admit the documents that match the manifest, record
  the rest with a reason, never raise on bad input.
- ``rejected()``: list of ``(doc_id, reason)`` for refused documents.
- ``search(tenant, query, k=5)``: eligibility first, ranking second;
  return only the tenant's currently approved documents.
- ``answer(tenant, question)``: an ``Answer(text, cited, action)`` whose
  ``action`` is always ``None``; text never comes from an ineligible
  document; when nothing approved covers the question, the text starts
  with ``"No approved source"``.
- ``cite(doc_id)``: the currently approved document or ``None``.
- ``revoke(doc_id)``: stop serving the document, its citations, and any
  cached answer built from it.
"""
from .target import Answer, tokens  # noqa: F401  (reuse is allowed)


class HardenedAssistant:
    def __init__(self, manifest):
        self.manifest = manifest
        raise NotImplementedError("build your assistant here")

    def index(self, docs):
        raise NotImplementedError

    def rejected(self):
        raise NotImplementedError

    def search(self, tenant, query, k=5):
        raise NotImplementedError

    def answer(self, tenant, question):
        raise NotImplementedError

    def cite(self, doc_id):
        raise NotImplementedError

    def revoke(self, doc_id):
        raise NotImplementedError


ASSISTANT = HardenedAssistant
