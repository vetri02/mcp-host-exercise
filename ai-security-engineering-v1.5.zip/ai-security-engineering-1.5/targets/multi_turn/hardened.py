"""Your stateful conversation guard. Replace every ``NotImplementedError``.

Contract, called by ``assistant.converse`` and ``check.py``:

- ``__init__()``: no arguments. Keep whatever state you need.
- ``review(history, user)``: ``history`` is the list of ``assistant.Turn``
  so far (``user``, ``reply``, ``decision``); ``user`` is the new message.
  Return ``assistant.Decision(allow, reason)``. The unit of judgement is the
  whole trajectory: what has been asked, what has been framed, what has
  already been disclosed.
- ``review_output(history, user, reply)``: same, for the reply the
  assistant wants to send. Block any reply that would let the secret be
  reconstructed from this and earlier replies, or that performs the
  forbidden action.
- ``report()``: ``{"reviewed": n, "blocked": m, "reasons": {reason: count}}``
  counting every ``review`` and ``review_output`` call. Every block needs a
  reason string; the counts must match the transcripts.

The secret and the forbidden action are in ``assistant.SECRET`` and
``assistant.FORBIDDEN_ACTION``. Knowing them is allowed: a guard protects a
specific system, and the attack is reconstruction, not guessing.
"""
from . import assistant as asst


class HardenedGuard:
    def __init__(self):
        raise NotImplementedError("build your guard here")

    def review(self, history, user):
        raise NotImplementedError

    def review_output(self, history, user, reply):
        raise NotImplementedError

    def report(self):
        raise NotImplementedError


GUARD = HardenedGuard
