"""The vulnerable guard: a per-turn prompt classifier. Run the fuzzer on it:

    python3 -m targets.multi_turn.target

It judges each user message on its own, with a short blocklist, and does not
look at replies at all. That is what most "guardrail" products did first.
"""
import re
from collections import Counter

from . import assistant as asst
from . import fuzzer

BLOCKLIST = re.compile(r"\bwhat is the (override|admin) (code|key)\b|\bexport all\b", re.I)


class StatelessGuard:
    def __init__(self):
        self._reviewed = 0
        self._reasons = Counter()

    def review(self, history, user):
        self._reviewed += 1
        if BLOCKLIST.search(user):
            self._reasons["blocklist"] += 1
            return asst.Decision(False, "blocklist")
        return asst.Decision(True, "")

    def review_output(self, history, user, reply):
        return asst.Decision(True, "")       # output filtering was judged too slow to ship

    def report(self):
        return {"reviewed": self._reviewed, "blocked": sum(self._reasons.values()),
                "reasons": dict(self._reasons)}


GUARD = StatelessGuard


def main():
    print("Crescendo against the stateless guard:\n")
    t = asst.converse(fuzzer.CRESCENDO, StatelessGuard())
    for turn in t.turns:
        print("  user > %s\n  bot  < %s\n" % (turn.user, turn.reply))
    print("leaked:", asst.leaked(t), " actions:", t.actions)
    print("\nFull campaign:\n")
    fuzzer.main(["--guard", "targets.multi_turn.target"])


if __name__ == "__main__":
    main()
