# Hands-on targets

The reference lab shows you a hardened system. The targets do the opposite: each one is a small, deliberately broken system that you must fix until a grader stops finding holes. The first two were added in version 1.4 for the modules whose lab was reading-heavy, Module 07 (knowledge poisoning) and Module 15 (model supply chain). Version 1.5 added two more: an MCP host for Module 10 and a multi-turn conversation guard, with a supplied fuzzer, for Module 17.

Everything is standard-library Python running on synthetic data inside your own machine, so none of it needs a model, a network connection or a credential. The "malicious" model file calls an in-memory canary and nothing else.

## Rules of engagement

- Work in this folder on your own branch or copy. Commands run from the course root.
- Read the vulnerable build first and predict every way it fails before you run it. Write the predictions down; each target's deliverables list asks for them.
- Edit only the `hardened.py` stub in each target. The grader imports it by name. Edit nothing else in the target: `corpus.py`, `fixtures.py`, `servers.py`, `tokens.py`, `canary.py`, `assistant.py`, `fuzzer.py`, `target.py` and `check.py` are the attacker's side of the table or the grader's evidence.
- Each grader stage prints a flag when its invariant holds. Flags are fixed strings and prove nothing on their own; the deliverable is the code and your explanation of why each stage passes.
- Reference solutions live under `instructor/targets/`. Open them after you pass, or after an honest attempt has stalled for more than an hour.

## The targets

| Target | Module | Vulnerable build | Grader | Stages |
| --- | --- | --- | --- | --- |
| [Poisoned corpus](poisoned_corpus/README.md) | 07 | `python3 -m targets.poisoned_corpus.target` | `python3 -m targets.poisoned_corpus.check` | eligibility before ranking; one witness beats four copies; text is data; latest approved version; revocation reaches the cache |
| [Model loader](model_loader/README.md) | 15 | `python3 -m targets.model_loader.target` | `python3 -m targets.model_loader.check` | refuse before deserialising; identity is the consumer's pin; approved bytes still get a schema; member names do not choose paths; failed promotion changes nothing |
| [MCP host](mcp_shield/README.md) | 10 | `python3 -m targets.mcp_shield.target` | `python3 -m targets.mcp_shield.check` | only pinned definitions reach the model; a changed definition is a new tool; the upstream token never leaves the host; a result is data, not a call; arguments meet the pinned schema |
| [Multi-turn guard](multi_turn/README.md) | 17 | `python3 -m targets.multi_turn.target` | `python3 -m targets.multi_turn.check` | the unit of judgement is the trajectory; benign conversations still flow; a persona does not change permissions; partial disclosures add up; the gate reports what it counted |

## Verifying the targets themselves

~~~bash
python3 -m unittest discover -s targets/tests -t . -v
~~~

The suite checks that the vulnerable builds fail the graders, that the untouched stubs fail cleanly, and that the reference solutions pass every stage without tripping the canary. Twenty-nine tests. Run it before you start so a broken environment is not mistaken for a broken solution.

## How the targets are graded in the course

A passed grader is the entry ticket, not the grade. Milestones B (Module 07), C (Module 10), D (Module 15) and E (Module 17) score the written parts: the prediction list, the explanation of each invariant, the negative tests you added beyond the grader's, and the limits paragraph, using the rubric in the [peer-review protocol](../assessments/peer-review.md).
