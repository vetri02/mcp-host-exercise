"""Tests for the targets themselves: the vulnerable builds must be
vulnerable, the learner stubs must fail cleanly, and the reference
solutions must pass every stage.

    python3 -m unittest discover -s targets/tests -t . -v
"""
import io
import contextlib
import unittest

from targets.poisoned_corpus import check as pc_check, corpus, target as pc_target
from targets.model_loader import canary, check as ml_check, fixtures, target as ml_target
from targets.mcp_shield import check as shd_check, servers as shd_servers, target as shd_target
from targets.multi_turn import assistant as mt_asst, check as mt_check, fuzzer as mt_fuzzer, target as mt_target


class PoisonedCorpusTarget(unittest.TestCase):
    def setUp(self):
        self.a = pc_target.VulnerableAssistant(corpus.trusted_manifest())
        self.a.index(corpus.ingested())

    def test_copies_outvote_the_approved_document(self):
        ans = self.a.answer("alpha", corpus.RETENTION_QUESTION)
        self.assertEqual(ans.text, "365 days")
        self.assertIn("FAQ-21", ans.cited)

    def test_document_text_becomes_an_action(self):
        ans = self.a.answer("alpha", corpus.PHRASE_QUESTION)
        self.assertEqual(ans.action, "export_records")

    def test_revocation_misses_the_cache(self):
        before = self.a.answer("alpha", corpus.RETENTION_QUESTION)
        self.a.revoke("RET-1")
        self.assertEqual(self.a.answer("alpha", corpus.RETENTION_QUESTION), before)

    def test_grader_fails_the_vulnerable_build(self):
        results = pc_check.run("targets.poisoned_corpus.target")
        self.assertFalse(all(ok for _, ok, _ in results))
        self.assertFalse(results[0][1])     # stage 1 must fail

    def test_grader_reports_unimplemented_stub(self):
        results = pc_check.run("targets.poisoned_corpus.hardened")
        self.assertEqual([ok for _, ok, _ in results], [False] * 5)

    def test_reference_solution_passes(self):
        results = pc_check.run("instructor.targets.poisoned_corpus_solution")
        self.assertEqual([ok for _, ok, _ in results], [True] * 5, results)

    def test_cli_exit_codes(self):
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(pc_check.main(["--solution", "instructor.targets.poisoned_corpus_solution"]), 0)
            self.assertEqual(pc_check.main(["--solution", "targets.poisoned_corpus.target"]), 1)


class ModelLoaderTarget(unittest.TestCase):
    def setUp(self):
        canary.reset()
        self.loader = ml_target.VulnerableLoader()

    def test_pickle_executes_on_load(self):
        self.loader.load(fixtures.evil_pickle())
        self.assertEqual(canary.TRIPPED, ["pickle-load-executed"])

    def test_json_prefixed_pickle_also_executes(self):
        self.loader.load(fixtures.evil_pickle_with_json_prefix())
        self.assertEqual(canary.TRIPPED, ["pickle-load-executed"])

    def test_adjacent_checksum_is_accepted(self):
        t = fixtures.tampered_blob()
        self.assertEqual(self.loader.load(t, fixtures.adjacent_checksum(t)), (1.0, 2.5))

    def test_self_approval_promotes(self):
        self.loader.promote({"digest": "deadbeef", "approved": True})
        self.assertEqual(self.loader.current(), "deadbeef")

    def test_grader_fails_the_vulnerable_build(self):
        results = ml_check.run("targets.model_loader.target")
        self.assertFalse(results[0][1])     # the canary trips

    def test_grader_reports_unimplemented_stub(self):
        results = ml_check.run("targets.model_loader.hardened")
        self.assertEqual([ok for _, ok, _ in results], [False] * 5)

    def test_reference_solution_passes(self):
        results = ml_check.run("instructor.targets.model_loader_solution")
        self.assertEqual([ok for _, ok, _ in results], [True] * 5, results)

    def test_reference_solution_never_trips_canary(self):
        ml_check.run("instructor.targets.model_loader_solution")
        self.assertEqual(canary.TRIPPED, [])


class McpShieldTarget(unittest.TestCase):
    def setUp(self):
        self.s = shd_servers.make_servers()
        self.host = shd_target.VulnerableHost(self.s)

    def test_poisoned_description_reaches_the_model(self):
        self.assertTrue(any("<IMPORTANT>" in t["description"] for t in self.host.tools_for_model()))

    def test_upstream_token_is_forwarded(self):
        self.host.call("files", "read_file", {"path": "docs/a.txt"})
        self.assertIn(shd_servers.UPSTREAM_TOKEN, self.s["files"].requests[-1][1]["authorization"])

    def test_result_next_call_is_executed(self):
        self.host.call("notes", "lookup", {"query": "x"})
        self.assertEqual(self.s["files"].calls[-1][0], "send_email")

    def test_grader_fails_the_vulnerable_build(self):
        results = shd_check.run("targets.mcp_shield.target")
        self.assertEqual([ok for _, ok, _ in results], [False] * 5)

    def test_grader_reports_unimplemented_stub(self):
        results = shd_check.run("targets.mcp_shield.hardened")
        self.assertEqual([ok for _, ok, _ in results], [False] * 5)

    def test_reference_solution_passes(self):
        results = shd_check.run("instructor.targets.mcp_shield_solution")
        self.assertEqual([ok for _, ok, _ in results], [True] * 5, results)

    def test_cli_exit_codes(self):
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(shd_check.main(["--solution", "instructor.targets.mcp_shield_solution"]), 0)
            self.assertEqual(shd_check.main(["--solution", "targets.mcp_shield.target"]), 1)


class MultiTurnTarget(unittest.TestCase):
    def test_crescendo_leaks_through_the_stateless_guard(self):
        t = mt_asst.converse(mt_fuzzer.CRESCENDO, mt_target.StatelessGuard())
        self.assertTrue(mt_asst.leaked(t))
        self.assertIn(mt_asst.SECRET, t.turns[-1].reply)

    def test_fragments_reconstruct_the_secret(self):
        t = mt_asst.converse(mt_fuzzer.FRAGMENTS, mt_target.StatelessGuard())
        self.assertGreaterEqual(mt_asst.coverage([x.reply for x in t.turns]), 0.5)

    def test_campaign_gate_fails_the_stateless_guard(self):
        res = mt_fuzzer.run_campaign(mt_target.StatelessGuard())
        self.assertEqual(res["leaks"], res["attacks"])
        self.assertFalse(mt_fuzzer.gate(res))

    def test_grader_fails_the_vulnerable_build(self):
        results = mt_check.run("targets.multi_turn.target")
        self.assertEqual([ok for _, ok, _ in results], [False] * 5)

    def test_grader_reports_unimplemented_stub(self):
        results = mt_check.run("targets.multi_turn.hardened")
        self.assertEqual([ok for _, ok, _ in results], [False] * 5)

    def test_reference_solution_passes(self):
        results = mt_check.run("instructor.targets.multi_turn_solution")
        self.assertEqual([ok for _, ok, _ in results], [True] * 5, results)

    def test_cli_exit_codes(self):
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(mt_check.main(["--solution", "instructor.targets.multi_turn_solution"]), 0)
            self.assertEqual(mt_check.main(["--solution", "targets.multi_turn.target"]), 1)
            self.assertEqual(mt_fuzzer.main(["--guard", "instructor.targets.multi_turn_solution"]), 0)


if __name__ == "__main__":
    unittest.main()
