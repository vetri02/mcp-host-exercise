"""The vulnerable loader. It does what many real loaders did for years:
it sniffs the format and hands the bytes to whichever parser fits,
including ``pickle``; it trusts the checksum file that arrived with the
artefact; it extracts archives wherever the member names point; and its
promotion step believes the candidate's own ``approved`` flag.

Run ``python3 -m targets.model_loader.target`` to watch the canary trip.
"""
import io
import json
import os
import pickle
import tempfile
import zipfile

from . import canary, fixtures


class VulnerableLoader:
    def __init__(self, approved=frozenset()):
        self.approved = approved          # held, never consulted
        self.current_record = None
        self.previous_record = None

    def load(self, blob, checksum=None):
        if checksum is not None and fixtures.sha256(blob) != checksum:
            raise ValueError("checksum mismatch")
        if blob[:1] == b"\x80":
            return pickle.loads(blob)
        try:
            obj = json.loads(blob)
        except ValueError:
            # "a JSON header line, then the pickled payload"
            _header, _, payload = blob.partition(b"\n")
            return pickle.loads(payload)
        return tuple(obj["weights"])

    def extract(self, archive, dest):
        written = []
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            for name in z.namelist():          # member names decide the paths
                path = os.path.join(dest, name)
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "wb") as out:
                    out.write(z.read(name))
                written.append(name)
        return written

    def promote(self, record):
        if record.get("approved"):
            self.previous_record, self.current_record = self.current_record, record

    def current(self):
        return self.current_record and self.current_record["digest"]

    def rollback(self):
        self.current_record, self.previous_record = self.previous_record, None


LOADER = VulnerableLoader


def main():
    canary.reset()
    loader = VulnerableLoader()
    print("clean artefact  ->", loader.load(fixtures.clean_blob()))
    tampered = fixtures.tampered_blob()
    print("tampered + attacker checksum ->",
          loader.load(tampered, fixtures.adjacent_checksum(tampered)))
    loader.load(fixtures.evil_pickle())
    print("evil pickle     -> canary:", canary.TRIPPED)
    dest = tempfile.mkdtemp(prefix="model-loader-")
    loader.extract(fixtures.slip_archive(), dest)
    escaped = os.path.normpath(os.path.join(dest, "..", "..", "escaped.txt"))
    print("slip archive    -> wrote outside root:", os.path.exists(escaped))
    if os.path.exists(escaped):
        os.remove(escaped)
    loader.promote({"digest": "deadbeef", "approved": True})
    print("self-approved candidate promoted ->", loader.current())


if __name__ == "__main__":
    main()
