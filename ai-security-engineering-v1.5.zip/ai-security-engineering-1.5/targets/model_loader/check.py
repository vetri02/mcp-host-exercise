"""Grader for the model-loader target.

    python3 -m targets.model_loader.check
    python3 -m targets.model_loader.check --solution targets.model_loader.target
"""
import argparse
import importlib
import os
import shutil
import sys
import tempfile

from . import canary, fixtures

FLAGS = {
    1: "FLAG{ml1-refused-before-deserialisation}",
    2: "FLAG{ml2-adjacent-checksum-is-not-identity}",
    3: "FLAG{ml3-approved-bytes-still-get-a-schema}",
    4: "FLAG{ml4-member-names-do-not-choose-paths}",
    5: "FLAG{ml5-failed-promotion-changes-nothing}",
}


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


def expect_value_error(fn, label):
    try:
        fn()
    except ValueError:
        return
    except Exception as e:
        raise AssertionError("%s raised %s, expected ValueError" % (label, type(e).__name__))
    raise AssertionError("%s was accepted" % label)


def stage_1(loader, approved):
    """Refused before deserialisation: the canary never trips."""
    for label, blob in (("evil pickle", fixtures.evil_pickle()),
                        ("json-prefixed pickle", fixtures.evil_pickle_with_json_prefix())):
        approved.add(fixtures.sha256(blob))     # even an approved pickle is refused
        canary.reset()
        expect_value_error(lambda: loader.load(blob), label)
        check(not canary.TRIPPED, "%s executed code during load" % label)


def stage_2(loader, approved):
    """Identity comes from the consumer's pinned set, not the file beside the artefact."""
    clean = fixtures.clean_blob()
    check(loader.load(clean) == (1.0, 2.0), "clean approved artefact failed to load")
    tampered = fixtures.tampered_blob()
    expect_value_error(lambda: loader.load(tampered, fixtures.adjacent_checksum(tampered)),
                       "tampered artefact with matching adjacent checksum")
    expect_value_error(lambda: loader.load(tampered), "tampered artefact")


def stage_3(loader, approved):
    """Approved bytes still get a schema: each malformed fixture is pinned, then refused."""
    for label, blob in fixtures.malformed_blobs().items():
        approved.add(fixtures.sha256(blob))
        expect_value_error(lambda: loader.load(blob), label)


def stage_4(loader, approved):
    """Member names do not choose paths."""
    root = tempfile.mkdtemp(prefix="ml-target-")
    try:
        dest = os.path.join(root, "a", "b")
        os.makedirs(dest)
        for label, archive in (("path-climbing archive", fixtures.slip_archive()),
                               ("absolute-member archive", fixtures.absolute_archive()),
                               ("inflating archive", fixtures.bomb_archive())):
            expect_value_error(lambda: loader.extract(archive, dest), label)
            check(not os.listdir(dest), "%s wrote files before rejecting" % label)
        escaped = os.path.join(root, "escaped.txt")
        check(not os.path.exists(escaped), "a member escaped the extraction root")
        names = loader.extract(fixtures.clean_archive(), dest)
        check(names == ["weights.json"], "clean archive produced %r" % names)
        check(os.path.isfile(os.path.join(dest, "weights.json")), "member not written")
    finally:
        shutil.rmtree(root, ignore_errors=True)


def stage_5(loader, approved):
    """A failed promotion changes nothing; rollback restores the previous release."""
    clean = fixtures.clean_blob()
    rec = fixtures.release_record(clean)
    loader.promote(rec)
    check(loader.current() == rec["digest"], "approved release not serving")
    bad = [("self-approved unpinned candidate",
            dict(fixtures.release_record(fixtures.tampered_blob()))),
           ("wrong builder", fixtures.release_record(clean, builder="someone-else")),
           ("missing evaluation", fixtures.release_record(clean, evaluation_id=None)),
           ("not approved", fixtures.release_record(clean, approved=False)),
           ("missing field", {k: v for k, v in rec.items() if k != "source_revision"})]
    for label, candidate in bad:
        expect_value_error(lambda: loader.promote(candidate), label)
        check(loader.current() == rec["digest"], "%s changed the serving release" % label)
    second = fixtures.malformed_blobs()["extra-field"]      # pinned in stage 3
    rec2 = fixtures.release_record(second)
    loader.promote(rec2)
    check(loader.current() == rec2["digest"], "approved switch did not take effect")
    loader.rollback()
    check(loader.current() == rec["digest"], "rollback did not restore the previous release")


def run(module_name="targets.model_loader.hardened"):
    mod = importlib.import_module(module_name)
    cls = getattr(mod, "LOADER")
    approved = {fixtures.sha256(fixtures.clean_blob())}
    try:
        loader = cls(approved)
    except NotImplementedError as e:
        return [(n, False, "not implemented: %s" % e) for n in FLAGS]
    results = []
    for n, fn in ((1, stage_1), (2, stage_2), (3, stage_3), (4, stage_4), (5, stage_5)):
        try:
            fn(loader, approved)
            results.append((n, True, fn.__doc__.split("\n")[0]))
        except Exception as e:
            results.append((n, False, "%s: %s" % (type(e).__name__, e)))
    return results


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--solution", default="targets.model_loader.hardened",
                   help="module exposing LOADER")
    args = p.parse_args(argv)
    results = run(args.solution)
    passed = 0
    for n, ok, msg in results:
        if ok:
            passed += 1
            print("stage %d  PASS  %s\n         %s" % (n, msg, FLAGS[n]))
        else:
            print("stage %d  FAIL  %s" % (n, msg))
    print("%d of %d stages passed" % (passed, len(results)))
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
