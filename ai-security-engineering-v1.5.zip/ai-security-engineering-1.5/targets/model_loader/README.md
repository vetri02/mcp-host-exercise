# Target: the model loader

Module 15 companion. Time: four to six hours. Watch V44 and V45 first: the DEF CON talks on backdoored pickles and on code execution through model file formats show the real versions of every fixture here.

## Scenario

A serving process loads a two-weight "model" from an artefact and promotes releases. The loader sniffs the bytes and hands them to whichever parser fits, including `pickle`; it trusts the checksum file that arrived beside the artefact; it extracts archives wherever the member names point; and the promotion step believes the candidate's own `approved` flag.

The fixtures in `fixtures.py` are all built in memory:

- a clean JSON artefact and a tampered one that ships with a matching checksum;
- a pickle whose only payload is a call to `canary.trip`, and a second one hidden behind a JSON header line;
- seven approved-looking artefacts that are malformed in different ways;
- an archive with a path-climbing member, one with an absolute member name, and one that is small on the wire and large when inflated.

## Watch it fail

~~~bash
python3 -m targets.model_loader.target
~~~

The canary list is the demonstration: a function ran because bytes were loaded. Nothing else happens. The mechanism in a real incident is identical; only the function differs.

## Your task

Implement `HardenedLoader` in `hardened.py`, then:

~~~bash
python3 -m targets.model_loader.check
~~~

| Stage | Invariant | Hint |
| --- | --- | --- |
| 1 | Refused before deserialisation | Choose the parser by policy, never by sniffing. If `pickle` is not on the list, an approved pickle is still refused. The grader pins the evil pickle's digest to make that point. |
| 2 | Identity is the consumer's pin | The checksum beside the artefact was written by whoever wrote the artefact. Ignore it. Your trust anchor is the set the consumer pinned independently. |
| 3 | Approved bytes still get a schema | Identity says the bytes are the ones approved. It does not say they are well formed. Exact types, bounded size, finite values, no extra fields, no nonstandard JSON constants. |
| 4 | Member names do not choose paths | Resolve each member under the destination and compare real paths. Check inflated size before writing. Decide for every member before writing any. |
| 5 | A failed promotion changes nothing | Validate the whole record, then switch in one assignment. Rollback restores the previous release. A candidate's own `approved` flag is a claim, not a decision. |

## Deliverables

1. `hardened.py` passing all five stages.
2. Your prediction list from before the first run.
3. Three negative tests the grader does not run. Suggestions: a record whose digest is approved but whose builder field is an empty string; an archive member named `weights.json/` (a directory entry); a JSON artefact with a duplicate key.
4. A trust-boundary narrative: which checks authenticate bytes, which constrain execution, which evaluate behaviour, and which of the three this target cannot do at all. Valid provenance does not establish the absence of a backdoor; say why.

## What this target does not do

The target has no signature scheme, no registry and no real serialisation library, because each of those would hide the lesson behind a dependency. `safetensors` (B07 in the media index, the audit that made it a default) and model scanners are discussed in V45; this target shows why a scanner that validates after the parser has run is too late.
