"""Target 2: a model-file loader that runs code at load time (Module 15)."""
