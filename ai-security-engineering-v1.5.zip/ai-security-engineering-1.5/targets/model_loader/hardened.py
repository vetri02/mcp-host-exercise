"""Your hardened loader. Replace every ``NotImplementedError``.

Contract, called by ``check.py``:

- ``__init__(approved)``: ``approved`` is a set of hex SHA-256 digests the
  consumer pinned independently. Hold the reference; the grader adds to it.
- ``load(blob, checksum=None)``: return ``(w0, w1)`` for an approved,
  well-formed ``toy-linear-v1`` JSON artefact. Raise ``ValueError`` for
  anything else, before any parser that can execute code sees the bytes.
  ``checksum`` is whatever arrived beside the artefact; it is not a trust
  anchor.
- ``extract(archive, dest)``: write only members whose final path is
  inside ``dest``; reject absolute names, parent references, and members
  that inflate past one mebibyte; return the member names written.
  Raise ``ValueError`` before writing anything if any member is bad.
- ``promote(record)``: require digest in ``approved``, the expected
  builder, a source revision, an evaluation id and ``approved`` true;
  raise ``ValueError`` otherwise and leave the current release unchanged.
- ``current()``: digest of the serving release or ``None``.
- ``rollback()``: restore the previous release.
"""
EXPECTED_BUILDER = "local-builder-A"
MAX_ARTEFACT_BYTES = 2048
MAX_INFLATED_BYTES = 1 << 20


class HardenedLoader:
    def __init__(self, approved):
        self.approved = approved
        raise NotImplementedError("build your loader here")

    def load(self, blob, checksum=None):
        raise NotImplementedError

    def extract(self, archive, dest):
        raise NotImplementedError

    def promote(self, record):
        raise NotImplementedError

    def current(self):
        raise NotImplementedError

    def rollback(self):
        raise NotImplementedError


LOADER = HardenedLoader
