"""An in-memory canary. When a loader executes code it should not, the
only effect is an entry in this list. Nothing touches the filesystem,
network, or shell, which is the whole point of a safe demonstration."""

TRIPPED = []


def trip(tag):
    TRIPPED.append(tag)
    return tag


def reset():
    del TRIPPED[:]
