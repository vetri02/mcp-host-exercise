"""Model artefacts for the loader target. All are built in memory.

The "evil" pickle calls ``canary.trip`` when unpickled. That is the full
extent of its payload. A real malicious model file would call something
else; the loading mechanism is identical.
"""
import hashlib
import io
import json
import pickle
import zipfile

from . import canary

FORMAT = "toy-linear-v1"


def sha256(blob):
    return hashlib.sha256(blob).hexdigest()


def clean_blob():
    return json.dumps({"format": FORMAT, "weights": [1.0, 2.0]}).encode()


def tampered_blob():
    """One weight changed. The attacker also ships a matching checksum
    file beside it; see ``adjacent_checksum``."""
    return json.dumps({"format": FORMAT, "weights": [1.0, 2.5]}).encode()


def adjacent_checksum(blob):
    """What an attacker who controls both files would publish."""
    return sha256(blob)


class _Payload:
    def __reduce__(self):
        return (canary.trip, ("pickle-load-executed",))


def evil_pickle():
    return pickle.dumps(_Payload(), protocol=4)


def evil_pickle_with_json_prefix():
    """A JSON header line followed by the pickle opcodes, the shape of
    many container formats. A loader that sniffs the first byte and then
    falls back to ``pickle`` on a JSON parse error is caught by this one."""
    return b'{"format":"' + FORMAT.encode() + b'"}\n' + evil_pickle()


def malformed_blobs():
    """Approved-looking artefacts that must still fail schema checks."""
    return {
        "wrong-format": json.dumps({"format": "other", "weights": [1.0, 2.0]}).encode(),
        "extra-field": json.dumps({"format": FORMAT, "weights": [1.0, 2.0],
                                   "loader": "exec"}).encode(),
        "string-weight": json.dumps({"format": FORMAT, "weights": ["1.0", 2.0]}).encode(),
        "bool-weight": json.dumps({"format": FORMAT, "weights": [True, 2.0]}).encode(),
        "three-weights": json.dumps({"format": FORMAT, "weights": [1.0, 2.0, 3.0]}).encode(),
        "nonfinite": b'{"format":"' + FORMAT.encode() + b'","weights":[1.0,NaN]}',
        "oversize": json.dumps({"format": FORMAT,
                                "weights": [1.0, 2.0]}).encode() + b" " * 4096,
    }


def clean_archive():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("weights.json", clean_blob())
    return buf.getvalue()


def slip_archive():
    """An archive whose member name climbs out of the extraction root."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("weights.json", clean_blob())
        z.writestr("../../escaped.txt", b"written outside the model directory")
    return buf.getvalue()


def absolute_archive():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("/tmp/escaped.txt", b"absolute member name")
    return buf.getvalue()


def bomb_archive(limit=1 << 20):
    """Small on the wire, larger than the limit when inflated."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("weights.json", b"0" * (limit * 4))
    return buf.getvalue()


def release_record(blob, **overrides):
    rec = {"digest": sha256(blob), "builder": "local-builder-A",
           "source_revision": "synthetic-rev-1", "data_id": "synthetic-data-1",
           "evaluation_id": "eval-1", "approved": True}
    rec.update(overrides)
    return rec
