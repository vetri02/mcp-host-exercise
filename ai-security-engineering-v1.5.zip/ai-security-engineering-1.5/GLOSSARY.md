# Working glossary

## Identity, authority, and effects

**Authentication:** establishing a subject's identity through a trusted process. Fixture objects are not production authentication.

**Authorization:** deciding whether that subject may perform a particular action on a particular resource under current policy.

**Principal:** the trusted representation of a user or service and relevant attributes. Do not derive it from model-generated fields.

**Tenant isolation:** preventing one customer's context, records, memory, or effects from crossing into another's scope without authorized sharing.

**Object-level authorization:** permission for a specific record or resource, not merely a tool or endpoint.

**Least privilege:** granting only the operations, resources, duration, and context needed for a task.

**Capability:** a permission-bearing object or credential whose holder can exercise some authority. Scope and leakage matter.

**Delegation:** preserving or constraining an initiating subject's authority through downstream services.

**Confused deputy:** a privileged component misuses its own authority on behalf of a less-privileged caller.

**Approval:** an additional deliberate decision for a specific action, supplemental to valid authorization.

**TOCTOU:** time-of-check/time-of-use divergence; facts or arguments change between validation and effect.

**Idempotency:** retries represent the same logical operation rather than unintentionally repeating an effect. It is not the same as ignoring every duplicate request.

**Execution oracle:** authoritative evidence of what an operation actually did, such as database state or a controlled outbox, rather than generated claims.

## AI mechanisms and threats

**Token:** a vocabulary unit used by a language model; not necessarily a complete word.

**Context window:** the bounded input sequence available for a generation, including messages and supplied content.

**Embedding:** a numerical representation used for similarity or other learned tasks; not evidence of trust.

**RAG:** retrieval-augmented generation, where selected external content enters inference context.

**Fine-tuning:** additional parameter training from a pretrained model; distinct from retrieval-time context.

**Agent loop:** repeated generation, proposal interpretation, tool execution, and observation. Each step needs bounds and policy.

**Prompt injection:** attacker-controlled content influences model behavior in a way that conflicts with the application's intended instruction/data boundary.

**Indirect injection:** malicious influence enters through retrieved pages, documents, tool results, or other secondary content rather than only the user's direct prompt.

**Jailbreak:** an attempt to bypass model behavior or safety restrictions. It does not necessarily demonstrate application authorization impact.

**Excessive agency:** unnecessarily broad tools, permissions, or autonomy create an enlarged effect surface.

**RAG poisoning:** malicious content enters a retrieval corpus or pipeline to corrupt selected context, answers, or subsequent behavior.

**Training poisoning:** adversarial training-data changes affect the learned model.

**Backdoor:** a learned or inserted behavior activated by a trigger while ordinary behavior may appear acceptable.

**Evasion:** manipulating an inference input to change a model decision under defined feasibility constraints.

**Membership inference:** estimating whether a particular example was part of training under stated attacker knowledge.

**Memorization:** learned retention of example-specific content; an output alone may not establish its provenance.

**Model extraction:** attempting to reproduce model behavior or parameters, often through query access.

**Data extraction:** obtaining protected information from a model or surrounding system; distinct from extracting a surrogate model.

## Integrity, operations, and evaluation

**Integrity digest:** a content identity compared with an independently trusted expectation. It does not prove truth or authorship.

**Provenance:** information about origin and transformation. Claims need appropriate authentication and consumer policy.

**Attestation:** a statement about an artifact or process that can be verified under explicit signer/builder/trust assumptions.

**Supply chain:** upstream code, data, models, adapters, packages, tools, and build/release processes that influence the system.

**MCP:** a protocol for connecting applications with tools and data. Authentication does not replace resource authorization or semantic tool review.

**SSRF:** a service is induced to make unintended server-side requests. Parsing checks alone do not replace egress enforcement.

**Sandbox:** a restricted execution environment. Its actual isolation depends on permissions, runtime, kernel, mounts, network, and operational design.

**Denial of wallet:** resource or API spending abuse, including excessive tokens, recursion, retries, or concurrency.

**Canary:** a synthetic marker used to detect a specific data path in a lab. It is not a general data-loss prevention guarantee.

**Positive control:** a setup demonstrating that the test can observe the targeted behavior, often in an isolated vulnerable fixture.

**Negative test:** a case expected to be rejected or bounded, with effects checked.

**Held-out case:** an evaluation case not used during tuning, helping reveal overfitting to known tests.

**False positive:** a legitimate case incorrectly flagged or blocked under a defined oracle.

**Attack success rate:** successes divided by a precisely defined attack-attempt denominator. Category, configuration, dependence, and impact definition must be stated.

**Confidence interval:** uncertainty about an estimated parameter under specified sampling/model assumptions; not a universal coverage guarantee for adaptive attacks.

**Paired comparison:** baseline and defended configurations evaluated on matched cases/settings to reduce some comparison noise.

**Residual risk:** known or uncertain risk remaining after controls and tests, with an owner and decision.

**No-go condition:** an explicit defect or evidence gap that blocks release of the affected scope.

**Regression test:** a retained test preventing a previously identified failure from silently returning after changes.

## Security principles added in version 1.2

**Trust boundary:** a point where data or control passes between components with different levels of trust, and where validation and authorization must therefore happen. Every arrow across one in a data-flow diagram is a place to test.

**Confidentiality, integrity, availability:** the three properties whose loss defines a security outcome. Confidentiality: information reaches a party not entitled to it. Integrity: data or behavior is changed without authorization. Availability: a legitimate user is denied the service, budget, or approval path. Module 07 uses "artifact integrity" for the narrow, byte-level sense.

**Deny by default:** anything not explicitly permitted is refused. An allowlist is the implementation; a blocklist is its opposite and is always incomplete.

**Defense in depth:** independent controls at different boundaries so that one failure is insufficient for impact. Two controls that share a failure mode, such as two prompts to the same model, are one layer.

**Fail closed:** on error, uncertainty, or timeout, refuse the effect rather than permit it. A broad exception handler that returns success is a fail-open bug.

**Separation of duties:** no single identity may both propose and authorize a consequential change. The reference lab's supervisor-only approval issuance is an instance.

**Capability versus ambient authority:** a capability is authority carried by an unforgeable reference to one specific thing (a single-use approval bound to exact arguments); ambient authority is permission a component has merely because of where it runs (a shared service account). Injection turns ambient authority into the attacker's reach.

**Confused deputy:** a component that uses its own broad authority to act on a caller's behalf without checking the caller's entitlement. Most agent attack chains are confused-deputy chains.

**Kerckhoffs's principle:** a system must remain secure when everything about it except the secret key is public. Applied here: assume the attacker has your system prompt, schemas, and model.

**Canonicalization:** transforming input to a single standard form (normalized Unicode, decoded percent-encoding, resolved paths) before comparing it to a policy, and then using that same form. Checking one form and using another is the classic bypass.

**Side channel:** information leaked through an observable other than the response body: latency, size, error type, cache state. Denial paths should be structurally similar; residual timing risk is measured, not assumed away.

**Attacker model:** an explicit statement of what the adversary controls (inputs, documents, a peer agent), what they know, and what they want. A finding without one is not reproducible.

**Threat, vulnerability, exploit, impact:** a threat is a possible harmful event; a vulnerability is a weakness that permits it; an exploit is a demonstrated path through the weakness; impact is the realized loss in confidentiality, integrity, or availability terms.

**Hash, signature, encryption:** a hash gives bytes an identity (same input, same digest; proves equality only). A signature binds bytes to a private key (proves endorsement, given trust in the key). Encryption hides bytes from anyone without the key (proves nothing about origin or truth).

**Access token, ID token, audience, scope, issuer, subject, client:** an access token is a bearer credential presented to a resource server; its audience names which server, its scope names which operations, its issuer names who minted it, its subject names the resource owner (or the client under client credentials), and client identifies the OAuth client application. An ID token asserts who logged in and is for the client, not for APIs.

**Token passthrough:** forwarding a token intended for one audience to a downstream service unchanged. Forbidden by the MCP specification; erases a resource boundary and confuses accountability.

**Bearer token:** a credential that grants access to whoever presents it, without proof of identity. Possession is the only check, so lifetime, audience, and scope are the only limits on a stolen one.

**CSRF:** cross-site request forgery; a request a browser sends with the user's cookies because another site caused it. Relevant wherever cookies confer authority, including browser agents.

**SBOM and SLSA:** a software bill of materials is an inventory of components; SLSA is a ladder of build-integrity levels whose provenance attestation is a builder-signed statement of source, recipe, and output digests.

**Unsafe deserialization:** loading a serialized object (a pickle, for example) in a way that executes code the data chose. A model file in such a format is a program.

**Workload identity:** an identity issued to a running service or job (for example through SPIFFE or a cloud instance role) rather than to a human, so that a component's authority is explicit and attributable.

**Control plane versus data plane:** the components that decide policy, issue approvals, and register trusted artifacts (control plane) versus the components that process requests under that policy (data plane). The lab's approval registry and document registry are control plane; `run_tool` is data plane.

**Exfiltration:** unauthorized movement of data out of its permitted scope, by any channel, including a URL path, an image request, a DNS label, or a log line.

**Lethal trifecta:** Willison's 2025 compression: private data in context, untrusted content that can steer the model, and a channel out. Remove any leg and the exfiltration class is gone.

**Rate limit, denial of wallet:** a rate limit bounds requests per principal per window, enforced outside the model. Denial of wallet is spending the operator's budget (tokens, API calls, compute) through volume or expensive requests; OWASP calls the broader risk unbounded consumption.

## Model mechanics added in version 1.2

**Token, tokenizer:** the subword unit a model reads and writes, and the component that splits text into those units. Character-level filters and the model can disagree about what was read.

**Context window:** the fixed token budget a request may occupy. System prompt, history, retrieved documents, schemas, and tool results compete for it; truncation drops content silently.

**Sampling, temperature, decoding:** the model outputs a distribution over the next token; decoding selects from it. Temperature sharpens or flattens the distribution. Identical requests vary; one safe output is one draw.

**Pretraining, instruction tuning, preference training (RLHF):** pretraining learns next-token prediction from vast text; instruction tuning and preference training then shape the model to follow instructions and refuse some requests. The model was rewarded for obeying instruction-shaped text wherever it appears, which is the root of prompt injection.

**System prompt and roles:** system, user, assistant, and tool are formatting conventions in a chat template, marked by special tokens in one linear sequence. The model weights them differently; nothing enforces them.

**Instruction hierarchy:** training a model to rank instructions by their source's privilege (system over developer over user over tool output). A model-side mitigation that lowers steering rates; not a boundary.

**Hallucination:** a fluent, plausible continuation that is false, produced because training rewards plausibility rather than verified truth. Claims of actions taken or sources cited need an execution oracle.

**Tool calling:** tool names, descriptions, and JSON schemas are placed in context; the model emits text the host parses as a structured call; the host executes it and appends the result. Each of the three is untrusted at its boundary.

**Guardrail, classifier:** a model or rules engine that labels inputs or outputs as safe or unsafe. A detector with false-positive and false-negative rates that depend on distribution; not a boundary.

**Prompt infection:** a self-replicating injection in a multi-agent system: the injected instruction tells the agent to include itself in its output, so it propagates to the next agent.

**Tool poisoning, tool shadowing:** instructions hidden in a tool's description (seen by the model, not the user); and one server's description altering how an agent uses another server's tool.

**Memory poisoning:** planting a record in persistent memory, through a hostile document, a scheduled write triggered by a later benign reply, or query-only interaction the system chooses to remember, so that later sessions are steered.

**Fine-tuning, adapter (LoRA):** additional training that changes weights; can introduce backdoors and erode safety training. An adapter is a small set of weight deltas applied to a base model, and is executable behavior requiring the same provenance review.

**White-box, black-box:** an attacker with access to weights, gradients, or internals (white-box) versus one with query access only (black-box). Gradient-based evasion assumes the first; query-based extraction needs only the second.

**Perturbation budget, adversarial example:** a bound on how much an input may change (a metric and a threshold) under a stated assumption that the change preserves the input's true class; an input within that budget that flips the prediction.

**Clean-label poisoning, trigger:** poisoning that keeps supplied labels correct while manipulating other aspects of examples; a trigger is the input feature that activates a backdoor's conditional behavior.

## Measurement terms added in version 1.2

**False negative:** an attack the oracle scored as safe. The complement of a false positive (a benign case scored as an attack); reducing one usually raises the other.

**Precision, sensitivity, specificity:** of the cases flagged, the fraction that were real (precision); of the real cases, the fraction flagged (sensitivity or recall); of the benign cases, the fraction correctly not flagged (specificity).

**Base rate, prevalence:** how common the condition actually is in the population. With a low base rate, even a sensitive detector's alerts are mostly false; alert precision depends on it.

**Wilson interval:** a confidence interval for a binomial proportion with better behavior near zero and one than the Wald interval, which collapses to zero width at zero events.

**Rule of three, zero-event bound:** with zero events in n independent trials, the one-sided 95 percent upper bound on the rate is approximately 3/n (exactly 1 − 0.05^(1/n)). It says nothing about untested categories.

**Bootstrap, cluster bootstrap:** estimating uncertainty by resampling the data with replacement many times; a cluster bootstrap resamples whole independent units (cases with their repeats attached) so that dependent rows are not treated as independent.

**Bernoulli trial, frequentist:** a trial with two outcomes and a fixed probability; the interpretation of a confidence interval as a long-run coverage property of the procedure, not a probability about the fixed unknown rate.

**Test oracle:** the observable rule that decides whether a test passed, distinct from the execution oracle (the backend state that shows whether an effect occurred). A text match is a weak oracle; a state check is a strong one.

**LLM judge:** a model used to score another model's outputs. A measurement with its own error rate; audit a sample and report disagreements.

**Proposal-steered rate versus unauthorized-execution rate:** how often the model asked for something the case did not authorize (a model property) versus how often the executor allowed it (an executor property, which must be zero).

## Build-pipeline terms added in version 1.3

**Parameters, weights:** the numbers inside a model that training adjusts; stored as a file and loaded at serving time. Every behaviour of the model, including refusals, is encoded here, so the file is an executable artefact for supply-chain purposes.

**Loss, gradient descent, backpropagation:** the loss measures how badly the model predicted the training data; the gradient says how to change each parameter to reduce it; backpropagation computes that gradient efficiently. The same gradient, taken with respect to the input instead of the parameters, finds adversarial inputs.

**Base model:** the output of pretraining alone: a document completer that continues any text, including instructions found in retrieved content, with no notion of whose instructions to prefer.

**Supervised fine-tuning (SFT), chat template, special tokens:** further training on curated conversations in a fixed format whose role markers are special tokens. The format is a learned convention; it is not authentication, and text that imitates a role marker inside a document presents the same pattern.

**Reward model, reward hacking:** a model or rule that scores outputs during preference training. Policies learn to satisfy the scorer rather than the intent, which is reward hacking; the same failure appears when an agent optimises a metric instead of the goal.

**Byte-pair encoding (BPE):** the algorithm most tokenizers use, merging frequent byte pairs into vocabulary entries. It explains why spacing, confusables and encodings change what the model "reads" and why token count differs from character count.

**Glitch token:** a vocabulary entry present in tokenizer training but rare in model training, producing erratic behaviour. An example of the tokenizer and model being separate artefacts with separate data.

**Logits, softmax:** the per-vocabulary scores a model produces at each step and the function that turns them into a probability distribution. Temperature divides the logits before the softmax, which is why it sharpens or flattens sampling.

**Quantisation:** storing weights at lower numerical precision to reduce memory and cost. It changes model behaviour slightly, so the quantised artefact, not the original, is what an evaluation must cover.

**KV cache, batching:** serving optimisations that keep per-sequence attention state and process many requests together. Isolation between tenants is a property of this layer's memory handling, not of the model; cost grows with context length.

## Terms added in version 1.4

**Canary (in a loader test):** a harmless function whose only effect is to record that it ran. If loading an artefact trips the canary, the loader executed code from the artefact; the demonstration is complete without any real payload.

**Adjacent checksum:** a hash published beside the artefact by whoever published the artefact. It detects transfer corruption and nothing else; an attacker who controls the file controls the checksum. Identity must come from a set the consumer pinned independently.

**Zip slip, path traversal in archives:** an archive member whose name climbs out of the extraction root with `..` or an absolute path, so extracting it writes outside the directory the caller intended. The fix resolves every member under the root and decides before writing anything.

**Promptware:** the authors' term (DEF CON 33, V47) for an indirect prompt injection carried in ordinary data such as a calendar invite, that waits for a later benign request to trigger an agent's tools. The payload is text; the harm is the agent's authority.

## Terms added in version 1.5

**Tool pinning:** recording the digest of a tool definition (name, description, schema) that a person reviewed, and exposing to the model only tools whose current digest matches. A server that changes a definition has published a new tool, and the earlier review does not apply to it.

**Rug pull (MCP):** a server that announces a benign tool, waits for approval, then re-announces the same name with a changed description or schema, relying on the host to keep its approval. Pinning by digest defeats it.

**Crescendo (multi-turn attack):** a family of jailbreaks in which each turn is innocuous on its own and the request escalates across the conversation, often after a persona or fiction is established and earlier partial compliance is acknowledged. A guard that scores single prompts cannot see it.

**Trajectory (as the unit of judgement):** the whole conversation so far, including the assistant's own earlier replies, as the thing a guard evaluates. Partial disclosures across turns add up; the reply that would complete a reconstruction is the one to block.

**Bypass rate:** the fraction of attack sequences in a campaign that reached their goal. It describes that campaign against that target and nothing more; the sample size needed to claim a rate for a real model is a Module 16 question.
