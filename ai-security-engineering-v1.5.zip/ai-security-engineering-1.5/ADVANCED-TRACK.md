# Advanced track: from foundation to specialization

## Choose depth after the core

The twenty-four-module course and capstone establish a broad applied foundation. Excelling requires depth in a selected area, independent review, and repeated work on unfamiliar systems. Choose one of the following twenty-to-forty-hour projects first. Estimates exclude learning major missing prerequisites. These are advanced project briefs, not claims that the short core chapters confer research mastery.

## Track A: production AI application security

Prerequisites: strong backend engineering, identity, SQL, deployment, and Modules 01-12 and 17-20.

Build a locally deployed multi-tenant assistant with maintained authentication middleware, a scoped persistent database, a real model adapter, and a narrow tool executor. Persist approval state and effects with transactional/idempotent semantics. Handle lost responses, retries, concurrent requests, revoked roles, changed resource versions, and policy outages. Add a real MCP integration only after the direct API is secure.

Experiments: replay an action after a simulated timeout; revoke permission while approval waits; change a ticket version; retry a partially failed request; swap a reviewed tool definition; attempt cross-tenant retrieval through an alternate path. Test infrastructure egress using controlled local destinations and policy fixtures, never cloud metadata or unrelated services.

Exit evidence: authenticated deployment diagram, negative integration tests, durable traces, least-privilege credentials, rollback plan, and a report reviewed by another engineer. A container or token alone is not enough. Include actual resource access controls and operational ownership.

## Track B: model privacy and extraction research

Prerequisites: probability, statistics, linear algebra, optimization, experimental ML, and Modules 13-16. Study training/validation splits, regularization, calibration, and differential privacy before making privacy claims.

Train a small model on a public-permissioned or entirely synthetic dataset in a local environment. Compare member/nonmember behavior with a carefully separated evaluation set. Implement a simple membership-inference baseline and calibrate it using held-out data. Explore query-based extraction only against your own toy endpoint. Separate fidelity to the target from accuracy on true labels.

Experiments: vary overfitting, confidence availability, query budget, class balance, and distribution shift. Use repeated splits and confidence intervals. If exploring differential privacy, record the mechanism, clipping, noise, accountant, and privacy parameters; do not infer a formal privacy guarantee from low empirical attack success.

Exit evidence: reproducible training scripts, attack assumptions, clean splits, utility/privacy tradeoffs, limitations, and a small paper-style report. A toy confidence threshold is a learning exercise, not evidence that a production LLM leaks membership at the same rate.

Primary map: [NIST adversarial ML taxonomy](https://www.nist.gov/publications/adversarial-machine-learning-taxonomy-and-terminology-attacks-and-mitigations-0) and the papers in Module 13.

## Track C: adversarial robustness and poisoning

Prerequisites: calculus, optimization, tensor-library competence, experimental design, and Modules 14-16.

Use a small owned classifier and controlled synthetic data. Compare a clean baseline with bounded adversarial inputs, label corruption, and a synthetic trigger introduced during training. Define feasible perturbations and attacker knowledge before choosing an algorithm. Verify that inputs remain valid for the real task; a mathematically small change need not be semantically acceptable.

Experiments: evaluate clean performance, attack success, trigger activation, transfer across seeds, and defender-aware attacks. Test whether a defense actually restores robustness or merely breaks the attack implementation. Keep holdouts independent and report negative results. Separate inference-time evasion, training poisoning, and RAG corruption.

Exit evidence: experiments across multiple seeds, baseline/defense comparisons, resource budget, retained artifacts, and a clear statement that finite attack tests do not prove robustness against all attacks. Only test models and endpoints you own.

## Track D: agent evaluation and multi-agent security

Prerequisites: the full core including the Module 21 real-model lab, and statistics.

Build a small two-agent workflow where one agent retrieves information and another proposes a controlled action. Propagate the initiating identity, restrict each agent's capabilities, and retain a trace across handoffs. Treat summaries and agent messages as untrusted data. Do not let one agent's confidence or claimed approval become authority for another.

Experiments: contaminated handoff summary, changed tool metadata, repeated action proposals, hidden state from prior runs, identity confusion, and an allowed-but-wrong answer that alters a business recommendation. Evaluate proposal steering separately from execution violations and task quality.

Exit evidence: category-level held-out evaluation, paired baseline/fix runs, manually validated failures, cost/utility tradeoffs, and an independent review of the case catalogue. Extend one framework rather than combining several opaque scorers.

Primary sources: [PyRIT](https://microsoft.github.io/PyRIT/latest), [garak](https://github.com/NVIDIA/garak), [OWASP agent guidance](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html), and [Microsoft red-team lessons](https://arxiv.org/abs/2501.07238).

## Track E: secure model platform and supply chain

Prerequisites: CI/CD, artifact registries, cloud identity, containers, and Modules 15/18/19.

Build a release pipeline for a harmless model or JSON weight fixture. Separate builder, reviewer, deployer, and runtime identities. Verify artifact identity against an independently controlled approval record, include source/data/evaluation versions, and prevent the candidate from approving itself. Use safer data formats and do not load untrusted pickle artifacts.

Experiments: mutable tags, swapped adjacent checksums, wrong signer or builder, missing evaluation evidence, credential leakage in logs, orphaned endpoints, and rollback to an unapproved artifact. Treat labels as unverified until actual provenance authentication is implemented.

Exit evidence: pinned release manifest, least-privilege identities, policy tests, protected provenance/evidence, quarantine and rollback procedure, and an architecture review. A signed harmful build remains harmful; authenticity is only one requirement.

## Build projects

A list of "build your own" AI security projects circulates on social media. Most of its items are taught in this course; two of them became graded targets in version 1.5 (the [MCP host](targets/mcp_shield/README.md) and the [multi-turn guard](targets/multi_turn/README.md)). The rest are listed here as self-directed builds for after the core, each with the module that teaches it and the one claim a finished build has to prove with a test. Pick one per month. Document every decision, and write the limits paragraph before the README.

| Build | Teaching module | The claim your tests must prove |
| --- | --- | --- |
| PII masking proxy: deterministic placeholder swap before the model, restoration after | 11 | No placeholder is reversible from the model's side, and restoration never applies to text the model invented. |
| Constrained output cage: grammar- or schema-enforced decoding with executable-content refusal | 08 | A well-formed output that encodes a forbidden action is still refused; the schema is not the policy. |
| Delegated-agent credential broker: short-lived, audience-bound, least-scope tokens per hop | 02, 10 | A token captured at hop N cannot be replayed at hop N-1 or N+1, and expiry is enforced by the receiver, not the issuer. |
| Semantic rate limiter: similarity-based detection of extraction and scraping patterns | 13 | The limiter's false-positive rate on a benign workload is measured, not assumed, and the limit cannot be reset by changing accounts. |
| Computer-use pixel auditor: invisible-element detection and click-target validation | 23 | A click lands only on an element that was visible to a person at decision time, with a screenshot as evidence. |
| Inter-agent sanitisation bus: trust-boundary enforcement between cooperating agents | 24 | A message from a lower-trust agent cannot raise the authority of an action in a higher-trust one, whatever it contains. |
| Memory integrity scanner: detection of planted instructions in episodic or vector memory | 09 | A memory written during one task cannot change tool permissions in a later one; provenance travels with every record. |
| Trajectory ledger: append-only hash chain over prompts, context, tool calls and results | 09, 18 | An investigator can replay any decision from the ledger alone, and a modified record is detected without trusting the writer. |
| Dependency reality check: flag packages a coding agent proposes that do not exist or were registered after the proposal | 15, 22 | Every proposed package name is resolved against the registry before install, and a name that resolves but was registered after the proposal date is quarantined with a test showing both cases. |
| Dependency reality check: flag packages a coding agent proposes that do not exist or were registered after the proposal | 15, 22 | Every proposed package name is resolved against the registry before install, and a name that resolves but was registered after the proposal date is quarantined with a test showing both cases. |
| Dependency reality check: flag packages a coding agent proposes that do not exist or were registered after the proposal | 15, 22 | Every proposed package name is resolved against the registry before install, and a name that resolves but was registered after the proposal date is quarantined with a test showing both cases. |
| Exploit-chain teardown: reproduce a published AI incident in a synthetic environment and map each mitigation | 20 | Every step of the chain is reproduced with synthetic data, and each control named would have stopped a specific step, with a test that shows it. |

One item from the circulating list is not here: an activation-patching dashboard is interpretability research rather than security engineering; Track B's readings are the entry point if that is your interest.

## Continuing practice

Every month, update one primary-source reading, reproduce one technique in an authorized synthetic environment, and review one assumption in your capstone. Keep an evidence-led portfolio: code, tests, results, limitations, and decisions. Read target job descriptions and map each requirement to an artifact or a genuine gap. Do not substitute framework familiarity, certificates, or catchy jailbreaks for demonstrated engineering.
