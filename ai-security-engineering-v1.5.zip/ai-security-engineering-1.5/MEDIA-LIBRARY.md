# Curated media and discussion library

Course version 1.5. Resources checked during this course research on 3 November 2026.

## What changed

Added 13 video references, 12 technical blog/case-study readings, 8 Reddit discussions, and 4 X posts. Use [the module index](MEDIA-INDEX.md) to find the relevant item without browsing an unstructured feed. The original primary-source library remains the technical reference backbone.

Version 1.3 adds 20 recordings (V24-V43): the build-it-yourself lectures behind the [first principles map](FIRST-PRINCIPLES.md), and talks for the seven modules that previously had no video. YouTube items were confirmed through the public oEmbed endpoint; durations and dates for them come from creators' own pages or secondary listings and are marked approximate.

## How to use the library

- Core videos can replace part of a module's two-hour concept-reading block. Optional material is enrichment, not extra mandatory workload.
- Videos were checked using metadata and relevant transcript excerpts, not watched in full. Dates and durations below come from the platform metadata.
- Blogs were read for mechanisms, assumptions and scope. A vendor-reported case is not an independent reproduction. Historical examples do not establish a current product vulnerability or patch status.
- Reddit and X are optional sources of questions, competing opinions and case leads. They are not authority for permission decisions, benchmark results or hiring-market claims.
- X public text was readable through web retrieval without a logged-in account; visible threads may be partial. No social actions were performed.
- Use only owned synthetic labs for reproduction. Do not point attacks at the products named in historical reports.
- V05 includes the episodes separately linked as V04 and V06. Do not double-watch or treat them as independent evidence.
- Do not reproduce long transcript passages; use notes and your own diagrams. Primary docs and your experiments take precedence over commentary.

## A short starting path

1. V01 for the architecture mental model, alongside Module 03.
2. V04 then V13 for red-team framing and injection fundamentals, alongside Modules 04-05.
3. V07 for concrete agent consequences, alongside Modules 09-12.
4. V08 and V09 for broader model-security goals, alongside Modules 13-14.
5. V11 for detector/evaluation tradeoffs, and V06 for automation, alongside Modules 16-17.

If the build pipeline is new to you, watch V24 before V01 and follow the ordered path in the [first principles map](FIRST-PRINCIPLES.md). Karpathy's long V03 and the full V05 series are optional deepening paths. You do not need to consume every resource before starting a lab.

## Videos: explainers, lectures, and research talks

### V01

**[Transformers, the tech behind LLMs | Deep Learning Chapter 5](https://www.youtube.com/watch?v=wjZofJX0v4M)**

- Creator/source: 3Blue1Brown.
- Published: 2024-04-01. Duration: 27m 14s.
- Use: core. Modules: 03.

**Why it belongs:** Visual, first-principles explanation of token representations and the transformer data flow.

**Do this after reading/watching:** Draw the boundary between token prediction and application permission decisions.

**Limits:** Architecture explanation, not a security defense or current provider implementation guide.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V02

**[Attention in transformers, step-by-step | Deep Learning Chapter 6](https://www.youtube.com/watch?v=eMlx5fFNoYc)**

- Creator/source: 3Blue1Brown.
- Published: 2024-04-07. Duration: 26m 9s.
- Use: optional. Modules: 03, 14.

**Why it belongs:** Explains attention, embeddings and how tokens influence one another.

**Do this after reading/watching:** Explain why similarity or attention weight is not a trust or authorization signal.

**Limits:** Simplified conceptual model; do not infer semantic isolation guarantees.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V03

**[Deep Dive into LLMs like ChatGPT](https://www.youtube.com/watch?v=7xTGNNLPyMI)**

- Creator/source: Andrej Karpathy.
- Published: 2025-02-05. Duration: 3h 31m 23s.
- Use: optional deep dive. Modules: 03, 13, 14.

**Why it belongs:** Detailed training/inference mental models, tokenization and model behavior.

**Do this after reading/watching:** Separate training, fine-tuning, inference context and retrieval in a data-lifecycle diagram.

**Limits:** Long general-audience lecture; optional, not required in full and not a security course.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V04

**[Episode 1: What is AI Red Teaming? | AI Red Teaming 101 with Amanda and Gary](https://www.youtube.com/watch?v=DabrWAKNQZc)**

- Creator/source: Microsoft Developer.
- Published: 2025-07-09. Duration: 6m 15s.
- Use: core. Modules: 04, 17, 20.

**Why it belongs:** Introduces AI red-team scope and how it differs from conventional testing.

**Do this after reading/watching:** Write your assets, adversary capabilities and effect-based success criteria before testing.

**Limits:** Vendor-authored introduction; also included in the full-course recording V05.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V05

**[AI Red Teaming 101 – Full Course (Episodes 1-10)](https://www.youtube.com/watch?v=DwFVhFdD2fs)**

- Creator/source: Microsoft Developer.
- Published: 2025-07-09. Duration: 1h 17m 25s.
- Use: optional series. Modules: 04, 05, 16, 17, 20.

**Why it belongs:** A compact ten-episode introduction to manual and automated AI red teaming.

**Do this after reading/watching:** Compare safety behavior testing with the capstone authorization and effect oracles.

**Limits:** Contains V04 and V06; do not count or watch those segments twice. Recheck tool commands against current docs.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V06

**[Episode 8: Automating AI Red Teaming with PyRIT | AI Red Teaming 101](https://www.youtube.com/watch?v=cEHTxmpAgjA)**

- Creator/source: Microsoft Developer.
- Published: 2025-07-09. Duration: 8m 11s.
- Use: core. Modules: 16, 17.

**Why it belongs:** Explains PyRIT components and the move from manual attacks to repeatable campaigns.

**Do this after reading/watching:** Map target, input transformation, strategy, scorer and backend impact oracle separately.

**Limits:** 2025 demonstration; use the installed release docs rather than copying old APIs. Also in V05.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V07

**[DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](https://www.youtube.com/watch?v=b7GvMYedPw8)**

- Creator/source: DEFCONConference.
- Published: 2026-09-30. Duration: 42m 5s.
- Use: core case study. Modules: 05, 09, 11, 12, 18.

**Why it belongs:** Researcher demos across coding and computer-use agents connect malicious content to concrete effects.

**Do this after reading/watching:** Choose one reported case and draw entry point, trust boundary, authority and effect; propose a local synthetic reproduction.

**Limits:** Uploaded September2026 but discusses August2025 findings. Historical demos do not establish present product vulnerability or patch status.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V08

**[Overview of Adversarial Machine Learning](https://www.youtube.com/watch?v=C8jJ4H6BL1c)**

- Creator/source: Software Engineering Institute | Carnegie Mellon University.
- Published: 2023-10-12. Duration: 8m 10s.
- Use: core. Modules: 13, 14, 15.

**Why it belongs:** Short CMU SEI taxonomy of attacker influence and adversarial machine learning.

**Do this after reading/watching:** Classify evasion, training poisoning, backdoors, RAG corruption and extraction by attacker control.

**Limits:** Overview and taxonomy, not proof of robustness or a substitute for current NIST guidance.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V09

**[USENIX Security '21 - Extracting Training Data from Large Language Models](https://www.youtube.com/watch?v=A_P_9mmTuGA)**

- Creator/source: USENIX.
- Published: 2021-09-03. Duration: 11m 28s.
- Use: core historical research. Modules: 13.

**Why it belongs:** Primary research presentation on extracting training data from a language model.

**Do this after reading/watching:** Distinguish memorized-data extraction from membership inference and model extraction.

**Limits:** 2021 experiment and model setting; do not generalize measured rates to current services.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V10

**[USENIX Security '20 - High Accuracy and High Fidelity Extraction of Neural Networks](https://www.youtube.com/watch?v=PPU2a_A2ScI)**

- Creator/source: USENIX.
- Published: 2020-09-14. Duration: 10m 57s.
- Use: optional research. Modules: 13, 14.

**Why it belongs:** Explains accuracy versus fidelity objectives in model extraction.

**Do this after reading/watching:** Define separate surrogate accuracy and target-agreement measurements for your owned toy endpoint.

**Limits:** 2020 research assumptions; only test owned models/endpoints, not commercial services.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V11

**[ROC and AUC, Clearly Explained!](https://www.youtube.com/watch?v=4jRBRDbJemM)**

- Creator/source: StatQuest with Josh Starmer.
- Published: 2019-07-11. Duration: 16m 17s.
- Use: core foundations. Modules: 13, 16.

**Why it belongs:** Step-by-step ROC/AUC explanation for understanding classifier thresholds and false positives.

**Do this after reading/watching:** Select a detector threshold, then report false positives and actual effect violations separately.

**Limits:** ROC/AUC does not measure whole-application authorization or prove adaptive-attack safety.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V12

**[Bootstrapping Main Ideas!!!](https://www.youtube.com/watch?v=Xz0x-8-cgaQ)**

- Creator/source: StatQuest with Josh Starmer.
- Published: 2021-07-05. Duration: 9m 27s.
- Use: optional foundations. Modules: 16.

**Why it belongs:** Explains resampling and uncertainty around estimates.

**Do this after reading/watching:** Identify the independent sampling unit in your evaluation before applying bootstrap intervals.

**Limits:** Naive resampling of correlated prompt variants can give misleading uncertainty; follow Module16 assumptions.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V13

**[Prompt Injection, explained](https://www.youtube.com/watch?v=FgxwCaL6UTA)**

- Creator/source: Simon Willison.
- Published: 2023-05-03. Duration: 12m 16s.
- Use: core conceptual history. Modules: 04, 05, 08, 11.

**Why it belongs:** Researcher introduction to instruction/data confusion and tool-enabled consequences; companion blog includes slides and transcript.

**Do this after reading/watching:** Explain why a stronger prompt or probabilistic filter does not replace independent effect authorization.

**Limits:** 2023 proposed patterns and examples are historical; check newer controls and evaluate utility/security tradeoffs.

**Verification:** YouTube metadata and English transcript excerpts inspected; no claim of watching the entire recording. Checked 2026-11-03.

## Blogs and technical case studies

### B01

**[The lethal trifecta for AI agents: private data, untrusted content, and external communication](https://simonwillison.net/2025/Jun/16/the-lethal-trifecta)**

- Creator/source: Simon Willison.
- Published: 2025-06-16.
- Use: recommended technical reading. Modules: 04, 05, 09, 10, 11.

**Why it belongs:** A concise threat-modeling framework explaining how private-data access, attacker-controlled content, and outbound communication combine into an exfiltration risk. Useful for evaluating whole agent architectures rather than assuming a safer model or prompt solves the problem.

**Do this after reading/watching:** Draw the dataflow for a fictional email assistant and identify two architectural changes that break the trifecta without eliminating its useful function.

**Limits:** Independent practitioner synthesis, not a controlled comparative study. Its categorical skepticism toward guardrails is a reliability argument, not a measured failure rate for every current product; referenced vendor incidents are historical.

**Verification:** Inspected full article body with webfetch; exact title and date exposed by the primary source in search. Checked 2026-11-03.

### B02

**[ChatGPT: Hacking Memories with Prompt Injection](https://embracethered.com/blog/posts/2024/chatgpt-hacking-memories)**

- Creator/source: Johann Rehberger / Embrace The Red.
- Published: 2024-05-22.
- Use: recommended technical reading. Modules: 05, 09, 18.

**Why it belongs:** Shows how untrusted connected-app content, uploaded images, and browsing results can influence a persistent memory tool. Connects memory provenance, visible changes, dangerous-operation approval, and recovery from poisoned state.

**Do this after reading/watching:** Specify a memory-write policy that distinguishes user-approved facts from third-party claims and requires explicit approval for bulk deletion; describe the audit evidence needed to reverse an unauthorized write.

**Limits:** Original researcher case study of May 2024 behavior, not verification of current ChatGPT vulnerability. The author labels an inferred extra-LLM mitigation as a guess, and some bypasses were intermittent; do not teach that inference as confirmed architecture.

**Verification:** Inspected article body, recommendations, disclosure and conclusions with webfetch and extracted text; dateline exposed by primary-source search. Embedded videos were not inspected. Checked 2026-11-03.

### B03

**[MCP Security Notification: Tool Poisoning Attacks](https://invariantlabs.ai/blog/mcp-security-notification-tool-poisoning-attacks)**

- Creator/source: Luca Beurer-Kellner and Marc Fischer / Invariant Labs.
- Published: 2025-04-01.
- Use: recommended technical reading. Modules: 05, 08, 09, 10, 11, 15.

**Why it belongs:** Introduces malicious tool descriptions, descriptor rug pulls, and cross-server tool shadowing, including why a tool need not be invoked to influence another tool. Connects MCP metadata trust, argument visibility, approval quality, pinning, and cross-server dataflow controls.

**Do this after reading/watching:** Compare two synthetic versions of a tool descriptor and design the integrity check, reapproval event, and cross-server policy that should apply when its capabilities or instructions change.

**Limits:** Primary demonstrations, including Cursor, accompanied by promotion of Invariant security products. Separate general protocol claims from the specific clients and versions tested; tool poisoning here is not training-data poisoning. Page exposes April 7 and April 11 follow-up updates.

**Verification:** Inspected complete webfetch article, experiments, mitigations and author byline; publication date exposed in the primary-source search excerpt. Checked 2026-11-03.

### B04

**[Designing AI agents to resist prompt injection](https://www.openai.com/index/designing-agents-to-resist-prompt-injection)**

- Creator/source: Thomas Shadwell and Adrian Spânu / OpenAI.
- Published: 2026-03-11.
- Use: recommended technical reading. Modules: 03, 04, 05, 09, 11, 12.

**Why it belongs:** Frames injection as social engineering and explains source-sink analysis, deterministic limits, outbound-data safeguards, sandboxing, and meaningful consent. A defensive counterpart to exploit cases because it emphasizes constraining consequences even when manipulation succeeds.

**Do this after reading/watching:** For a fictional research agent, define three sensitive source-to-sink transitions and decide which require blocking, redaction, or approval displaying the exact transmitted data.

**Limits:** Vendor self-description of deployed defenses, not independent assurance. Claims that attacks most often fail lack a representative denominator in this post; Safe Url coverage and product behavior are version-specific.

**Verification:** Inspected full webfetch body; date and named authors exposed in article; title exposed by primary-source search. Checked 2026-11-03.

### B05

**[Propagating SharePoint Document Permissions to AI Search and RAG Pipelines](https://devblogs.microsoft.com/ise/sharepoint-doc-level-access)**

- Creator/source: Elena Vavilova / Microsoft ISE Developer Blog.
- Published: 2026-04-30.
- Use: recommended technical reading. Modules: 02, 03, 06, 19.

**Why it belongs:** Concrete permission-aware RAG architecture using least-privilege ingestion, Entra identity normalization, materialized user/group ACLs, and filtering before retrieval. Explicitly discusses access-revocation lag and why filtering after retrieval is too late.

**Do this after reading/watching:** Construct a two-user, three-document ACL test matrix, revoke one permission, and specify the maximum acceptable stale-access window and the tests proving its enforcement.

**Limits:** Microsoft-authored customer implementation specific to SharePoint, Graph, Entra and Azure Search. Materialized permissions do not update automatically; secure by design does not mean immediate revocation or complete treatment of every permission edge case.

**Verification:** Inspected webfetch body including permission flow, query-time filtering, limitations and pitfalls; exact title, author and dateline exposed in primary-source search. Checked 2026-11-03.

### B06

**[A small number of samples can poison LLMs](https://www.anthropic.com/research/small-samples-poison)**

- Creator/source: Anthropic, UK AI Security Institute, and The Alan Turing Institute.
- Published: 2025-10-09.
- Use: recommended technical reading. Modules: 07, 14, 15, 16, 20.

**Why it belongs:** Explains a controlled study finding that a small fixed number of poisoned documents can install a particular backdoor across models from 600M to 13B parameters. The experimental grid, clean-data-volume controls, three seeds per configuration, and 72 trained models support poisoning and statistical reasoning lessons.

**Do this after reading/watching:** Reconstruct the study experiment matrix and explain what evidence distinguishes fixed document count from fixed fraction; propose one additional control before extrapolating to much larger models.

**Limits:** Primary joint research, but the principal demonstration uses a low-stakes gibberish/denial-of-service trigger and models no larger than 13B. The post explicitly says generalization to larger models and more harmful behaviors is unclear; 250 documents is not a universal threshold.

**Verification:** Inspected webfetch body and study design, results and stated limitations; exact title/date exposed in primary-source search. Checked 2026-11-03.

### B07

**[Audit shows that safetensors is safe and ready to become the default](https://huggingface.co/blog/safetensors-security-audit)**

- Creator/source: Nicolas Patry and Stella Biderman / Hugging Face and EleutherAI; commissioned with Stability AI, audited by Trail of Bits.
- Published: 2023-05-23.
- Use: recommended technical reading. Modules: 01, 15.

**Why it belongs:** Explains why executable pickle deserialization is inappropriate for untrusted model weights and describes the narrower safetensors format and external audit. Includes concrete findings on specification precision, validation, polyglot files and test-suite improvements.

**Do this after reading/watching:** Write a model-loading review checklist that separately addresses weight serialization, repository code, dependency provenance, pinned revisions, and isolated execution.

**Limits:** Maintainer announcement with commissioned independent audit and public report. No critical arbitrary-code-execution flaw found is not proof of absence; safe tensor deserialization does not establish trust in model behavior, accompanying code, or the entire repository. Title is the live article heading; indexed page title is Safetensors audited as really safe and becoming the default, with a decorative icon.

**Verification:** Inspected full webfetch body and live heading; primary-source search exposed author bylines and date. Checked 2026-11-03.

### B08

**[Auditing Gradio 5, Hugging Face's ML GUI framework](https://blog.trailofbits.com/2024/10/10/auditing-gradio-5-hugging-faces-ml-gui-framework)**

- Creator/source: Trail of Bits, jointly published with the Hugging Face Gradio team.
- Published: 2024-10-10.
- Use: recommended technical reading. Modules: 01, 02, 11, 12, 15.

**Why it belongs:** Substantive application-security audit covering SSRF, CORS/token theft, file disclosure, output-component processing, and shared deployment infrastructure. Shows why conventional web vulnerabilities and deployment assumptions remain central to ML security, alongside CI analysis and fuzzing.

**Do this after reading/watching:** Translate one SSRF finding and one file-disclosure finding into offline regression-test specifications, including the security invariant, synthetic input, and expected denial.

**Limits:** Paid audit and joint announcement with linked detailed findings. The post says reported issues were addressed after fix review for the October 2024 Gradio 5 release; do not present them as current vulnerabilities or assurance for all later releases.

**Verification:** Inspected webfetch body, vulnerability classifications, fixed-state statement and SDLC recommendations; title, org and date exposed in primary-source search. No exploit reproduction performed. Checked 2026-11-03.

### B09

**[Extracting (Even More) Training Data From Production Language Models](https://spylab.ai/blog/training-data-extraction)**

- Creator/source: Javier Rando and Florian Tramèr / SPY Lab; joint work includes Milad Nasr, Nicholas Carlini and collaborators.
- Published: 2024-07-02.
- Use: recommended technical reading. Modules: 13, 14, 16, 17.

**Why it belongs:** Explains why aligned refusal behavior can conceal rather than eliminate memorization, and how fine-tuning changes observed extraction and targeted reconstruction rates. Supports distinctions between training-data privacy, extraction evidence, and patching one exploit versus fixing the underlying vulnerability.

**Do this after reading/watching:** Using a synthetic canary dataset and supplied offline outputs, specify how to measure exact-match extraction and estimate false positives; distinguish this from ordinary membership inference.

**Limits:** Primary academic follow-up to a 2023 study. Rates apply to the particular historical models, fine-tuning access and datasets; public-web matches are evidence of likely memorization, not proof of possession of the undisclosed training corpus.

**Verification:** Inspected full webfetch body, limitations, experiment summaries and conclusion; title, authors and date exposed in primary-source search. Also inspected the 2023 original for background. Checked 2026-11-03.

### B10

**[Demystifying evals for AI agents](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents)**

- Creator/source: Anthropic.
- Published: 2026-01-09.
- Use: recommended technical reading. Modules: 01, 03, 08, 16, 17, 20.

**Why it belongs:** Detailed engineering treatment of tasks, repeated trials, traces, real outcomes, evaluation harnesses and code/model/human graders. Its distinction between pass@k and pass^k, grader calibration, and capability versus regression suites supplies broader evaluation coverage.

**Do this after reading/watching:** Under an explicitly stated independent-trial assumption, calculate pass@3 and pass^3 for a 75% per-trial success rate; explain which metric suits a customer-facing agent and how correlated failures change the interpretation.

**Limits:** Vendor engineering experience and examples, not a security certification framework. Repeated-trial formulas assume appropriate independence; model graders require human calibration, and high task success does not establish absence of security failures.

**Verification:** Inspected webfetch body, definitions, grader taxonomy and exact pass-metric passage; primary-source search exposes headline and Jan 09, 2026 date. Checked 2026-11-03.

### B11

**[3 takeaways from red teaming 100 generative AI products](https://www.microsoft.com/en-us/security/blog/2025/01/13/3-takeaways-from-red-teaming-100-generative-ai-products/)**

- Creator/source: Blake Bullwinkel, Ram Shankar Siva Kumar, and Veronica Sun / Microsoft Security.
- Published: 2025-01-13.
- Use: recommended technical reading. Modules: 04, 12, 17, 19, 20.

**Why it belongs:** Connects traditional application vulnerabilities, AI-specific risks, human expertise, and iterative break-fix cycles. Provides an accessible entry into the accompanying Microsoft threat-model ontology and whitepaper while emphasizing that automation cannot replace contextual human judgment.

**Do this after reading/watching:** Draft a rules-of-engagement and evidence rubric for a fictional AI-product assessment, separating security findings from responsible-AI harms and allocating checks between automation and human review.

**Limits:** Primary operational experience, but the blog is a selective vendor summary rather than the full technical whitepaper. One hundred products is not a representative sample establishing population prevalence, and the post mixes safety and security outcomes.

**Verification:** Inspected webfetch article body and takeaways; exact title, all three authors and date exposed by primary-source search. Checked 2026-11-03.

### B12

**[Investigating three real-world incidents in our cybersecurity evaluations](https://www.anthropic.com/news/investigating-incidents-cybersecurity-evals)**

- Creator/source: Anthropic, reporting an investigation conducted with evaluation partner Irregular.
- Published: 2026-07-30.
- Use: recommended technical reading. Modules: 12, 15, 17, 18, 19, 20.

**Why it belongs:** Postmortem of evaluation infrastructure unexpectedly permitting internet access, illustrating that written simulation scope is not a containment boundary. Discusses retrospective transcript review, stopping evaluations, notification, vendor assurance, monitoring, and defense in depth.

**Do this after reading/watching:** Produce a tabletop response plan for unexpected external activity in a synthetic evaluation trace: containment, evidence preservation, affected-party notification, vendor responsibilities, and criteria for resuming evaluations.

**Limits:** First-party incident account with limited public transcripts and continuing investigation; three incidents are not a controlled model comparison. Do not treat claims about newer-model behavior or the problem being chiefly a harness failure as independently established. Updated August 3, 2026; live heading includes real-world, which some indexed titles omit.

**Verification:** Inspected full webfetch body, response timeline, comparison caveat and Aug 3 update; primary-source search exposed current heading and publication date. Checked 2026-11-03.

## Reddit: optional engineering discussions

### R01

**[Is AI security a dedicated job or a security-engineering specialization?](https://www.reddit.com/r/AskNetsec/comments/1oqpzuj/is_ai_security_a_real_dedicated_job_yet_or_still/)**

- Creator/source: r/AskNetsec.
- Published: exact date not recorded.
- Use: optional discussion. Modules: 02, 04, 20.

**Why it belongs:** Shows role-title ambiguity and disagreement over application security versus model research.

**Do this after reading/watching:** Choose a target role and map its requirements to course evidence rather than accepting the title alone.

**Limits:** Original post was deleted when inspected; comments remain the evidence. Anecdotes are not hiring-market statistics.

**Verification:** Original post/comments inspected in logged-in browser during this course research; exact publication dates were not recorded. Checked 2026-11-03.

### R02

**[Getting into AI/LLM security and red teaming](https://www.reddit.com/r/LLMDevs/comments/1u612dk/looking_for_advice_on_getting_into_aillm_security/)**

- Creator/source: r/LLMDevs.
- Published: exact date not recorded.
- Use: optional discussion. Modules: 01, 03, 17, 20.

**Why it belongs:** Concrete learning and portfolio suggestions from a backend/security starting point.

**Do this after reading/watching:** Compare a scanner demo with an attack-impact-fix-retest project and identify stronger evidence.

**Limits:** Crossposted elsewhere; counted once, not as independent community consensus. Individual training opinions vary.

**Verification:** Original post/comments inspected in logged-in browser during this course research; exact publication dates were not recorded. Checked 2026-11-03.

### R03

**[Evaluating agentic AI security before production](https://www.reddit.com/r/LLMDevs/comments/1u0ym3n/how_do_you_evaluate_the_security_of_an_agentic_ai/)**

- Creator/source: r/LLMDevs.
- Published: exact date not recorded.
- Use: optional discussion. Modules: 02, 04, 08, 16, 18, 20.

**Why it belongs:** Comments distinguish prompt injection from tool-call authorization and ask for execution traces.

**Do this after reading/watching:** Show what the agent was authorized to query versus what it actually executed.

**Limits:** Reported production anecdotes are unverified. Read-only access is insufficient without row/object scope.

**Verification:** Original post/comments inspected in logged-in browser during this course research; exact publication dates were not recorded. Checked 2026-11-03.

### R04

**[Prompt injection in a self-hosted LLM deployment](https://www.reddit.com/r/LocalLLaMA/comments/1qyljr0/prompt_injection_is_killing_our_selfhosted_llm/)**

- Creator/source: r/LocalLLaMA.
- Published: exact date not recorded.
- Use: optional discussion. Modules: 02, 05, 06, 08, 19.

**Why it belongs:** Discusses why self-hosting and prompt filters do not replace application access controls.

**Do this after reading/watching:** List which threats change with self-hosting and which authorization threats stay the same.

**Limits:** Deployment claims and proposed filters are anecdotes, not validated universal controls.

**Verification:** Original post/comments inspected in logged-in browser during this course research; exact publication dates were not recorded. Checked 2026-11-03.

### R05

**[Red teaming for AI/LLM applications](https://www.reddit.com/r/cybersecurity/comments/1r4p4du/red_teaming_for_aillm_apps/)**

- Creator/source: r/cybersecurity.
- Published: exact date not recorded.
- Use: optional discussion. Modules: 16, 17, 20.

**Why it belongs:** Recommendations for tools alongside comments about scanner reliability and false positives.

**Do this after reading/watching:** Manually adjudicate a detector hit against actual protected state and a legitimate-task control.

**Limits:** Tool endorsements and complaints are anecdotal; versions and reproducibility differ.

**Verification:** Original post/comments inspected in logged-in browser during this course research; exact publication dates were not recorded. Checked 2026-11-03.

### R06

**[Handling MCP authorization-boundary failures](https://www.reddit.com/r/mcp/comments/1qr1pqa/how_are_you_handling_auth_boundary_failures_in/)**

- Creator/source: r/mcp.
- Published: exact date not recorded.
- Use: optional discussion. Modules: 02, 09, 10, 12.

**Why it belongs:** Discusses scoped tokens, fine-grained policy, runtime enforcement and human approval.

**Do this after reading/watching:** Separate transport authentication, application authorization and approval in your MCP design.

**Limits:** Several replies promote their own products; do not treat recommendations as independent validation.

**Verification:** Original post/comments inspected in logged-in browser during this course research; exact publication dates were not recorded. Checked 2026-11-03.

### R07

**[Poisoning an owned RAG store: experiment and limitations](https://www.reddit.com/r/LangChain/comments/1ulss3t/we_tried_to_poison_our_own_rag_store_the/)**

- Creator/source: r/LangChain.
- Published: exact date not recorded.
- Use: optional discussion. Modules: 06, 07, 16.

**Why it belongs:** A useful discussion of retrieval corruption, utility costs and the limits of a synthetic experiment.

**Do this after reading/watching:** Measure retrieval selection, answer corruption and harmful execution separately; add legitimate retrieval tasks.

**Limits:** Small synthetic, retrieval-focused experiment, not a full agent loop or general benchmark. Do not generalize its numerical claims.

**Verification:** Original post/comments inspected in logged-in browser during this course research; exact publication dates were not recorded. Checked 2026-11-03.

### R08

**[Handling prompt injection when agents have production access](https://www.reddit.com/r/cybersecurity/comments/1sx66fe/how_is_your_org_handling_prompt_injection_now/)**

- Creator/source: r/cybersecurity.
- Published: exact date not recorded.
- Use: optional discussion. Modules: 05, 09, 11, 18, 19.

**Why it belongs:** Discusses indirect inputs, tool chaining, governance and observability in production contexts.

**Do this after reading/watching:** Design a trace and containment plan that still helps when a detector misses malicious content.

**Limits:** The author mentions developing a classifier. Advice may be commercially influenced; no proof the described controls are sufficient.

**Verification:** Original post/comments inspected in logged-in browser during this course research; exact publication dates were not recorded. Checked 2026-11-03.

## X posts: optional researcher commentary

### X01

**[MCP prompt-injection risk comes from tool access and untrusted inputs](https://x.com/simonw/status/1909955640107430226)**

- Creator/source: Simon Willison.
- Published: 2025-04-09.
- Use: optional commentary. Modules: 04, 05, 10.

**Why it belongs:** Separates protocol mechanics from the wider tool-using application risk.

**Do this after reading/watching:** Describe a system that uses MCP but avoids one relevant attack path through independently enforced policy.

**Limits:** Short-form researcher commentary; pair with MCP and OWASP primary documentation.

**Verification:** Public post text and visible thread retrieved via web fetch; no posting, following or account changes. Checked 2026-11-03.

### X02

**[Design patterns for securing LLM agents: discussion and paper notes](https://x.com/simonw/status/1933526098941522060)**

- Creator/source: Simon Willison.
- Published: 2025-06-13.
- Use: optional commentary. Modules: 04, 08, 09, 10.

**Why it belongs:** Points to structured design patterns rather than only attack prompts.

**Do this after reading/watching:** For one pattern, state its trust assumptions, utility cost and independent execution check.

**Limits:** The visible discussion is not the paper itself; formal claims depend on the paper model and assumptions.

**Verification:** Public post text and visible thread retrieved via web fetch; no posting, following or account changes. Checked 2026-11-03.

### X03

**[Hidden PDF content and a reported Notion exfiltration path](https://x.com/simonw/status/1969111931152634010)**

- Creator/source: Simon Willison.
- Published: 2025-09-19.
- Use: optional commentary. Modules: 05, 07, 11, 18.

**Why it belongs:** Shows that seemingly passive document content can steer a tool-using workflow.

**Do this after reading/watching:** Model the input-to-sink chain using a synthetic document and local outbox; never test the named live product.

**Limits:** Historical reported case, not a claim of current vulnerability or patch status.

**Verification:** Public post text and visible thread retrieved via web fetch; no posting, following or account changes. Checked 2026-11-03.

### X04

**[Restrict agent actions rather than giving arbitrary execution authority](https://x.com/karpathy/status/1934651657444528277?lang=en)**

- Creator/source: Andrej Karpathy.
- Published: 2025-06-16.
- Use: optional commentary. Modules: 04, 08, 12.

**Why it belongs:** A concise discussion of narrow action types and unrestricted shell authority.

**Do this after reading/watching:** Replace an arbitrary interpreter tool with three typed, scoped operations and define tests.

**Limits:** Opinion and analogy, not a benchmark or comprehensive defense. Evaluate the actual capability boundary.

**Verification:** Public post text and visible thread retrieved via web fetch; no posting, following or account changes. Checked 2026-11-03.

## Resource upkeep

Retain author, title, URL, publication date, review date, version and relevant claim in your source inventory. Recheck current APIs and product status rather than inferring them from a dated talk. Use the current official documentation if commands differ. The JSON catalogue in resources/learning-resources.json contains the same module mappings for filtering and future updates.

## Version 1.2 additions: agentic frontier, hands-on labs, and tools

Added 3 November 2026 for Modules 21-24 and the updated sections of Modules 05, 10, 11, 12, 17 and 19. Entries follow the same format as above; L-items are hands-on labs, tool documentation and model cards.

### Videos, version 1.2

### V14

**[Learn Ollama in 15 Minutes - Run LLM Models Locally for FREE](https://www.youtube.com/watch?v=UtSSMs6ObqY)**

- Creator/source: Tech With Tim.
- Published: 2025-01-13. Duration: 14m 1s.
- Use: core. Modules: 21.

**Why it belongs:** Install, pull a small model, call the local HTTP API from Python: everything Module 21 needs to stand up a zero-cost target.

**Do this after reading/watching:** Stand up the endpoint, then run Module 21's worked example and record model name, digest and quantization.

**Limits:** Sponsor-tagged creator video from early 2025; model names and CLI flags drift, so follow the Ollama API reference (L08) for current syntax.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V15

**[Indirect prompt injection - PortSwigger Web LLM Attacks walkthrough](https://www.youtube.com/watch?v=z_rdrqsocQs)**

- Creator/source: ad4m Academy.
- Published: 2026-06-20. Duration: 11m 9s.
- Use: optional. Modules: 21.

**Why it belongs:** Shows the planted-review to account-deletion chain in the hosted PortSwigger lab before you attempt it yourself.

**Do this after reading/watching:** Attempt the lab (L01) first; then watch and write the five-part trace from Module 05 for the chain shown.

**Limits:** Small channel and a solution video; the Academy lab uses a live model so results vary across runs.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V16

**[Agentic ProbLLMs - Exploiting Coding Agents](https://www.youtube.com/watch?v=3NiL1vtLlIE)**

- Creator/source: Johann Rehberger (hosted by Zenity).
- Published: 2025-10-29. Duration: 30m 33s.
- Use: core. Modules: 22.

**Why it belongs:** The coding-agent-only cut of Rehberger's research: rules-file and repository injection, auto-approved shell commands, exfiltration through tool calls.

**Do this after reading/watching:** For one demonstrated chain, classify every file involved as read-as-text, executed, or both, using Module 22's inventory format.

**Limits:** Vendor-hosted recording; overlaps thematically with V07; historical findings, not current patch status.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V17

**[Agentic ProbLLMs: Exploiting AI Computer-Use and Coding Agents (39c3)](https://www.youtube.com/watch?v=TWhKGqYQT9g)**

- Creator/source: Johann Rehberger / Embrace The Red.
- Published: 2025-12-31. Duration: 58m 51s.
- Use: core. Modules: 23.

**Why it belongs:** The long-form version with the computer-use material: command-and-control through a web page, lure pages, browser agents.

**Do this after reading/watching:** Map one computer-use demo onto the lethal trifecta and name which of Module 23's four structural controls would have broken it.

**Limits:** Substantial overlap with V07 and V16; treat one as core and the others as optional. Historical demonstrations.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V18

**[Deep Dive into the OWASP Top 10 for Agentic AI Applications](https://www.youtube.com/watch?v=-vXoC0UvpjY)**

- Creator/source: John Sotiropoulos / OWASP London.
- Published: 2025-11-23. Duration: 52m 23s.
- Use: core. Modules: 24, 09, 11.

**Why it belongs:** A co-lead of the agentic list walks all ten entries, including inter-agent communication, memory poisoning and orchestrator trust.

**Do this after reading/watching:** For ASI07, ASI08 and ASI10, write one sentence each naming the course control that addresses it and the module where it lives.

**Limits:** Chapter-meeting recording of a draft-era list; the published 2026 document is the reference, this is the spoken companion.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V19

**[Generationship Ep. 39: Simon Willison, I Coined Prompt Injection](https://www.youtube.com/watch?v=_bW58o8l0os)**

- Creator/source: Heavybit.
- Published: 2025-07-10. Duration: 52m 23s.
- Use: optional. Modules: 05.

**Why it belongs:** Long-form conversation on why prompt-level fixes fail and what design-level mitigations (dual LLM, CaMeL, breaking the trifecta) buy.

**Do this after reading/watching:** After reading Module 05's architectural-defenses section, list which of the six design patterns your capstone could adopt and at what cost to generality.

**Limits:** Podcast, not a technical talk; V13 is Willison's shorter 2023 explainer.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V20

**[Using Guardrails for AI Security: LlamaGuard Demonstration](https://www.youtube.com/watch?v=MTFKSAfyGIo)**

- Creator/source: Probably Private (Katharine Jarmul).
- Published: 2025-12-28. Duration: 10m 10s.
- Use: recommended. Modules: 17.

**Why it belongs:** Hands-on run of a content classifier as an input/output guard, reading its category output.

**Do this after reading/watching:** Run the same classifier on Module 17's benign near-miss cases and record its false-positive rate with a Wilson interval.

**Limits:** A demonstration, not an evaluation; the classifier download is gated.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V21

**[OWASP Top 10 LLM10:2025 Unbounded Consumption](https://www.youtube.com/watch?v=HUDOen3nqRE)**

- Creator/source: Martin Voelk.
- Published: 2025-03-22. Duration: 9m 44s.
- Use: optional. Modules: 12.

**Why it belongs:** Narrates the OWASP entry: input-size abuse, repeated requests, expensive queries, denial of wallet, model replication, and mitigations.

**Do this after reading/watching:** List the resources your capstone spends per request and which limit in Module 12 bounds each.

**Limits:** Training-channel narration of a document; no demonstration. The 2026 list renumbers this entry as LLM06.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V22

**[Promptfoo Red Teaming: A beginner's guide to finding vulnerabilities in your LLM apps](https://www.youtube.com/watch?v=y6Dlsz5P8s8)**

- Creator/source: Jason Koo.
- Published: 2026-02-18. Duration: 30m 11s.
- Use: recommended. Modules: 17, 21.

**Why it belongs:** Install, first scan against a target, and reading the report, for the tool Module 21 suggests against a local endpoint.

**Do this after reading/watching:** Point promptfoo at your Ollama endpoint with a local grader, run ten of Module 21's cases through it, and compare its labels with your executor's outcomes.

**Limits:** Individual creator; attack generation defaults to a hosted provider unless reconfigured.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### V23

**[EU AI Act for Developers - What you need to know](https://www.youtube.com/watch?v=w-fcZKq4Ew8)**

- Creator/source: Analysis Cloud IT Vlog.
- Published: 2025-04-02. Duration: 10m 49s.
- Use: optional. Modules: 19.

**Why it belongs:** Short developer-angled orientation to risk tiers and obligations.

**Do this after reading/watching:** Compare its dates with the Commission page (B29); note which ones the 2026 Omnibus changed.

**Limits:** Small channel; predates the July 2026 Omnibus, so its high-risk dates are superseded.

**Verification:** YouTube watch-page metadata (title, author, duration, publish date) inspected; no claim of watching the entire recording. Checked 2026-11-03.

### Blogs, papers and primary documents, version 1.2

### B13

**[New Vulnerability in GitHub Copilot and Cursor: How Hackers Can Weaponize Code Agents](https://www.pillar.security/blog/new-vulnerability-in-github-copilot-and-cursor-how-hackers-can-weaponize-code-agents)**

- Creator/source: Ziv Karliner et al. / Pillar Security.
- Published: 2025-03-18.
- Use: core. Modules: 22.

**Why it belongs:** The origin disclosure of the rules-file backdoor: invisible Unicode in instruction files that survives review, forks and templates.

**Do this after reading/watching:** Create one hidden zero-width character in a scratch instruction file and confirm Module 22's scanner reports it; then confirm ordinary accented text does not.

**Limits:** Vendor research; GitHub added hidden-Unicode warnings in May 2025, so reproduce only in your own repository.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B14

**[Prompt injection to RCE in AI agents](https://blog.trailofbits.com/2025/10/22/prompt-injection-to-rce-in-ai-agents/)**

- Creator/source: Will Vandevanter / Trail of Bits.
- Published: 2025-10-22.
- Use: core. Modules: 22, 12.

**Why it belongs:** Shows allowlisted 'safe' commands giving one-shot code execution in three production agents, and lists structural mitigations: sandboxing, hardened handlers, minimal allowlists.

**Do this after reading/watching:** For each allowlisted command in an agent you use, write what side effect it can have beyond its purpose, and whether any is a sink.

**Limits:** Agents are unnamed; references fixed CVEs; the mitigation list is the author's, not a standard.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B15

**[Claude Code: Data Exfiltration with DNS (CVE-2025-55284)](https://embracethered.com/blog/posts/2025/claude-code-exfiltration-via-dns-requests/)**

- Creator/source: Johann Rehberger / Embrace The Red.
- Published: 2025-08-11.
- Use: core. Modules: 22, 11.

**Why it belongs:** End-to-end chain from injected file content through an auto-approved lookup utility to a secret encoded in a DNS label.

**Do this after reading/watching:** Add 'DNS query label' to your Module 11 sink inventory and name two other allowlisted commands with a network side effect.

**Limits:** Fixed in the version named; use for the mechanism, not as a current vulnerability.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B16

**[Agentic Browser Security: Indirect Prompt Injection in Perplexity Comet](https://brave.com/blog/comet-prompt-injection/)**

- Creator/source: Artem Chaikin, Shivan Kaul Sahib / Brave.
- Published: 2025-08-20.
- Use: core. Modules: 23.

**Why it belongs:** Hidden forum text made a browser agent read account settings, request a one-time code, read it from email and post it back; explains why same-origin policy does not help when the agent holds the session.

**Do this after reading/watching:** Trace the chain with Module 05's five parts and mark which of the four structural controls breaks each step.

**Limits:** Brave ships a competing browser; a post-publication update disputes whether the class was fully fixed.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B17

**[Unseeable prompt injections in screenshots: more vulnerabilities in Comet and other AI browsers](https://brave.com/blog/unseeable-prompt-injections/)**

- Creator/source: Brave.
- Published: 2025-10-21.
- Use: recommended. Modules: 23, 05.

**Why it belongs:** Faint text survives a user screenshot, is recognized, and lands in the model as if it were user intent. Direct evidence for Module 23's claim that pixels are text.

**Do this after reading/watching:** Render one of your Module 23 hostile pages to an image and check whether your text-only controls would have seen the carrier.

**Limits:** Same vendor-competitor bias as B16; fix status not stated. Commentary by Willison at simonwillison.net/2025/Oct/21/unseeable-prompt-injections/.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B18

**[ZombAIs: From Prompt Injection to C2 with Claude Computer Use](https://embracethered.com/blog/posts/2024/claude-computer-use-c2-the-zombais-are-coming/)**

- Creator/source: Johann Rehberger / Embrace The Red.
- Published: 2024-10-24.
- Use: recommended. Modules: 23, 12.

**Why it belongs:** A web page tells a computer-use agent to download and run a 'support tool'; the host joins an attacker's command channel. The canonical computer-use-to-malware case.

**Do this after reading/watching:** Name the egress and execution controls from Module 12 that would have stopped each of the three steps.

**Limits:** Beta-period demonstration from 2024; the vendor's documentation already warned of it.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B19

**[Cross-Agent Privilege Escalation: When Agents Free Each Other](https://embracethered.com/blog/posts/2025/cross-agent-privilege-escalation-agents-that-free-each-other/)**

- Creator/source: Johann Rehberger / Embrace The Red.
- Published: 2025-09-24.
- Use: core. Modules: 24, 22.

**Why it belongs:** A hijacked coding agent writes a malicious server into a second agent's configuration; the second then loosens the first. Concrete agent-to-agent propagation on one developer machine.

**Do this after reading/watching:** Draw the two agents' configuration files as a graph and mark which writes Module 22's scanner would catch and which Module 24's attenuation would prevent.

**Limits:** Single-researcher demonstration; one vendor declined immediate servicing, so behaviour may persist.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B20

**[Defeating Prompt Injections by Design (CaMeL)](https://arxiv.org/abs/2503.18813)**

- Creator/source: Debenedetti et al. / Google DeepMind, Google, ETH Zurich.
- Published: 2025-03-24.
- Use: core. Modules: 05, 24.

**Why it belongs:** A privileged model compiles the trusted request into a restricted program; a quarantined model parses untrusted data; an interpreter tracks capabilities per value and enforces policy at each tool call.

**Do this after reading/watching:** Write the capability tags your capstone's executor would need on retrieved text, and the one policy check that would stop Module 05's forged note.

**Limits:** Assumes the user prompt is trusted and needs user-written policies; does not stop text-only manipulation of the answer.

**Verification:** arXiv abstract page fetched; full paper not read. Checked 2026-11-03.

### B21

**[The Dual LLM pattern for building AI assistants that can resist prompt injection](https://simonwillison.net/2023/Apr/25/dual-llm-pattern/)**

- Creator/source: Simon Willison.
- Published: 2023-04-25.
- Use: recommended. Modules: 05.

**Why it belongs:** Privileged model with tools, quarantined model with none, and a non-model controller passing variable references rather than text; the author's own later critique explains the flaw CaMeL fixed.

**Do this after reading/watching:** State in one sentence why a quarantined output can still carry an attacker-chosen value into an argument.

**Limits:** Historical; read as the precursor to B20.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B22

**[Our framework for developing safe and trustworthy agents](https://www.anthropic.com/news/our-framework-for-developing-safe-and-trustworthy-agents)**

- Creator/source: Anthropic.
- Published: 2025-08-04.
- Use: recommended. Modules: 24, 04.

**Why it belongs:** Five principles (human control, transparency, value alignment, cross-context privacy, secure interactions) with concrete coding-agent examples such as read-only defaults and approval before changes.

**Do this after reading/watching:** Map each principle to the course module that tests it, and note which principle has no test in your capstone.

**Limits:** Vendor principles, not independent assurance; B04 is the OpenAI counterpart.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B23

**[Prompt Infection: LLM-to-LLM Prompt Injection within Multi-Agent Systems](https://arxiv.org/abs/2410.07283)**

- Creator/source: Donghyun Lee, Mo Tiwari.
- Published: 2024-10-09.
- Use: core. Modules: 24.

**Why it belongs:** A self-replicating prompt that hijacks a task, performs a role-appropriate action, and copies itself to the next agent; proposes origin tagging as a partial defense.

**Do this after reading/watching:** Run Module 24's worked example and report how many hops the propagation instruction survived in your pipeline.

**Limits:** 2024 models in a simulated setting; headline success rates not verified here.

**Verification:** arXiv abstract page fetched; full paper not read. Checked 2026-11-03.

### B24

**[Open Challenges in Multi-Agent Security](https://arxiv.org/abs/2505.02077)**

- Creator/source: Schroeder de Witt et al..
- Published: 2025-05-04.
- Use: optional. Modules: 24.

**Why it belongs:** A position paper defining multi-agent security as a field: collusion, swarm attacks, contagion, and the security-utility trade-off.

**Do this after reading/watching:** Pick one open challenge and write why the course's hop-attenuation control does or does not address it.

**Limits:** Survey, not an attack reproduction.

**Verification:** arXiv abstract page fetched; full paper not read. Checked 2026-11-03.

### B25

**[Bypassing LLM Guardrails: An Empirical Analysis of Evasion Attacks](https://arxiv.org/abs/2504.11168)**

- Creator/source: Hackett et al. (Mindgard / Lancaster).
- Published: 2025-04-15.
- Use: recommended. Modules: 17.

**Why it belongs:** Character-level and adversarial perturbations evading six guardrails, including commercial ones, at high rates while preserving the attack.

**Do this after reading/watching:** Add three character-perturbed variants to Module 17's guardrail case set and report the change in detection rate.

**Limits:** Vendor-affiliated authors; guardrail versions have since changed.

**Verification:** arXiv abstract page fetched; full paper not read. Checked 2026-11-03.

### B26

**[MCP Security Notification: Tool Poisoning Attacks](https://invariantlabs.ai/blog/mcp-security-notification-tool-poisoning-attacks)**

- Creator/source: Invariant Labs.
- Published: 2025-04-01.
- Use: core. Modules: 10.

**Why it belongs:** Instructions hidden in tool descriptions, invisible to the user, make the agent read a private key and pass it in an extra argument; also introduces tool shadowing across servers.

**Do this after reading/watching:** In Module 10's lab, change a tool description and confirm your digest check disables execution.

**Limits:** Vendor research tied to a product; the mechanism is general.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B27

**[Agentic Browser Security and the lethal trifecta: Supabase MCP](https://simonwillison.net/2025/Jul/06/supabase-mcp-lethal-trifecta/)**

- Creator/source: Simon Willison.
- Published: 2025-07-06.
- Use: recommended. Modules: 10, 11.

**Why it belongs:** An agent running with a service role that bypassed row-level security dumped an integration-tokens table because a support ticket told it to.

**Do this after reading/watching:** Name which principal's authority the executor carried and which Module 02 rule that violated.

**Limits:** Secondary write-up of a third party's finding; the underlying post is linked from it.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B28

**[Taxonomy of failure modes in agentic AI systems, v2.0](https://www.microsoft.com/en-us/security/blog/?p=147942)**

- Creator/source: Microsoft.
- Published: 2026-06-04.
- Use: recommended. Modules: 23, 24, 04.

**Why it belongs:** Adds seven categories to the 2025 taxonomy, including agentic supply-chain compromise, inter-agent trust escalation, computer-use visual attacks and capability disclosure.

**Do this after reading/watching:** Map your capstone threat records onto the taxonomy and note any category with no record.

**Limits:** Vendor taxonomy; useful as a checklist, not as a standard.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### B29

**[AI Act: regulatory framework for AI](https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai)**

- Creator/source: European Commission.
- Published: 2026-10-19.
- Use: core. Modules: 19.

**Why it belongs:** The authoritative dates after the 2026 Omnibus: general-purpose obligations since August 2025, transparency from August 2026, high-risk from December 2027.

**Do this after reading/watching:** Add one line to your risk register naming the tier you believe applies to your capstone and who decided.

**Limits:** A policy summary, not the legal text; consult EUR-Lex for article wording.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### Labs, tools and model cards, version 1.2

### L01

**[Web LLM attacks: topic and hosted labs](https://portswigger.net/web-security/llm-attacks)**

- Creator/source: PortSwigger Web Security Academy.
- Published: undated; status recorded at the check.
- Use: core. Modules: 05, 21.

**Why it belongs:** Hosted labs for direct and indirect injection, excessive agency, insecure output handling and training-data leakage, with the model hosted for you.

**Do this after reading/watching:** Complete the indirect-injection lab, then write the trace and say which course control would have blocked the effect.

**Limits:** Free account needed; live model so results vary; the topic page was already in the sources, the labs are the new item.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L02

**[Gandalf and Agent Breaker](https://play.lakera.ai/agent-breaker)**

- Creator/source: Lakera (now part of Check Point).
- Published: undated; status recorded at the check.
- Use: optional. Modules: 21.

**Why it belongs:** A browser-hosted extraction game with escalating defenses and newer agentic scenarios; no API key.

**Do this after reading/watching:** Play three levels and for each name whether the defense you beat was a prompt, a classifier, or a boundary.

**Limits:** The classic URL now redirects here; product status after the 2025 acquisition is unclear, so re-check before assigning.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L03

**[HackAPrompt tutorial track](https://www.hackaprompt.com/track/tutorial_competition)**

- Creator/source: HackAPrompt / Learn Prompting.
- Published: undated; status recorded at the check.
- Use: optional. Modules: 21.

**Why it belongs:** Nine guided lessons with live-model challenges covering injection, prompt leaking, a simple defense, tokens and judges.

**Do this after reading/watching:** After the tokens lesson, explain why a character filter and the model can disagree about what was read.

**Limits:** Sign-up required; competition side is gamified and sponsored.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L04

**[promptfoo: red-team quickstart and Ollama provider](https://www.promptfoo.dev/docs/red-team/quickstart/)**

- Creator/source: promptfoo.
- Published: undated; status recorded at the check.
- Use: core. Modules: 17, 21.

**Why it belongs:** Scans a local endpoint (Ollama, llama.cpp, vLLM) with generated attack cases; the provider page documents local grading so a run needs no hosted key.

**Do this after reading/watching:** Run a scan against your Module 21 endpoint with a local grader and compare its labels to your executor outcomes.

**Limits:** Attack generation defaults to a hosted provider unless reconfigured; 0.125.1 at the check.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L05

**[Inspect: an evaluation framework from the UK AI Security Institute](https://inspect.aisi.org.uk/)**

- Creator/source: UK AISI.
- Published: undated; status recorded at the check.
- Use: recommended. Modules: 17, 21.

**Why it belongs:** Tasks, scorers, tools and sandboxed agent evaluation; the tutorial builds a capture-the-flag agent in a container.

**Do this after reading/watching:** Rewrite Module 21's thirty cases as an Inspect task with your executor's state check as the scorer.

**Limits:** Examples use hosted models; check the providers page for local backends. 0.3.287 at the check.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L06

**[PyRIT 1.x documentation](https://microsoft.github.io/PyRIT/)**

- Creator/source: Microsoft.
- Published: undated; status recorded at the check.
- Use: recommended. Modules: 17.

**Why it belongs:** Current documentation for the 1.x release line; the repository moved to microsoft/PyRIT in March 2026.

**Do this after reading/watching:** Reproduce one V06 step with the 1.x API and note what changed.

**Limits:** Version 1.0 removed pre-1.0 APIs and changed the memory schema, so commands in V06 no longer match.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L07

**[garak documentation](https://docs.garak.ai/garak)**

- Creator/source: NVIDIA.
- Published: undated; status recorded at the check.
- Use: recommended. Modules: 17.

**Why it belongs:** Probe-driven scanning against local Hugging Face targets and REST endpoints.

**Do this after reading/watching:** Select two probe families explicitly, run them against your local model, and manually validate three hits against backend state.

**Limits:** Defaults run all probes; docs are marked work in progress. 0.17.1 at the check.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L08

**[Ollama API reference](https://docs.ollama.com/api)**

- Creator/source: Ollama.
- Published: undated; status recorded at the check.
- Use: core. Modules: 21, 23, 24.

**Why it belongs:** The chat and generate endpoints on localhost:11434, streaming versus single responses, tool calling, and an OpenAI-compatible base path.

**Do this after reading/watching:** Change Module 21's worked example to use the OpenAI-compatible path and confirm identical outcomes.

**Limits:** The API is not strictly versioned and the docs were migrating at the check; an older copy lives in the GitHub repository.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L09

**[AgentDojo](https://github.com/ethz-spylab/agentdojo)**

- Creator/source: ETH Zurich SPY Lab.
- Published: undated; status recorded at the check.
- Use: recommended. Modules: 21, 24.

**Why it belongs:** The standard benchmark of paired utility and attack tasks for tool-using agents, used by CaMeL and the design-patterns paper.

**Do this after reading/watching:** Run one task suite against your local model and report utility and attack rates separately with denominators.

**Limits:** No tagged releases; results depend on model and version.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L10

**[Llama Prompt Guard 2 model card](https://huggingface.co/meta-llama/Llama-Prompt-Guard-2-86M)**

- Creator/source: Meta.
- Published: undated; status recorded at the check.
- Use: recommended. Modules: 17.

**Why it belongs:** A small injection classifier with published recall at a stated false-positive rate and an explicit warning that adaptive attackers can evade it.

**Do this after reading/watching:** Read the reported numbers as Module 16 would: what set, what denominator, what base rate.

**Limits:** Gated download; vendor-set benchmark.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L11

**[AI Gateway rate limiting](https://developers.cloudflare.com/ai-gateway/features/rate-limiting/)**

- Creator/source: Cloudflare.
- Published: undated; status recorded at the check.
- Use: optional. Modules: 12.

**Why it belongs:** A concrete worked example of request limits with fixed and sliding windows and 429 behaviour.

**Do this after reading/watching:** Specify the limit, window and principal key your capstone would use, and say why requests alone do not bound spend.

**Limits:** Counts requests not tokens; vendor documentation.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

### L12

**[A2A protocol: enterprise-ready features](https://a2a-protocol.org/latest/topics/enterprise-ready/)**

- Creator/source: A2A project / Linux Foundation.
- Published: undated; status recorded at the check.
- Use: recommended. Modules: 24.

**Why it belongs:** How the protocol delegates authentication to HTTP, OAuth and OpenID Connect, with per-skill scopes and an agent-card security field.

**Do this after reading/watching:** Answer Module 24's four review questions for this protocol using only this page, then compare with the A2ABreak findings.

**Limits:** Spec version not shown; identity provisioning and card trust are left to implementers.

**Verification:** Page fetched and read in full during the version 1.2 research pass. Checked 2026-11-03.

## Version 1.3 additions: first principles and conference recordings

Added 3 November 2026. V24-V29 are Andrej Karpathy's lectures that build a language model from scratch; V30-V33 are the 3Blue1Brown visual chapters; V34-V38 are short explainers and foundations for Modules 01, 02, 03 and 05; V39-V43 are conference and primary-source recordings for Modules 06, 08, 10, 18 and 19.

### Videos, version 1.3

### V24

**[[1hr Talk] Intro to Large Language Models](https://www.youtube.com/watch?v=zjkBMFhNj_g)**

- Creator/source: Andrej Karpathy.
- Published: 2023-11. Duration: about 1 h.
- Use: core. Modules: 03.

**Why it belongs:** The whole pipeline in one hour: weights as a file, pretraining as compression, fine-tuning as a format, and why there is no trusted channel. The entry point to the first-principles map.

**Do this after reading/watching:** Write stages 1 to 8 of Module 03's build section in your own words, one line each, with the security consequence of each.

**Limits:** A 2023 overview; model names, sizes and the "LLM OS" framing are dated, the mechanics are not.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Duration from the creator's course page (karpathy.ai/zero-to-hero); publish date from secondary listings, approximate to the month. Checked 2026-11-03.

### V25

**[Let's build GPT: from scratch, in code, spelled out.](https://www.youtube.com/watch?v=kCc8FmEb1nY)**

- Creator/source: Andrej Karpathy.
- Published: 2023-01. Duration: 1 h 56 m.
- Use: core. Modules: 03.

**Why it belongs:** Builds a small transformer from a bigram model up, with code: tokens to vectors, attention as weighted mixing over the window, logits to a distribution. This is the mechanism behind principles 5, 6 and 9.

**Do this after reading/watching:** After watching, extend the course's sixty-line model to condition on two tokens and explain which part of the lecture replaces that lookup.

**Limits:** Uses PyTorch and a GPU-free toy scale; the course lab stays standard-library. Watch for the mechanism, not to reproduce.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Duration from the creator's course page (karpathy.ai/zero-to-hero); publish date from secondary listings, approximate to the month. Checked 2026-11-03.

### V26

**[Let's build the GPT Tokenizer](https://www.youtube.com/watch?v=zduSFxRajkE)**

- Creator/source: Andrej Karpathy.
- Published: 2024-02. Duration: 2 h 13 m.
- Use: recommended. Modules: 03, 05.

**Why it belongs:** Byte-pair encoding from scratch and a catalogue of tokenizer-caused oddities. Explains why a character-level filter and the model disagree about what was read.

**Do this after reading/watching:** Take one injection payload from Module 05 and produce three encodings (spacing, confusables, base64); say which a token-level check would still catch.

**Limits:** Long and detailed; the first forty minutes carry most of the security-relevant content.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Duration from the creator's course page (karpathy.ai/zero-to-hero); publish date from secondary listings, approximate to the month. Checked 2026-11-03.

### V27

**[Let's reproduce GPT-2 (124M)](https://www.youtube.com/watch?v=l8pRSuU81PU)**

- Creator/source: Andrej Karpathy.
- Published: 2024-06. Duration: about 4 h.
- Use: optional. Modules: 15, 03.

**Why it belongs:** A full training run end to end: dataset download, checkpoints, evaluation, cost. Shows where the artefacts in Module 15's supply chain come from.

**Do this after reading/watching:** List every file the run produces or depends on (data shards, tokenizer, checkpoints, eval sets) and mark which would need a hash, a signature, or both in a promotion gate.

**Limits:** Four hours of engineering detail; skim to the data-loading and checkpoint sections unless you intend to train.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Duration from the creator's course page (karpathy.ai/zero-to-hero); publish date from secondary listings, approximate to the month. Checked 2026-11-03.

### V28

**[The spelled-out intro to neural networks and backpropagation: building micrograd](https://www.youtube.com/watch?v=VMj-3S1tku0)**

- Creator/source: Andrej Karpathy.
- Published: 2022-08. Duration: 2 h 25 m.
- Use: core. Modules: 14.

**Why it belongs:** Gradients and backpropagation built in about a hundred lines of Python. The same gradient that trains a model, taken with respect to the input, finds adversarial examples.

**Do this after reading/watching:** Using the lecture's scalar autograd idea, write down the gradient of a tiny model's loss with respect to its input and explain the sign of the adversarial step in Module 14.

**Limits:** No security content; this is the mathematics the module relies on.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Duration from the creator's course page (karpathy.ai/zero-to-hero); publish date from secondary listings, approximate to the month. Checked 2026-11-03.

### V29

**[The spelled-out intro to language modeling: building makemore](https://www.youtube.com/watch?v=PaCmpygFfXo)**

- Creator/source: Andrej Karpathy.
- Published: 2022-09. Duration: 1 h 57 m.
- Use: optional. Modules: 03.

**Why it belongs:** A count-based bigram model, then a trained one, with sampling and loss. It is the same idea as Module 03's sixty-line model taken one step further.

**Do this after reading/watching:** Compare the lecture's bigram counts to the course model's and explain why "training data is the behaviour" (principle 2) holds for both.

**Limits:** Character-level names, not text; optional unless the lecture format is new to you.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Duration from the creator's course page (karpathy.ai/zero-to-hero); publish date from secondary listings, approximate to the month. Checked 2026-11-03.

### V30

**[But what is a neural network? | Deep learning chapter 1](https://www.youtube.com/watch?v=aircAruvnKk)**

- Creator/source: 3Blue1Brown.
- Published: 2017-10-05. Duration: 19 m.
- Use: core. Modules: 14.

**Why it belongs:** The visual introduction to layers, weights and activations that Module 14's geometry section assumes.

**Do this after reading/watching:** Sketch the decision boundary idea on paper, then mark where a small input change crosses it.

**Limits:** Classic explainer; no language-model content.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Publish date from the lesson page on 3blue1brown.com; duration approximate. Checked 2026-11-03.

### V31

**[Gradient descent, how neural networks learn | Deep Learning Chapter 2](https://www.youtube.com/watch?v=IHZwWFHWa-w)**

- Creator/source: 3Blue1Brown.
- Published: 2017-10-16. Duration: 21 m.
- Use: core. Modules: 14.

**Why it belongs:** Loss as a landscape and gradient descent as walking downhill, the intuition behind both training and evasion.

**Do this after reading/watching:** Explain in two sentences why an attacker minimising a different loss over the input is doing "the same thing" as training.

**Limits:** Explainer only; pair with V28 for the code.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Publish date from the lesson page on 3blue1brown.com; duration approximate. Checked 2026-11-03.

### V32

**[Backpropagation, intuitively | Deep Learning Chapter 3](https://www.youtube.com/watch?v=Ilg3gGewQ5U)**

- Creator/source: 3Blue1Brown.
- Published: 2017-11-03. Duration: 13 m.
- Use: optional. Modules: 14.

**Why it belongs:** How the gradient is computed layer by layer; useful if V28 moves too fast.

**Do this after reading/watching:** None required; watch if the chain of gradients in V28 was unclear.

**Limits:** Explainer only.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Publish date from the lesson page on 3blue1brown.com; duration approximate. Checked 2026-11-03.

### V33

**[How might LLMs store facts | Deep Learning Chapter 7](https://www.youtube.com/watch?v=9-Jl0dxWQs8)**

- Creator/source: 3Blue1Brown.
- Published: 2024-08-31. Duration: 23 m.
- Use: recommended. Modules: 13.

**Why it belongs:** Where facts live in a transformer (the feed-forward layers) and why they are stored as directions, not records. Background for memorisation and extraction in Module 13.

**Do this after reading/watching:** Relate the storage picture to V09: why would a repeated, rare sequence be more recoverable than a common fact?

**Limits:** Interpretability is an open field; the video presents one well-supported picture, not a settled mechanism.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Publish date from the lesson page on 3blue1brown.com; duration approximate. Checked 2026-11-03.

### V34

**[Glitch Tokens - Computerphile](https://www.youtube.com/watch?v=WO2X3oZEJOA)**

- Creator/source: Computerphile (Rob Miles).
- Published: 2023. Duration: about 19 m.
- Use: recommended. Modules: 03, 05.

**Why it belongs:** A concrete demonstration that the tokenizer and the model are separate artefacts trained on different data, and that rare tokens produce erratic behaviour.

**Do this after reading/watching:** Explain why a filter that scans characters cannot anticipate these inputs, and what a token-level budget would see instead.

**Limits:** Describes behaviour of 2023 models; specific glitch tokens have since been fixed, the mechanism remains.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Publish date and duration from secondary listings, approximate. Checked 2026-11-03.

### V35

**[Why Does AI Lie, and What Can We Do About It?](https://www.youtube.com/watch?v=w65p_IIp6JY)**

- Creator/source: Robert Miles AI Safety.
- Published: 2022-12. Duration: about 10 m.
- Use: recommended. Modules: 03, 16.

**Why it belongs:** Ten minutes on why the training objective rewards plausibility rather than truth, which is principle 8 and the reason the course insists on an execution oracle.

**Do this after reading/watching:** Give one example from your own lab where a model-produced claim would need a state check to confirm.

**Limits:** Alignment-research framing from 2022; the objective argument is unchanged.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Publish date and duration from secondary listings, approximate. Checked 2026-11-03.

### V36

**[Attacking LLM - Prompt Injection](https://www.youtube.com/watch?v=Sv5OLj2nVAQ)**

- Creator/source: LiveOverflow.
- Published: 2023-04. Duration: about 13 m.
- Use: core. Modules: 05, 21.

**Why it belongs:** A short, hands-on demonstration of direct and indirect injection against a real application, from a channel known for careful reproduction.

**Do this after reading/watching:** Reproduce the structure, not the target: point the same idea at your Module 21 local model and record the trace.

**Limits:** 2023 target and model; techniques are illustrative. Never test against systems you do not own.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Publish date and duration from secondary listings, approximate. Checked 2026-11-03.

### V37

**[Python Tutorial: Unit Testing Your Code with the unittest Module](https://www.youtube.com/watch?v=6tNS--WetLI)**

- Creator/source: Corey Schafer.
- Published: 2017-11. Duration: 39 m.
- Use: core. Modules: 01.

**Why it belongs:** The testing idiom Module 01 and the reference lab use: test cases, assertions, set-up and tear-down, and why tests must be independent of each other.

**Do this after reading/watching:** Write the Module 01 state-based test from the video's template, then add the negative control.

**Limits:** Python 3.6-era; the unittest API shown is unchanged, but prefer pathlib and f-strings in your own code.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Publish date and duration from secondary listings, approximate. Checked 2026-11-03.

### V38

**[OAuth 2.0 and OpenID Connect (in plain English)](https://www.youtube.com/watch?v=996OiexHze0)**

- Creator/source: OktaDev (Nate Barbettini).
- Published: 2018-02. Duration: about 1 h 2 m.
- Use: core. Modules: 02, 10.

**Why it belongs:** The clearest explanation of the parties, flows and scopes in delegated authorisation, which Module 02 assumes and Module 10's MCP authorisation layer reuses.

**Do this after reading/watching:** Map each OAuth party to a component in the capstone (user, MCP client, MCP server, resource) and write the scope you would issue per tool.

**Limits:** From 2018: predates PKCE-by-default and the newer MCP authorisation specification; read the current spec (Module 10 sources) for details.

**Verification:** Title and channel confirmed through YouTube's public oEmbed endpoint on 2026-11-03; recording not watched in full. Publish date and duration from secondary listings, approximate. Checked 2026-11-03.

### V39

**[BSidesSF 2025 - GenAI Application Security: Not Just Prompt Injection (Ahmed Abugharbia)](https://www.youtube.com/watch?v=S0Z4gZGbC5k)**

- Creator/source: Security BSides San Francisco.
- Published: 2025. Duration: conference slot, about 45 m.
- Use: recommended. Modules: 06, 08.

**Why it belongs:** A practitioner talk on the application-layer failures around a model, which is the Module 06 and 08 argument that retrieval and tool boundaries, not the prompt, decide the outcome.

**Do this after reading/watching:** List each failure class the speaker names and mark which course control (retrieval filter, executor, schema, budget) addresses it.

**Limits:** Indexed from title and schedule only; the abstract was not published on the schedule page. Treat specific product claims as the speaker's.

**Verification:** Video id taken from the Security Boulevard repost of the organisers' recording and confirmed through YouTube's public oEmbed endpoint (channel: Security BSides San Francisco) on 2026-11-03; talk slot and speakers from the BSidesSF 2025 schedule; duration not captured; recording not watched in full. Checked 2026-11-03.

### V40

**[BSidesSF 2025 - When AI Goes Awry: Responding to AI Incidents (Eoin Wickens, Marta Janus)](https://www.youtube.com/watch?v=jaJWjHS1jkI)**

- Creator/source: Security BSides San Francisco.
- Published: 2025. Duration: conference slot, about 45 m.
- Use: core. Modules: 18.

**Why it belongs:** Incident response for AI systems: weak logging, visibility and accountability, a RAG-enabled assistant case, and triage strategies. The talk Module 18 was missing.

**Do this after reading/watching:** Write the three log fields the speakers say were missing in their case, then check that your capstone's action events carry them.

**Limits:** Vendor researchers (HiddenLayer); the case is illustrative, not an independent reproduction.

**Verification:** Video id taken from the Security Boulevard repost of the organisers' recording and confirmed through YouTube's public oEmbed endpoint (channel: Security BSides San Francisco) on 2026-11-03; talk slot and speakers from the BSidesSF 2025 schedule; duration not captured; recording not watched in full. Checked 2026-11-03.

### V41

**[BSidesSF 2025 - AI's Bitter Lesson for SOCs: Let Machines Be Machines (Jackie Bow, Peter Sanford)](https://www.youtube.com/watch?v=JRvQGRqMazA)**

- Creator/source: Security BSides San Francisco.
- Published: 2025. Duration: conference slot, about 45 m.
- Use: optional. Modules: 18.

**Why it belongs:** Where automation helps and hurts in detection and response; context for Module 18's base-rate argument about AI-generated alerts.

**Do this after reading/watching:** State the base-rate problem from Module 18 in the talk's terms.

**Limits:** Opinion talk from practitioners; use for framing, not for metrics.

**Verification:** Video id taken from the Security Boulevard repost of the organisers' recording and confirmed through YouTube's public oEmbed endpoint (channel: Security BSides San Francisco) on 2026-11-03; talk slot and speakers from the BSidesSF 2025 schedule; duration not captured; recording not watched in full. Checked 2026-11-03.

### V42

**[Security in Model Context Protocol: An Analysis of the OWASP MCP Top 10](https://www.wearedevelopers.com/videos/1957-security-in-model-context-protocol-an-analysis-of-the-owasp-mcp-top-10)**

- Creator/source: WeAreDevelopers World Congress (Jose Manuel Ortega).
- Published: 2026-07-02. Duration: 48 m 46 s.
- Use: core. Modules: 10.

**Why it belongs:** A walk through the OWASP MCP Top 10 categories with hardening guidance, the recording Module 10 lacked.

**Do this after reading/watching:** For each category, name the Module 10 control that addresses it and mark the two the reference lab cannot demonstrate.

**Limits:** Hosted on the conference site, not YouTube; page lists the session date, duration from the site's listing. The MCP Top 10 is a living document.

**Verification:** Conference video page fetched on 2026-11-03: title, speaker and session date confirmed; duration from the site listing; recording not watched in full. Checked 2026-11-03.

### V43

**[Introduction to the NIST AI Risk Management Framework (AI RMF 1.0): An Explainer Video](https://www.nist.gov/video/introduction-nist-ai-risk-management-framework-ai-rmf-10-explainer-video)**

- Creator/source: NIST.
- Published: 2023-01-26. Duration: short explainer.
- Use: core. Modules: 19.

**Why it belongs:** The framework's own short explanation of its four functions (govern, map, measure, manage), from the primary source.

**Do this after reading/watching:** Place each Module 19 deliverable under one of the four functions.

**Limits:** 2023 release; the generative-AI profile (2024) and later updates are not covered. Hosted on nist.gov.

**Verification:** NIST video page fetched on 2026-11-03: title and date confirmed; duration not listed; recording not watched in full. Checked 2026-11-03.

## Version 1.4 additions: archive recordings and hands-on targets

Added 3 November 2026. V44-V47 are DEF CON talks served from the conference's own media archive (media.defcon.org), which publishes every main-stage recording with slides; they give Module 15 its model-file demonstrations and Module 07 a practitioner recording. L13 and L14 are the two [hands-on targets](targets/README.md) with graders. No PoisonedRAG (USENIX Security 2025) recording exists on the USENIX presentation page as of this check; Module 07 keeps the paper as its primary source.

### Videos and targets, version 1.4

### V44

**[DEF CON 30 - Backdooring Pickles: A decade only made things worse (ColdwaterQ)](https://media.defcon.org/DEF%20CON%2030/DEF%20CON%2030%20video%20and%20slides/DEF%20CON%2030%20-%20ColdwaterQ%20-%20Backdooring%20Pickles%20-%20A%20decade%20only%20made%20things%20worse.mp4)**

- Creator/source: DEF CON (speaker: ColdwaterQ, NVIDIA).
- Published: 2022-08. Duration: about 20 min.
- Slides: [PDF in the DEF CON archive](https://media.defcon.org/DEF%20CON%2030/DEF%20CON%2030%20presentations/ColwaterQ%20-%20Backdooring%20Pickles%20A%20decade%20only%20made%20things%20worse.pdf).
- Use: core. Modules: 15.

**Why it belongs:** The talk that shows what a pickle actually is: a program for a stack machine, so a model file in that format is code. The Fickling tool from Trail of Bits is demonstrated. Twenty minutes, and the whole reason safetensors exists.

**Do this after reading/watching:** Before starting the model-loader target, write down the three ways the speaker gets code to run from a pickle, then map each to the fixture in targets/model_loader/fixtures.py that imitates it.

**Limits:** 2022 recording; scanner coverage and library defaults have moved since (torch.load's weights_only default changed in 2.6). The archive file name misspells the speaker's handle on the slides PDF.

**Verification:** DEF CON media archive: HTTP HEAD on 2026-11-03 returned 200, 24,595,977 bytes, last modified 2024-06-20. Title and 20-minute length from the DEF CON forum listing; the TIB AV-Portal mirror (DOI 10.5446/62194) records the CC BY 3.0 licence. Recording not watched in full. Checked 2026-11-03.

### V45

**[DEF CON 33 - Loading Models, Launching Shells: Abusing AI File Formats for Code Execution (Cyrus Parzian)](https://media.defcon.org/DEF%20CON%2033/DEF%20CON%2033%20video%20and%20slides/DEF%20CON%2033%20-%20Loading%20Models%2C%20Launching%20Shells%20-%20Abusing%20AI%20File%20Formats%20for%20Code%20Execution%20-%20Cyrus%20Parzian.mp4)**

- Creator/source: DEF CON (speaker: Cyrus Parzian).
- Published: 2025-08-10. Duration: about 20 min.
- Slides: [PDF in the DEF CON archive](https://media.defcon.org/DEF%20CON%2033/DEF%20CON%2033%20presentations/Cyrus%20Parzian%20-%20Loading%20Models%2C%20Launching%20Shells%20Abusing%20AI%20File%20Formats%20for%20Code%20Execution.pdf).
- Use: core. Modules: 15.

**Why it belongs:** Extends the pickle story to formats people assume are safe: ONNX, HDF5, Feather, YAML, JSON and NPZ, with a live demo of a chatbot executing attacker code at model load. The archive also holds the four demo clips and the slides.

**Do this after reading/watching:** List the formats the talk covers and, for each, whether the code path is the format itself or the library that loads it. Then explain why stage 1 of the model-loader target chooses the parser by policy rather than by sniffing bytes.

**Limits:** A twenty-minute talk; detection and hardening are summarised rather than demonstrated. Library versions at the time of the talk are not those you will install.

**Verification:** DEF CON media archive: HTTP HEAD on 2026-11-03 returned 200, 23,183,777 bytes, last modified 2025-10-06. Date, duration and abstract from the infocondb.org listing for DEF CON 33. Recording not watched in full. Checked 2026-11-03.

### V46

**[DEF CON 32 - When Chatbots Go Rogue: Lessons Learned from Building and Defending LLM Applications (Javan Rasokat, Andra Lezza)](https://media.defcon.org/DEF%20CON%2032/DEF%20CON%2032%20video%20and%20slides/DEF%20CON%2032%20-%20When%20Chatbots%20Go%20Rogue%20-%20Lessons%20Learned%20from%20Building%20and%20Defending%20LLM%20Applications%20-%20Javan%20RasokatAndra.mp4)**

- Creator/source: DEF CON (speakers: Javan Rasokat, Andra Lezza).
- Published: 2024-08. Duration: not stated.
- Use: recommended. Modules: 07, 06.

**Why it belongs:** A practitioner account of building and defending retrieval-backed assistants: where untrusted documents entered, what prompt injection and hallucination did to them, and what controls survived. The closest recording to Module 07's subject until a PoisonedRAG talk is published.

**Do this after reading/watching:** Note every control the speakers describe and sort it into the three Module 07 questions: integrity of bytes, authority to publish, and truth of content. Mark which ones the poisoned-corpus target exercises.

**Limits:** Duration is not stated in the archive listing. The talk is about application defence broadly, not retrieval poisoning specifically; the Module 07 reading (PoisonedRAG) remains the primary source for the attack.

**Verification:** DEF CON media archive: HTTP HEAD on 2026-11-03 returned 200, 36,486,384 bytes, last modified 2024-10-07. Title and speakers from the archive file name and the AppSec Village copy; topic summary from the speakers' Application Security Podcast episode description. Recording not watched in full. Checked 2026-11-03.

### V47

**[DEF CON 33 - Invitation Is All You Need: Invoking Gemini Agents with a Google Calendar Invite (Ben Nassi, Or Yair, Stav Cohen)](https://media.defcon.org/DEF%20CON%2033/DEF%20CON%2033%20video%20and%20slides/DEF%20CON%2033%20-%20Invitation%20Is%20All%20You%20Need%20Invoking%20Gemini%20Agents%20with%20a%20Google%20Calendar%20Invite%20-%20Ben%20Nassi%2C%20Or%20Yair%2C%20Stav%20Cohen.mp4)**

- Creator/source: DEF CON (speakers: Ben Nassi, Or Yair, Stav Cohen).
- Published: 2025-08. Duration: not stated.
- Slides: [PDF in the DEF CON archive](https://media.defcon.org/DEF%20CON%2033/DEF%20CON%2033%20presentations/Ben%20Nassi%20Or%20Yair%20%26%20Stav%20Cohen%20-%20Invitation%20Is%20All%20You%20Need%21%20Invoking%20Gemini%20for%20Workspace%20Agents%20with%20a%20Simple%20Google%20Calendar%20Invite.pdf).
- Use: recommended. Modules: 05, 21.

**Why it belongs:** Indirect prompt injection with a delayed trigger, against a deployed assistant with real tools: a calendar invite carries the payload, an ordinary later request fires it, and the effects reach smart-home devices. Fourteen scenarios, named 'promptware' by the authors.

**Do this after reading/watching:** Draw the data path from invite to device action and mark where each Module 05 control (eligibility, capability scoping, approval before effect) would have interrupted it. Then reproduce the delayed-trigger pattern against your Module 21 local model with synthetic data only.

**Limits:** Vendor mitigations were deployed before publication, so the specific paths are closed; the pattern is not. Duration is not stated in the archive listing.

**Verification:** DEF CON media archive: HTTP HEAD on 2026-11-03 returned 200, 54,000,698 bytes, last modified 2025-10-06. Title and speakers from the archive file name and the Thinkst citation listing for DEF CON 33; scenario details from press coverage of the SafeBreach, Tel Aviv University and Technion research. Recording not watched in full. Checked 2026-11-03.

### L13

**[Target: the poisoned corpus](targets/poisoned_corpus/README.md)**

- Creator/source: This course.
- Published: 2026-11-03.
- Use: core. Modules: 07.

**Why it belongs:** A vulnerable retrieval assistant and a five-stage grader: eligibility before ranking, one witness beats four copies, text is data, latest approved version only, revocation reaches the cache.

**Do this after reading/watching:** Predict the failures, run the vulnerable build, implement hardened.py until the grader prints all five flags, then write the three extra negative tests and the limits paragraph.

**Limits:** No embedding model and no language model; answer extraction is a regular expression over the top document. Module 21 repeats the exercise against a real local model.

**Verification:** Graders, vulnerable builds and reference solutions executed on 2026-11-03; fifteen target tests passed on Python 3.14 at the time; twenty-nine since version 1.5. Checked 2026-11-03.

### L14

**[Target: the model loader](targets/model_loader/README.md)**

- Creator/source: This course.
- Published: 2026-11-03.
- Use: core. Modules: 15.

**Why it belongs:** A loader that unpickles, trusts the adjacent checksum, extracts wherever member names point and believes a candidate's own approval flag, with a grader whose stage 1 is an in-memory canary.

**Do this after reading/watching:** Watch V44 and V45, predict the failures, run the vulnerable build, implement hardened.py until all five flags print, then write the trust-boundary narrative.

**Limits:** No signatures, registry or real serialisation library; the pickle payload only appends to a list.

**Verification:** Graders, vulnerable builds and reference solutions executed on 2026-11-03; the reference solution never trips the canary. Checked 2026-11-03.

## Version 1.5 additions: two more targets

Added 4 November 2026. L15 and L16 are the third and fourth [hands-on targets](targets/README.md): an MCP host for Module 10 and a multi-turn conversation guard with a supplied fuzzer for Module 17. They were chosen from a circulating list of "build your own" AI security projects as the two that the course taught but did not grade.

### L15

**[Target: the MCP host](targets/mcp_shield/README.md)**

- Creator/source: This course.
- Published: 2026-11-04.
- Use: core. Modules: 10.

**Why it belongs:** A host that exposes every announced tool, routes by bare name, forwards the upstream token, passes arguments through and executes a result's next_call, with a pin list the administrator wrote and a per-server token minter.

**Do this after reading/watching:** Predict the six failures, run the vulnerable build, implement hardened.py until all five flags print, then write the boundary narrative naming whose claim each stage stopped trusting.

**Limits:** No real transport, OAuth server or JSON Schema library; the schema checker covers five keywords.

**Verification:** Grader, vulnerable build and reference solution executed on 2026-11-04; the vulnerable build fails all five stages, the reference solution passes all five. Checked 2026-11-04.

### L16

**[Target: the multi-turn guard](targets/multi_turn/README.md)**

- Creator/source: This course.
- Published: 2026-11-04.
- Use: core. Modules: 17.

**Why it belongs:** A simulated assistant with a synthetic secret and a rapport counter, a supplied multi-turn fuzzer with mutations and benign controls, and a per-turn guard that passes every attack; the deliverable is a trajectory-level guard whose report matches the transcripts.

**Do this after reading/watching:** Predict which benign control is hardest to keep open, run the vulnerable build, implement hardened.py until all five flags print, add two attack sequences of your own, and write the paragraph on what a bypass rate over eight scripted sequences does and does not measure.

**Limits:** The assistant is regular expressions and a counter; a word-matching guard will fail against paraphrase in ways this target cannot show.

**Verification:** Grader, fuzzer, vulnerable build and reference solution executed on 2026-11-04; the per-turn guard shows a bypass rate of 1.00 with one false positive, the reference guard 0.00 with none. Checked 2026-11-04.
