# Module 09: Agent Memory, Approvals, and Workflow Integrity

## Prerequisites and learning objectives

You need Python dictionaries, exception assertions, and the distinction between authentication and authorization. Read the [reference-lab contract](../reference-lab/CONTRACT.md). Its trusted `Principal` fixtures represent authenticated callers; selecting a fixture is not authentication. The simulator has no language model, real email service, or network dependency.

By the end, you will be able to:

1. Demonstrate user-and-tenant memory isolation with positive, cross-user, and expiry tests.
2. Explain and test approval binding to actor, tenant, tool, canonical arguments, expiry, and single use.
3. Design a workflow that rejects stale approvals and describes its concurrency and failure boundaries.

Allocate **10 hours**: concepts 2, practice 5, evaluation 2, and writeup 1. Use the concept time to trace authority through a workflow, not just memorize attack names.

## Memory is stored evidence, not enduring permission

An agent's memory can be conversation history, saved preferences, summaries, or facts retrieved for later work. Persistence changes the threat model: one misleading input can influence multiple later sessions. Summarization does not remove that risk. A summary saying “the supervisor approved all future changes” is still a claim from a source, not an approval record.

Memory falls into three categories that need different handling: preferences, which influence presentation; historical observations, which inform reasoning and carry dates and provenance; and authorization state, which controls actions and belongs in a trusted policy component. An agent may remember that a user prefers concise responses, but it must not convert that preference into permission to skip review. A previously approved ticket change does not authorize another change.

Memory isolation must happen before retrieval. A shared key such as `preference` is safe only if the store also scopes it by trusted tenant and user. Filtering a merged conversation afterward is too late if foreign content has already entered a model context or response. The supplied memory store uses tenant-and-user scope. It does not implement a full production consent, retention, or deletion program.

Useful production memory records carry source, owner, observation time, expiry, sensitivity, and correction history. Store the minimum needed and make deletion meaningful across indexes, caches, and backups. An integrity digest can detect changed bytes relative to an approved digest, but cannot establish truthful content or authenticated authorship. Neither persistence nor a hash upgrades untrusted text into policy.

Two 2025 results sharpen the memory threat. First, a memory write is an action with persistence beyond the session, so an injection that merely schedules a write converts a later benign confirmation into an authorized effect: a document told one assistant to save false long-term memories only if the user later replied "yes," and the user, answering an unrelated question, did. Second, an attacker needs no write access to the store. Query-only memory injection (MINJA, 2025) plants records through ordinary interactions that the system itself chooses to remember. Treat memory writes as the same approval class as tool actions, attach provenance (which turn, which source) to every record, expire by default, and never let a record's content change the policy applied to it. The 2026 OWASP agentic list calls this memory and context poisoning.

## Approval is a capability for one exact action

Authentication answers who is calling. Authorization decides what that caller may do now. Approval adds independently established consent for a specific sensitive operation. All three checks matter. A reader cannot acquire write permission simply because somebody issued an approval, and an operator still needs approval for the simulator's sensitive tools.

The execution boundary must bind approval to the actor, tenant, tool, and validated canonical arguments. It also checks expiry and single use. The approver must have authority and be independent of the requesting actor. The simulator's approval issuer is a trusted local component, not a tool exposed to the agent. A model-generated `user_confirmed=True` is merely untrusted input.

Canonicalization means producing one agreed representation after schema validation. Dictionary key order should not distinguish equivalent requests. Unknown fields must not disappear silently, because the UI and executor could then disagree about what was approved. Normalize only semantics the application actually defines. Do not lowercase arbitrary free text or reinterpret recipients during execution.

The approval screen should show the consequential fields: target, requested change, actor, tenant, and destination where relevant. “Approve agent task” is too vague. The executor must use the same validated action the reviewer saw, not regenerate it from the conversation.

An approval token is only a capability if it cannot be guessed or forged. Generate it from a cryptographic random source with enough entropy, as the reference lab does with `secrets.token_urlsafe`, never from a counter, a timestamp, or a hash of visible fields. Store its digest rather than the token so a leaked registry does not yield usable approvals.

## TOCTOU and workflow state

A time-of-check-to-time-of-use flaw occurs when a checked action or environment changes before execution. Suppose a reviewer approves closing A-100, then a mutable arguments dictionary is changed to B-200. A check that only remembers “approved” will authorize the wrong operation, whereas a check that bound the approval to the exact arguments rejects the substitution.

Binding alone does not cover every stale-state problem. A ticket's contents or owner could change while approval waits. Recheck current resource authorization at execution, and, when the business decision depends on prior state, bind an expected version or snapshot digest. Version binding is an extension here, not a supplied simulator feature.

Check-and-consume must be atomic across all accepting workers. Otherwise two requests can both observe an unused approval. The reference implementation provides atomic consumption in one process, which is not the same as a distributed transaction system. For a real external effect, plan idempotency keys, transactional state transitions, and reconciliation, because consuming consent before a timeout does not tell you whether the remote action happened, and an uncertain effect must never be replayed silently.

A defensible workflow is proposed, validated, independently approved, execution-checked, consumed, and recorded. Reject out-of-order transitions. If arguments change, request new approval. A refusal, revoked privilege, unavailable policy service, or unknown tool should not become permission through an exception handler.

## Worked example: close only the reviewed ticket

Run this in `reference-lab` with Python 3.10 or newer:

```python
from aisec_lab.fixtures import make_lab
from aisec_lab.errors import PolicyDenied

s = make_lab()
alice = s.identities['alice']
supervisor = s.identities['supervisor']
args = {'ticket_id': 'A-100', 'status': 'closed'}
token = s.approvals.issue(
    actor=alice, approver=supervisor,
    tool='update_ticket', arguments=args, ttl_seconds=60)
s.run_tool(alice, 'update_ticket', args, approval=token)

try:
    s.run_tool(alice, 'update_ticket', args, approval=token)
except PolicyDenied:
    print('Replay rejected')
```

The first call should update the synthetic ticket, while reuse is denied. Read A-100 before and after to verify state rather than trusting printed text. Keep the opaque token out of logs and deliverables. This example assumes the trusted supervisor fixture is invoking the approval authority, so it demonstrates neither login nor a human approval interface.

## Safe lab: isolate memory and preserve action identity

**Setup.** Work only on synthetic fixtures. From `reference-lab`, run `python3 -m unittest discover -s tests -v` and record the baseline. Write your additional tests in a learner-owned copy, not against production. Fresh `make_lab()` instances prevent one negative case from consuming another case's approval.

**Practice steps, five hours.**

1. Save `concise` under Alice's `preference` using `s.memory.put(alice, 'preference', 'concise', ttl_seconds=60)`. Save Bob's different value under the same key. Retrieve through each principal. Add a same-tenant, different-user case using the reader fixture. Assert no value crosses either boundary; use the store's documented missing-value behavior rather than assuming an exception.
2. Store a synthetic historical claim that approval is unnecessary. Retrieve it as ordinary text, then call `update_ticket` without approval. The executor must still deny the action. This tests authority separation, not a language model's resistance to injection.
3. Build a successful approved update and verify the resulting ticket. Repeat with reordered dictionary keys to check canonical equivalence. Use separate approvals for separate cases.
4. Test changed status, changed ticket, different actor, different tool, missing approval, self-approval, and replay. Test Bob's B-200 request with an Alpha approval. Distinguish argument-validation errors from policy denials, and assert unchanged tickets and outbox after rejection.
5. Exercise approval and memory expiry using the existing expiry-test clock pattern, or patch the actual clock lookup with `unittest.mock` after inspecting its implementation. Advance beyond expiry without long sleeps. Add two contenders for one approval and verify that at most one operation is accepted within the supported single-process boundary.

**Expected observations and negative tests.** Valid memory and reviewed updates work. Historical text never disables policy. Mutated arguments cannot reuse approval, and expiry closes the authorization window. A synthetic scheduling test that does not exercise the atomic consume path is not concurrency evidence. Do not assert distributed correctness from this lab.

**Deliverables.** Submit executable tests, a short workflow-state diagram written in text, before/after assertions, and redacted audit-event excerpts. Explain which tests cover actor, tenant, tool, argument, time, and reuse binding. Propose one version-binding extension and one recovery rule for an uncertain external effect, clearly labeled unimplemented.

## Evaluation and mastery gate

Spend two hours reviewing failures and rerunning the complete suite, then one hour writing the report. Pass when valid work succeeds, every binding mutation fails without side effects, memory remains isolated, and you can explain why atomic single use is narrower than distributed exactly-once execution. A missing negative case or a memory-derived approval is a failed gate, not a documentation issue.

## Quiz

1. Why does a remembered supervisor statement not count as approval?
2. Which checks remain necessary after an opaque approval token is presented?
3. How does argument binding prevent one TOCTOU flaw, and what stale-state flaw remains?
4. Why can a timeout after consuming approval require reconciliation rather than an automatic retry?

Answers and reasoning are in the [instructor key](../instructor/answers-09-12.md). Continue to [MCP security](10-mcp-security.md).

## Primary-source readings

- [OWASP AI Agent Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html), especially Memory & Context Security and High-Impact Action Integrity Controls.
- [OWASP Transaction Authorization Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Transaction_Authorization_Cheat_Sheet.html), sections 1.1, 1.5, and 2.5-2.10 on meaningful review, single use, state transitions, and final execution checks.
- [OWASP Top 10 for Agentic Applications 2026](https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026), for the wider agentic risk taxonomy.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V07 DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](../MEDIA-LIBRARY.md#v07).
- Read: [B04 Designing AI agents to resist prompt injection](../MEDIA-LIBRARY.md#b04).
- Discuss/critique: [R06 Handling MCP authorization-boundary failures](../MEDIA-LIBRARY.md#r06).
- Optional short commentary: [X02 Design patterns for securing LLM agents: discussion and paper notes](../MEDIA-LIBRARY.md#x02).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
