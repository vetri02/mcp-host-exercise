# Module 15: Secure MLOps and the Model Supply Chain

## Prerequisites, objectives, and time

You need Python file handling, JSON, hashes, Git concepts, and the poisoning distinctions in [Module 14](14-adversarial-machine-learning.md). MLOps connects data preparation, training, evaluation, packaging, deployment, and monitoring. Security must follow artifacts across those transitions rather than treating a model file as an inert document.

By the end, you can:

1. Identify code-execution and integrity risks across a model's artifact and dependency graph.
2. Implement a fail-closed loader for a bounded synthetic JSON artifact pinned to independently approved bytes.
3. Design a release decision that combines provenance, evaluation, least privilege, and rollback without equating provenance with safety.

Budget 2 hours for concepts, 5 for practice, 2 for evaluation, and 1 for the writeup. Production signing services, registries, and orchestration are design extensions, not prebuilt features of this course.

## A model release is a dependency graph

An executable prediction depends on more than weights. It may require a tokenizer, vocabulary, preprocessing code, custom operators, adapters, configuration, native libraries, and a container image. Training also depends on data snapshots, labeling decisions, optimizer settings, and source revisions. Replacing any one of these can alter behavior even when the main weight file is unchanged.

Treat each graph edge as a trust boundary: who may publish the dependency, who resolves its version, who approves it, and what the consumer verifies. A mutable tag such as “latest” describes a lookup convention, not immutable identity. Pin content digests and retain enough metadata to reconstruct the exact release. A software bill of materials inventories components; it is not proof that they are vulnerability-free or appropriate for your workload.

Separate preparation, build, approval, and serving privileges. A training job should not automatically possess production deployment credentials. A registry writer should not be able to rewrite the consumer's approval policy. A server needs read access to approved artifacts, not authority to approve new ones. In the course's reference simulator, trusted identities are fixtures; real identity and access management remain separate engineering work.

## Unsafe deserialization is code execution, not merely bad predictions

Serialization converts an object into stored bytes. Some formats encode only values; others encode instructions for reconstructing arbitrary objects. Python's `pickle` supports callable reconstruction. Loading attacker-controlled pickle bytes can therefore invoke code before any prediction or safety test occurs. A familiar extension, download count, successful virus scan, or plausible model card does not make untrusted unpickling safe.

Do not inspect a suspicious model by loading it in your everyday Python process. Use documented data-only formats where suitable, disable remote/custom code loading unless specifically reviewed, and still validate schemas, sizes, types, and resource demands. Data-only does not mean harmless: malicious dimensions can exhaust memory, extreme values can break numerical operations, and a valid weight matrix can encode undesirable behavior.

Dependency installation is another execution boundary. Package build hooks, import-time code, native extensions, and model repository helper scripts may execute with your process privileges. A restricted sandbox reduces consequences but does not authenticate an artifact. Conversely, authenticating an artifact does not make executing its contents safe. These controls answer different questions.

## Provenance: which claim is actually verified?

A digest identifies bytes relative to an expected digest. If an attacker can replace both an artifact and its adjacent checksum file, the comparison proves little. The expected identity must come from an independently controlled source. A signature adds evidence that a key or identity endorsed particular bytes, but only if verification checks the expected signer, issuer or trust root, and intended artifact binding.

Provenance records describe how an artifact was produced. Useful fields include source revision, data snapshot identifiers, builder identity, parameters, dependencies, and output digests. Verification must compare these claims with consumer policy. “Signed” is insufficient if any signer is accepted or the approved builder can run an arbitrary unreviewed source revision. Authenticated metadata can still faithfully describe a compromised build or a harmful dataset.

Record evaluation evidence as a separate claim. A release could have valid provenance and fail targeted backdoor tests; another could pass a small test set but have unknown origin. Neither result should cancel the other. NIST's AI-specific SSDF profile connects these practices to the broader software lifecycle; SLSA provides a vocabulary for software provenance rather than certifying model behavior.

Two acronyms recur in this area and are worth defining once. SLSA is a ladder of build-integrity levels; its provenance attestation is a signed statement by the builder naming the source revision, the build recipe, and the output digests, so a consumer can check "built by X from Y" instead of trusting a filename. An SBOM, a software bill of materials, is the inventory of components those checks run against. Neither proves that a component is benign; they make "what is this and where did it come from" answerable.

## Worked example: bounded, pinned JSON

This loader uses a caller-supplied approval set as its trust anchor. It is an in-process policy fixture, not a production registry. The artifact describes two floating-point weights and no executable objects.

```python
import hashlib
import json
import math

def reject_constant(value):
    raise ValueError("nonstandard JSON constant")

def load_artifact(blob, approved):
    if not isinstance(blob, bytes) or len(blob) > 2048:
        raise ValueError("invalid artifact size or type")
    digest = hashlib.sha256(blob).hexdigest()
    if digest not in approved:
        raise ValueError("artifact is not approved")
    obj = json.loads(blob, parse_constant=reject_constant)
    if type(obj) is not dict or set(obj) != {"format", "weights"}:
        raise ValueError("unexpected schema")
    if obj["format"] != "toy-linear-v1":
        raise ValueError("unsupported format")
    values = obj["weights"]
    if type(values) is not list or len(values) != 2:
        raise ValueError("expected two weights")
    if any(type(v) is not float or not math.isfinite(v)
           or abs(v) > 100 for v in values):
        raise ValueError("invalid numeric values")
    return tuple(values)

blob = b'{"format":"toy-linear-v1","weights":[1.0,2.0]}'
approved = frozenset({hashlib.sha256(blob).hexdigest()})
assert load_artifact(blob, approved) == (1.0, 2.0)
```

The deliberate float-only contract rejects integers and booleans. The byte bound limits this fixture's input, not every possible parser resource risk. Validation is defense in depth after identity checking. The loader does not establish training-data legitimacy, predictive accuracy, or an absence of backdoors.

## Safe lab: a simulated release gate

### The target, version 1.4

Watch V44 and V45 first; they show the real versions of every fixture. The [model-loader target](../targets/model_loader/README.md) is the vulnerable counterpart of this lab: a loader that unpickles, trusts the adjacent checksum, extracts wherever archive member names point, and promotes a candidate on its own say-so. Run `python3 -m targets.model_loader.target` from the course root and read the canary list. Implement `hardened.py` until `python3 -m targets.model_loader.check` prints all five flags, then do the steps below with your loader in place of the worked example. Keep the written deliverables for Milestone D, which scores them.

### Setup

Use a disposable local directory and standard-library Python. Copy the loader and create an in-memory release record containing artifact digest, fictional builder `local-builder-A`, source revision `synthetic-rev-1`, data ID `synthetic-data-1`, evaluation ID `eval-1`, and approval status. These identifiers are labels, not attestations. Do not fetch packages, unpickle downloaded files, or use production credentials.

### Steps

1. Establish the clean artifact and freeze its digest in the consumer's approval set. Keep the approval function separate from the loader. A candidate must not approve itself.
2. Write a release-gate function requiring the approved digest, expected builder, source revision, evaluation ID, and explicit approval status. Reject missing fields. Record a short reason code, not raw artifact contents or credentials.
3. Modify one weight while leaving the original approval set unchanged. Then recompute an attacker-controlled adjacent checksum. Show that neither candidate passes the consumer's independently pinned identity check.
4. Test schema rejection independently by creating locally approved negative fixtures: wrong format, extra field, string weight, boolean weight, oversized bytes, and nonfinite values. Approval here is solely for testing the parser; it must not be interpreted as production approval of malformed models.
5. Maintain a current and previous approved release. Simulate a failed candidate evaluation and demonstrate that current serving identity remains unchanged. Then simulate an approved switch and rollback. Treat pointers as in-memory values; no production deployment takes place.
6. Optional: construct your own harmless pickle object whose reconstruction calls a function that appends a marker to an in-memory list. Execute it only locally with no filesystem, network, or shell effects. Explain why a callback during loading establishes an execution boundary, not a demonstration of a real malicious model.

### Expected observations and negative tests

Byte changes invalidate the original digest. An adjacent recomputed checksum does not change the independent approval set. A correctly pinned but malformed artifact fails schema validation. A failed release decision leaves the previous identity active. These are expected invariants to test, not claims of measured production security.

Also test correct bytes with an unexpected builder, an approved-looking record with no evaluation ID, and a record for a different artifact. Verify benign approved loading still works. Ensure failure paths cannot promote candidates accidentally. If you later implement signatures, include a cryptographically valid but untrusted-signer test; this chapter does not provide a signing service.

### Deliverables

Submit loader and gate code, negative-test logs, a release inventory, and a trust-boundary narrative. Include owner and recovery action for compromised data, builder, registry, and consumer policy. State which checks authenticate bytes, which constrain execution, and which evaluate behavior.

## Quiz

1. Why is an adjacent checksum insufficient when both files are attacker-controlled?
2. What risk arises before inference when an untrusted pickle is loaded?
3. Can valid provenance establish absence of a backdoor? Why?
4. Which privileges should a serving process lack in a separated release pipeline?

## Mastery gate

Pass when unapproved and malformed candidates fail closed, clean loading succeeds, a failed promotion preserves the active release, and you can explain the trust anchor. A loader that silently accepts missing metadata or treats “signed” as “safe” does not pass. [Module 16](16-evaluation-and-statistics.md) develops evaluation evidence; [instructor guidance](../instructor/answers-13-16.md) covers assessment.

## Primary readings

- [Python pickle documentation](https://docs.python.org/3/library/pickle.html): read the explicit code-execution warning.
- [NIST SP 800-218A](https://csrc.nist.gov/pubs/sp/800/218/a/final): connect AI development to secure software practices.
- [SLSA 1.2 provenance](https://slsa.dev/spec/v1.2/provenance): distinguish build/source claims and consumer verification.
- [OWASP Secure AI/ML Model Ops Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Secure_AI_Model_Ops_Cheat_Sheet.html): compare lifecycle and runtime-isolation controls.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V44 DEF CON 30 - Backdooring Pickles: A decade only made things worse (ColdwaterQ)](../MEDIA-LIBRARY.md#v44) (core, v1.4).
- Watch: [V45 DEF CON 33 - Loading Models, Launching Shells: Abusing AI File Formats for Code Execution (Cyrus Parzian)](../MEDIA-LIBRARY.md#v45) (core, v1.4).
- Do: [L14 Target: the model loader](../MEDIA-LIBRARY.md#l14) (core, v1.4).
- Watch: [V27 Let's reproduce GPT-2 (124M)](../MEDIA-LIBRARY.md#v27) (optional, v1.3).
- Watch: [V08 Overview of Adversarial Machine Learning](../MEDIA-LIBRARY.md#v08).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](../MEDIA-LIBRARY.md#b12).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
