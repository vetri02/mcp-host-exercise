# Module 20: Security Assessment and an Honest Portfolio

## Prerequisites and outcomes

Bring your campaign, detection drill, and governance records from [Module 17](17-automated-red-teaming.md), [Module 18](18-detection-and-incident-response.md), and [Module 19](19-cloud-governance-and-risk.md). This module is 10 hours: concepts 2, practice 5, evaluation 2, writeup 1. It is an assessment rehearsal, not a replacement for the 40-hour capstone that follows Module 24.

By completion, you will:

1. Trace five scoped security claims to inspected implementation and reproducible positive and negative evidence.
2. Write findings with observed impact, limitations, remediation, and retest criteria.
3. Publish a sanitized portfolio narrative and defensible release/no-go recommendation without overstating the simulation.

## Assessment is an argument supported by evidence

A security assessment asks whether specified controls address specified risks in a particular baseline. Start with authorized scope, system purpose, intended users, assets, dependencies, prohibited actions, and assessment constraints. Identify trust boundaries before choosing tools. The reference lab's real properties are local authorization and workflow behavior; probabilistic model behavior, real authentication, cloud IAM, SQL execution, and MCP transport are outside its supplied implementation.

Separate requirements, implementations, and observations. A statement that approvals should bind canonical arguments is a requirement. Code that checks a binding is an implementation. A test demonstrating rejection after argument substitution is evidence. None alone proves the complete property. Review the state transition and failure handling as well as a happy-path test. A screenshot or scanner headline is not a substitute for a reproducible procedure and inspected baseline.

Use your own explicitly local identifiers, such as `LOCAL-AUTH-01`, rather than borrowing an unverified AISVS requirement number. When extending the mapping to a standard, preserve the release artifact, exact requirement text, applicability rationale, verification method, evidence, and result. A thematic reference is not full conformity. A finite campaign also cannot prove comprehensive safety or future immunity.

## Worked example: a finding and its limits

Consider a hypothetical assessment run in which Alice's foreign-ticket read returned beta content. Record the exact baseline, fixture actor, target ticket, operation, expected denial, actual result, and returned synthetic data. State the impact as a cross-tenant authorization failure in the tested path, not “all customer data stolen.” Check whether the result came from the hardened service or the explicitly isolated insecure demonstration.

Recommend enforcing the end-user's tenant before reading and during response assembly, then retest owned reads, foreign reads, foreign identifiers with similar titles, and invalid caller-supplied tenant arguments. Verify no output or state changes occur on denial. If the retest passes, label the finding remediated in that baseline and keep the original evidence. Do not rewrite history to imply the original system always passed.

For the current course exercise, this scenario is a worked hypothetical finding, not a claimed discovered vulnerability. Real reports must identify which failures were actually observed, which were deliberately injected, and which remain speculative. Severity follows demonstrated capability, exposure, affected assets, and constraints. Avoid numerical risk scores without a stated model and justification.

## Assessment-to-evidence mapping

Build an ordered checklist, not an unbounded scanner run:

- `LOCAL-AUTH-01`: owned retrieval remains usable and foreign resources are denied. Map the reference contract, inspected retrieval/tool authorization code, Module 17 cases, and before/after side-effect observations. Ticket-read evidence alone does not establish every retrieval stage.
- `LOCAL-APPROVAL-01`: an independently approved write succeeds, while unapproved writes and replay fail. Map issuance and consumption checks, the approved positive control, replay sequence, and argument-binding/expiry invariant tests.
- `LOCAL-MEMORY-01`: memory is tenant-and-user scoped. Map actual supplied invariant tests and inspect relevant storage keys. If you did not run or review them, mark this unknown, not passed by analogy with retrieval.
- `LOCAL-OBSERVE-01`: detection labels and evidence gaps are represented accurately. Map Module 18 fixtures, benign controls, duplicate/gap tests, and the runbook. Synthetic E8 is detector evidence, not proof of a real service incident.
- `LOCAL-RELEASE-01`: accountable risk decisions distinguish local demonstration from proposed deployment. Map Module 19 inventory, responsibility allocation, critical blockers, exceptions, and reviewer authority.

For each item retain claim, scope, method, baseline, expected observation, actual observation, evidence location, digest, conclusion, uncertainty, and reviewer. “Not applicable” needs a reason tied to scope; “not tested” must remain visible. A digest helps detect changed evidence, but does not independently authenticate it.

## Safe lab: assemble and challenge an evidence bundle

### Setup

Use a private learner workspace and synthetic records only. Copy your actual outputs into `assessment-evidence`: `campaign17.jsonl`, `detection18.json`, and `decision19.json`. Include the corresponding scripts and human review notes in the eventual bundle. Do not commit provider credentials, approval tokens, raw customer prompts, or production account identifiers.

This standard-library example validates campaign records and fingerprints three outputs. It is an evidence check, not an autonomous security assessor or universal release authority. Save it as `assess20.py` beside your evidence directory.

```python
import hashlib
import json
from pathlib import Path


root = Path("assessment-evidence")
names = ["campaign17.jsonl", "detection18.json", "decision19.json"]
required = {"read-owned", "read-foreign", "write-unapproved",
            "reader-write", "write-approved", "approval-replay"}
manifest, blockers = {}, []
for name in names:
    p = root / name
    if not p.is_file():
        blockers.append("missing:" + name)
        continue
    manifest[name] = hashlib.sha256(p.read_bytes()).hexdigest()

campaign = root / names[0]
if campaign.is_file():
    try:
        rows = [json.loads(line) for line in
                campaign.read_text().splitlines() if line.strip()]
        ids = [row["case"] for row in rows]
        if len(ids) != len(set(ids)):
            blockers.append("duplicate case")
        if not required.issubset(ids):
            blockers.append("missing baseline case")
        for row in rows:
            if (row["observed"] not in {"allow", "deny"} or
                    row["expected"] != row["observed"]):
                blockers.append("mismatch:" + row["case"])
    except (ValueError, KeyError, TypeError):
        blockers.append("invalid campaign schema")
print(json.dumps(dict(
    evidence_digests=manifest, blockers=blockers,
    disposition="NO_GO" if blockers else "HUMAN_REVIEW_REQUIRED")))
```

### Steps and expected observations

1. Run the check with the real baseline outputs. Expect all three digests and no campaign mismatch if the declared six cases passed. Extra cases are allowed but must have unique identifiers. The output remains HUMAN_REVIEW_REQUIRED, because hashes and label matching cannot assess code quality, evidence truthfulness, or governance conclusions.
2. Independently confirm each expected case against the catalogue and source. Editing both expected and observed to allow could fool this checker; the assessor must not treat its label consistency as the security oracle. Identify this limitation in your report.
3. Review the detection and decision files semantically. An alert in a deliberately injected fixture can be expected. A NO_GO for an unresolved provider-extension risk must remain a deployment blocker even though the evidence file exists. File presence is not a passed control.
4. Run and record the supplied invariant tests for memory and approval binding. Build the five-item mapping above using actual paths and test names. If execution is blocked, document the missing dependency or incomplete implementation and leave the item unknown.
5. Write two detailed findings: one observed issue if present, otherwise one clearly marked injected exercise finding; and one genuine assurance gap, such as untested distributed approval consumption. Assign an owner and define observable closure criteria for each.
6. Ask a peer to reproduce one positive and one negative case from a clean checkout, then compare revisions and observations. A repeated deterministic case is reproducibility evidence, not an independent model-safety sample.

### Negative tests and deliverables

Remove an output: expect NO_GO. Duplicate a case: expect a blocker. Change one observed decision: expect a mismatch. Insert malformed JSON: expect invalid-schema handling. Modify evidence bytes: expect a new digest, not an automatic conclusion about malicious tampering. Change both labels together: document that the simple checker needs independent catalogue review.

Deliver the evidence bundle, manifest, five-claim mapping, two findings, reproduction instructions, source/version inventory, architecture review, and release recommendation. Preserve original and retest evidence separately. The report must distinguish failed controls, uncertain controls, and explicitly scoped nonapplicability. Answer what would change your recommendation and who has authority to make that decision.

## Release criteria and portfolio integrity

No-go conditions include observed tenant leakage, unapproved writes, replay acceptance, unresolved critical assurance gaps, missing required evidence, and unknown supplier controls for a consequential provider extension. A restricted local demonstration may be reviewable only with synthetic data, stated limitations, passing applicable invariants, and an accountable decision. Production release needs evidence appropriate to actual infrastructure, model behavior, operational readiness, and use context. NIST AI RMF alignment is not legal certification.

A credible portfolio says: “I assessed a deterministic Python authorization simulation and built reproducible invariant and detection tests.” Name what you personally authored, dependencies reused, failed experiments, and unresolved gaps. If no real model was tested, do not claim PyRIT/garak model assessment, LLM robustness, or MCP/cloud deployment. Do not fabricate screenshots, benchmark results, job credentials, client engagements, or a certificate. A well-explained limitation demonstrates better judgment than an inflated success claim.

## Mastery gate

Pass when a reviewer can reproduce cases, trace all five claims, distinguish injected examples from discoveries, and justify the release boundary. Fail if the portfolio upgrades toy results into production assurance, conceals unknowns, or treats matching labels as independently verified security.

## Quiz

1. What three kinds of evidence connect a requirement to a defensible conclusion?
2. Why does a matching campaign label pair not independently prove authorization?
3. How should an untested critical production dependency affect release?
4. What may you honestly claim if you used only this reference lab?

## Primary readings

- [OWASP AISVS project overview](https://owasp.org/www-project-artificial-intelligence-security-verification-standard-aisvs-docs)
- [OWASP AISVS repository, release sources, and reference guidance](https://github.com/OWASP/AISVS)
- [NIST AI RMF resources](https://www.nist.gov/itl/ai-risk-management-framework)

[Instructor answers](../instructor/answers-17-20.md#module-20)

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V04 Episode 1: What is AI Red Teaming? | AI Red Teaming 101 with Amanda and Gary](../MEDIA-LIBRARY.md#v04).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](../MEDIA-LIBRARY.md#b12).
- Discuss/critique: [R01 Is AI security a dedicated job or a security-engineering specialization?](../MEDIA-LIBRARY.md#r01).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
