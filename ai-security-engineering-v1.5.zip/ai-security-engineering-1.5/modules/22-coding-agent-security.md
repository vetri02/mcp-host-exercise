# Module 22: Coding Agents and Developer-Tool Security

## Prerequisites and outcomes

Bring the sink inventory from [Module 11](11-leakage-and-output-security.md), the egress and budget controls from [Module 12](12-isolation-and-resource-limits.md), the supply-chain review from [Module 15](15-secure-mlops-and-supply-chain.md), and the local model from [Module 21](21-real-model-lab.md). Allocate ten hours: two for concepts, five for the lab, two for evaluation, one for the writeup.

By the end, you can:

1. Enumerate the configuration surface of an IDE or terminal coding agent and classify each file as data the model reads, code the harness executes, or both.
2. Explain why a cloned repository is a code-execution vector for an agent before any trust decision is made, and build a scanner for the common carriers.
3. Design a CI pipeline in which an agent can triage untrusted issues without the credentials to publish a release.

## The agent's configuration is executable data

A coding agent reads far more than the file you asked about. It reads instruction files (`.cursorrules`, `CLAUDE.md`, `AGENTS.md`, Copilot instructions), skill or command definitions, hook configuration, MCP server configuration, editor task files, and the repository itself. Some of those files are consumed by the model as text. Others are consumed by the harness as configuration that starts processes. Several are both: a settings file that defines a hook is read by the harness and run as a shell command, and its contents can also steer the model.

Module 15 taught that an artifact is trusted only after review and pinning. A cloned repository arrives with none of that. In 2025 and 2026 the recurring pattern was a project-local file that the harness honored before, or without, a trust prompt: hooks in a repository's agent settings that executed on session start, MCP configuration that auto-started a server, a task file that ran when the folder opened. Each is ordinary functionality. Each becomes remote code execution the moment a repository is attacker-controlled, which every public repository is.

The second recurring pattern is invisible text. Unicode offers zero-width and bidirectional control characters that a reviewer does not see in a diff and a tokenizer passes to the model unchanged. An instruction file can carry a hidden sentence that tells the agent to add a dependency or send a file somewhere. The fix is not to ban Unicode; it is to render it visibly at review time and reject control characters in files the agent consumes as instructions.

## Allowlisted commands are still sinks

Agents ask for confirmation before running commands, and to reduce fatigue they allowlist commands judged harmless. In mid-2025 one assistant allowed name-resolution utilities without approval. An injected instruction then read a `.env` file and encoded it into the labels of DNS queries to an attacker's domain. Nothing in the allowlist was a file-transfer tool; the network side effect was enough. Module 11's rule applies without change: any observable external effect is a sink, and an allowlist is an authorization decision that needs the same review as a tool manifest.

Approval fatigue is itself an attack surface. "Don't ask again for this kind of action" converts a single consent into a standing capability whose scope the user did not examine. The 2025 skills research showed a benign approval carrying over to a harmful related action. Bind approvals to exact action identity, as Module 09 did for tool arguments, never to a category.

## The CI case: Clinejection

In early 2026 an open-source project ran a coding agent in a GitHub Actions workflow to triage new issues. The workflow interpolated the issue title into the agent's prompt. A title crafted as an instruction made the agent, which had a shell, install a typosquatted action and poison the Actions cache. A later nightly release consumed the poisoned cache and leaked the npm publishing token; a malicious package version was then installed on thousands of machines before it was pulled.

Trace it with Module 05's five parts. Attacker-controlled source: the issue title. Ingestion: string interpolation into a prompt. Claimed authority: none, but the agent had a shell and the workflow had cache write access. Requested deviation: install and cache a package. Consequential sink: the release job's credentials. No single step was exotic. The design error was giving an untrusted-input processor the same runner, cache, and credential reach as the release pipeline.

## Worked example: a carrier scanner

This standard-library script scans a repository for the carriers above. It is a reviewer's aid, not a proof of safety: it finds known carriers and says nothing about an attack it has not been taught.

```python
import json
import re
import sys
from pathlib import Path

INSTRUCTION_FILES = {".cursorrules", "CLAUDE.md", "AGENTS.md", "copilot-instructions.md"}
HOOK_FILES = {".claude/settings.json", ".claude/settings.local.json",
              ".vscode/tasks.json", ".cursor/mcp.json", ".mcp.json"}
HIDDEN = re.compile("[​-‏‪-‮⁠-⁤﻿]")


def scan(root):
    findings = []
    for path in Path(root).rglob("*"):
        if not path.is_file() or ".git" in path.parts:
            continue
        rel = path.relative_to(root).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        if path.name in INSTRUCTION_FILES or rel.startswith(".github/"):
            for match in HIDDEN.finditer(text):
                findings.append((rel, "hidden_unicode", "U+%04X" % ord(match.group())))
        if rel in HOOK_FILES:
            try:
                data = json.loads(text)
            except ValueError:
                findings.append((rel, "unparseable_config", ""))
                continue
            blob = json.dumps(data)
            for key in ("hooks", "command", "mcpServers", "tasks", "runOn"):
                if '"%s"' % key in blob:
                    findings.append((rel, "executes_on_open", key))
    return findings


if __name__ == "__main__":
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
    for rel, kind, detail in scan(root):
        print(f"{kind:18} {rel} {detail}")
    print("scanned; absence of findings is not evidence of safety")
```

Run it against a scratch repository you create with one hidden zero-width joiner in `AGENTS.md` and one `SessionStart` hook in `.claude/settings.json`. Both must be reported. Then run it on a clean repository and confirm it reports nothing. The script treats the presence of a hook as a finding to review, not as malice; many legitimate projects define hooks. The point is that nothing should run before a human has seen the list.

## Safe lab: an agent that can triage but not publish

Use a scratch Git repository, synthetic issue text, and your local model. No real CI service, package registry, or credentials.

1. **Surface inventory, one hour.** List every file in your scratch repository that a chosen coding agent reads or executes, using its current documentation. For each: who can write it, when the harness reads it, whether a trust prompt precedes use, and what it can cause. Record the agent and version; this surface changes between releases.
2. **Carrier tests, one hour.** Extend the scanner with one carrier from the agent's documentation that it does not yet cover. Add a negative test: a file with ordinary non-ASCII text (accented names, CJK) must not be flagged.
3. **Triage harness, two hours.** Write `triage.py` that takes an issue title and body, asks the local model for a JSON label and one-sentence summary, and writes them to a file. Give the harness no shell and no network beyond the model endpoint. Feed it twenty synthetic issues, five of which carry instructions in the title. Record whether the model's output tries to escape the label schema, and verify that the harness rejects anything that is not a label.
4. **Credential separation, one hour.** Write a two-job pipeline description (YAML or prose) in which the triage job runs with read-only repository access and no cache write, and the release job runs from a pinned commit on a separate runner with the publishing credential. State what a compromised triage job can and cannot reach. Compare with the Clinejection chain and name the link you broke.

Negative tests: a benign issue whose body contains a code block with the words `curl | sh` must be labelled normally, not refused. A hook definition in a repository you own must be listed, not silently deleted.

Deliver: the surface inventory, the extended scanner with tests, the triage harness and its twenty-issue log, the pipeline design with a credential-reach table, and a short note on what remains untested, which includes the real agent's actual behaviour on hooks, since you only inspected its documentation.

## Mastery gate

Pass when you can name, for one real coding agent, every file it will execute or obey from a freshly cloned repository and whether a trust prompt stands in front of each, and when your triage harness demonstrably cannot reach a publishing credential. Fail if you treat an allowlist of "harmless" commands as a boundary or if the scanner's silence is reported as safety.

## Quiz

1. Why is a repository's agent settings file both data and code, and which reading is the dangerous one?
2. A DNS lookup utility was allowlisted as safe. Which Module 11 principle did that violate?
3. In the CI incident, which single design change would have stopped the chain even with a fully steered model?
4. Why must an approval bind to an exact action rather than an action category?

Answers: [instructor key](../instructor/answers-21-24.md#module-22).

## Primary readings

- [Pillar Security: Rules File Backdoor](https://www.pillar.security/blog/new-vulnerability-in-github-copilot-and-cursor-how-hackers-can-weaponize-code-agents): hidden Unicode in instruction files, March 2025.
- [Embrace The Red: Claude Code data exfiltration via DNS](https://embracethered.com/blog/posts/2025/claude-code-exfiltration-via-dns-requests/): an allowlisted command as a sink, June 2025.
- [Check Point: Claude Code project-file flaws](https://blog.checkpoint.com/research/check-point-researchers-expose-critical-claude-code-flaws/): hooks executing before trust, October 2025.
- [CSA: Clinejection](https://labs.cloudsecurityalliance.org/research/csa-research-note-clinejection-prompt-injection-cicd-cache-p/): prompt injection to CI cache poisoning to supply-chain release, February 2026.
- [Schmotz, Abdelnabi, Andriushchenko: Agent Skills as an injection vector](https://arxiv.org/abs/2510.26328): approval carry-over, October 2025.
- [Anthropic: How we built Claude Code auto mode](https://www.anthropic.com/engineering/claude-code-auto-mode): a vendor's own account of tool-output classification as a defense layer; read it as design rationale, not a guarantee.

## Curated media and discussion

See [the module index](../MEDIA-INDEX.md#module-22-coding-agents-and-developer-tool-security).
