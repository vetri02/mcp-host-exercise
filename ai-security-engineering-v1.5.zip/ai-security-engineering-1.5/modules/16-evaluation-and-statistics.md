# Module 16: Evaluation Design and Statistics

## Prerequisites, objectives, and time

You need Python loops, basic proportions, and the difference between a deterministic authorization invariant and a probabilistic model outcome. The examples in [Module 13](13-model-privacy-and-extraction.md) and [Module 14](14-adversarial-machine-learning.md) supply useful distinctions, but this chapter's lab is independent of any model provider.

By the end, you can:

1. Design paired baseline/fix evaluation with development and held-out attack categories.
2. Report attack outcomes, benign false positives, denominators, and uncertainty without hiding nondeterminism.
3. Explain confidence-interval assumptions, dependence between trials, and why zero observed failures do not prove zero risk.

Use 2 hours for concepts, 5 for practice, 2 for evaluation, and 1 for the writeup. Learning these tools does not make a small course exercise a validated benchmark.

## Define the event before counting it

A test is meaningful only when its outcome rule is explicit. “The model seemed safe” is not a reproducible event. For tool authorization, success might mean an unauthorized state change, regardless of the assistant's wording. For leakage, success might require an exact synthetic canary appearing outside its allowed context. For factual poisoning, a target false statement and the scoring rule must be established before evaluation.

Measure the complete system at the boundary relevant to harm. An assistant may emit a dangerous proposal while an independent authorization layer prevents execution. Record both proposal rate and unauthorized-execution rate, rather than calling either one the other. An automated judge can mislabel outputs; audit a sample and report disagreements, ambiguous cases, and the judge's own uncertainty.

Define exclusions in advance. Timeouts, crashes, malformed inputs, and abstentions are outcomes, not inconvenient rows to discard. A timeout might prevent immediate harm while still being a denial-of-service failure. Keep separate counts for successful completion, harmful outcome, and availability failure. Use counts and denominators alongside rates.

## Paired comparison and honest holdouts

A baseline/fix comparison should use the same case IDs, expected outcomes, environment, budget, and scoring rules. Pairing removes some variation due to case difficulty. Independent random case samples for each version can confuse a case-mix difference with a treatment effect.

Split at the level where information leaks between examples. Paraphrases of one attack template should not straddle development and holdout as though they were independent discoveries. Hold out entire categories, document sources, or workflows when the intended claim concerns generalization to unfamiliar mechanisms. Use development cases to tune controls and thresholds; freeze those decisions before revealing holdout outcomes. Once you tune on a holdout, it becomes development data and needs replacement.

Attack cases alone reward blocking everything. Include benign requests, near-miss inputs, and legitimate boundary workflows. Here a **false positive** means a benign request incorrectly blocked; this convention differs from a judge falsely labeling a harmless output as harmful. State which meaning you use. Track benign task completion and latency alongside security events. A stricter fix may reduce harmful outputs while creating an unacceptable utility loss.

The complementary error, a false negative, is an attack the oracle scored as safe. Reducing one error usually raises the other; report both, and state which one your threshold was tuned to limit. When a detector is deployed against real traffic, its usefulness also depends on the base rate of attacks, a point Module 13 makes for membership inference and Module 18 applies to alerts.

## Nondeterminism and independent units

A deterministic reference simulator may enforce an invariant identically each run. Real model outputs can vary with sampling, model revisions, parallel execution, tool timing, and provider infrastructure. A seed and temperature are useful metadata, not universal guarantees of repeatability. Record versions, decoding settings, timestamps, and the number of attempts permitted per case.

Repeat cases to investigate this variation, but distinguish repeated trials from independent cases. Twenty runs of one prompt do not provide the diversity of twenty unrelated attack mechanisms. If you bootstrap a paired difference, resample whole case pairs with their repeats attached, not individual output rows. Shared templates or documents may require even larger clusters. Cluster bootstrap estimates are unstable when only a few independent clusters exist.

A per-attempt failure rate and the probability of at least one failure across an attacker's multiple attempts are different quantities. Under independent equal-probability attempts the latter is `1-(1-p)**m`. Dependence, adaptive queries, and changing context can invalidate that calculation. Explicitly describe the available attack budget rather than reporting only a convenient single-shot rate.

## Worked example: proportions with uncertainty

The Wald interval `p ± 1.96*sqrt(p*(1-p)/n)` collapses to zero width at zero events. That is a warning sign. The Wilson interval has better behavior near boundaries for a binomial proportion. It still assumes a meaningful independent sampling model.

```python
import math

def wilson(k, n, z=1.96):
    if type(k) is not int or type(n) is not int:
        raise ValueError("integer counts required")
    if n <= 0 or not 0 <= k <= n:
        raise ValueError("invalid counts")
    p = k / n
    den = 1 + z*z/n
    center = (p + z*z/(2*n)) / den
    half = z * math.sqrt(p*(1-p)/n + z*z/(4*n*n)) / den
    return max(0, center-half), min(1, center+half)

def zero_event_upper(n, alpha=0.05):
    if type(n) is not int or n <= 0 or not 0 < alpha < 1:
        raise ValueError("invalid trial count or alpha")
    return 1 - alpha ** (1 / n)

print(wilson(2, 20))
print(zero_event_upper(100))
```

The first input is an illustrative count, not a measured model result. For zero events in 100 independent identically distributed Bernoulli trials, the exact one-sided 95 percent upper bound is approximately 2.95 percent. It follows from `(1-p)**100=0.05`. The familiar `3/n` rule approximates this bound. Neither expression covers untested categories or correlated repetitions.

A 95 percent confidence interval describes long-run coverage of a procedure under its assumptions. It is not a 95 percent probability assigned to the fixed unknown rate by this frequentist calculation. A suite curated for challenge coverage may not be a random sample from deployment at all; describe its observed rate as suite-specific and use intervals only with a justified sampling interpretation.

## Safe lab: a paired synthetic evaluation

### Setup

Use Python's `random`, `statistics`, and standard-library collections only. Build five unique synthetic case IDs in each of four categories: direct attack, encoded attack, held-out context attack, and benign request. These labels organize a simulator, not real prompt attacks. Keep held-out IDs separate until the evaluation plan is frozen.

Define Bernoulli outcome probabilities for baseline/fix as `(0.60, 0.20)`, `(0.50, 0.30)`, `(0.50, 0.40)`, and `(0.05, 0.15)` respectively. The event means harmful completion for attack cases and incorrect blocking for benign cases. These are invented simulator parameters, not empirical claims about a defense.

### Steps

1. Write the event definitions, category split, repeat count of 20, and metrics before generating outcomes. Use development categories to check the pipeline, not to announce holdout performance.
2. For each case and repeat, draw `u` from a locally seeded `random.Random`. Record baseline as `u < p_baseline` and fix as `u < p_fix`. Sharing `u` creates deliberate synthetic pairing; it does not replicate how two real model versions share randomness. Because `p_fix` is lower in every attack category, sharing `u` also guarantees the fix never loses on any single row; that one-sidedness is an artifact of this simulator (common random numbers), not evidence that pairing always produces clean improvements.
3. Store case ID, category, repeat, version, and binary outcome. Calculate per-case mean outcomes, then category means. Report benign false-positive rate separately from attack success rates.
4. Freeze the comparison and reveal held-out outcomes. For each attack case calculate `baseline_mean - fix_mean`, so positive differences indicate improvement. Bootstrap 2,000 samples of whole paired cases using a separate recorded seed. Calculate the mean difference for each sample and report empirical 2.5th and 97.5th percentiles. Stratify by category rather than silently changing category weights.
5. Compute Wilson intervals on one designated independent trial per case for teaching purposes. Do not feed all repeated rows into a binomial formula without defending independence. Report that five cases per category provide weak interval and bootstrap evidence.
6. Construct a separate zero-event fixture. Calculate the bound for 10 and 100 independent trials; compare it with repeated runs of one case and explain why effective coverage differs.

### Expected observations, negative tests, and deliverables

The imposed probabilities tend to yield fewer attack events under the fix and more benign blocks, but finite samples can differ from their expectations. Report what ran, not what the simulator was intended to show. A degenerate bootstrap with identical differences can have zero width without establishing absence of other uncertainties.

Reject `n=0`, `k>n`, missing pairs, and duplicate case/repeat/version records. Shuffle row order and verify unchanged paired metrics. Deliberately mismatch case IDs and ensure the comparison fails rather than silently pairing by row position. Verify all-block behavior scores poorly on benign utility. An unknown category must be reported, not dropped.

Submit the frozen plan, generated records, runnable analysis, counts, category metrics, interval assumptions, and a limitations memo. Label every number as calculated, simulated, or observed from an actual system. No external model execution is required.

## Quiz

1. Why evaluate the same cases before and after a fix?
2. Why can repeated trials inflate apparent confidence if treated as independent cases?
3. What does zero failures in 100 trials establish, and what does it not establish?
4. How can attack success improve while the system becomes less useful?

## Mastery gate

Pass when pairing survives row shuffling, malformed counts fail, heldout decisions remain frozen, and benign outcomes accompany security rates. Explain the zero-event bound and reject a claim of comprehensive safety. See [instructor answers](../instructor/answers-13-16.md).

## Primary readings

- [NIST AI RMF Playbook: Measure](https://airc.nist.gov/airmf-resources/playbook/measure): document test sets, metrics, and unmeasured risks.
- [NIST Dataplot: Wilson and related proportion intervals](https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/agcoulci.htm): read the naming clarification and assumptions.
- [NIST Dataplot: exact binomial confidence limits](https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbici.htm): compare one-sided and two-sided bounds.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V35 Why Does AI Lie, and What Can We Do About It?](../MEDIA-LIBRARY.md#v35) (recommended, v1.3).
- Watch: [V06 Episode 8: Automating AI Red Teaming with PyRIT | AI Red Teaming 101](../MEDIA-LIBRARY.md#v06).
- Read: [B10 Demystifying evals for AI agents](../MEDIA-LIBRARY.md#b10).
- Discuss/critique: [R03 Evaluating agentic AI security before production](../MEDIA-LIBRARY.md#r03).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
