# Module 07: Knowledge Poisoning, Provenance, and Publication

## Prerequisites and measurable objectives

Complete [Module 06](06-rag-authorization.md). You should understand tenant-bound retrieval, publication eligibility, Python dictionaries, and the difference between a resource identifier and trusted identity.

By the end of this ten-hour module, you will:

1. Distinguish answer-contaminating knowledge poisoning from instruction-based prompt injection.
2. Build a versioned synthetic publication check and demonstrate what digest verification does and does not establish.
3. Design tests and a recovery procedure spanning ingestion, indexes, caches, and citations.

Use two hours for concepts and readings, five for the lab, two for evaluation and quiz work, and one for the incident-style writeup.

## The corpus is part of the security boundary

A retrieval system may produce a harmful answer without any sentence telling the model to ignore instructions. An attacker can instead make the retrieved evidence wrong. A fabricated support note could state an incorrect retention period, unsafe operational procedure, or false entitlement. If the assistant treats the note as evidence, the answer can be contaminated while the model follows its task faithfully.

Knowledge poisoning targets the information on which the system relies. Prompt injection targets how the system behaves. A single document can do both, but separating the mechanisms improves diagnosis: correcting an instruction hierarchy does not validate factual claims, and verifying a factual statement does not authorize a tool request embedded beside it.

Attackers might control an external source, a contributor account, an ingestion job, document metadata, or the publication store. Their influence depends on which stage accepts their input and how retrieval selects evidence. A high-ranking poisoned passage is dangerous because it is likely to enter context, not because relevance magically makes it trustworthy. The PoisonedRAG paper is a primary research example of retrieval-corpus poisoning; its experimental findings should not be treated as a universal rate for your system.

Separate four properties. Artifact integrity means the bytes match an expected version (Modules 04 and 05 use "integrity" more broadly, for any unauthorized change to data or behavior; this chapter means the narrow, byte-level sense). Provenance records where those bytes came from and how they were handled. Authorization determines who may publish and read them. Truth is whether their claims are correct for the task. These properties overlap operationally but are not interchangeable.

A SHA-256 digest helps detect a change relative to a trusted expected digest. If an attacker can replace both the document and the expected digest, the comparison succeeds. A digest also cannot distinguish a correct retention policy from a false policy that was mistakenly approved. Signed records can authenticate a signer under a key-management assumption; they still do not prove the signer was competent or the assertion true.

Three primitives answer three different questions. A hash gives bytes an identity: anyone can compute it, so it proves only that two things are the same. A signature binds bytes to a private key: it proves who endorsed them, given trust in that key. Encryption hides bytes from anyone without the key: it proves nothing about origin or truth. Encryption at rest therefore cannot stop an authorized service from reading the wrong tenant, and a hash cannot stop an attacker who controls the expected value.

## Worked example: the false retention policy

In this synthetic scenario, the authoritative sandbox policy says records are retained for thirty days. A contributed note instead says 365 days. Both strings are ordinary statements, not executable commands. A retrieval assistant could confidently repeat the wrong duration if it sees only the contributed note.

Suppose publication requires a reviewer to register the document identifier, tenant, version, source, and content digest in a separately controlled manifest. Replacing the approved bytes with the false note should be detected. Publishing the false note as an approved new version will pass the digest check. The failure has moved upstream to review and publication authority.

This example contains invented sandbox rules for teaching. Neither duration is advice for a real organization's retention policy. The code below checks a publication decision only; it has no model and cannot measure answer accuracy.

```python
from hashlib import sha256

def digest(body):
    return sha256(body.encode("utf-8")).hexdigest()

def record(document_id, tenant, version, source, body):
    return {
        "id": document_id, "tenant": tenant, "version": version,
        "source": source, "body": body,
    }

def manifest_entry(doc):
    return (doc["tenant"], doc["version"], doc["source"],
            digest(doc["body"]))

def publish(doc, trusted_manifest):
    expected = trusted_manifest.get(doc["id"])
    if expected is None or manifest_entry(doc) != expected:
        raise PermissionError("unapproved document version")
    return dict(doc)

original = record("RET-1", "alpha", 1, "sandbox-handbook",
                  "Sandbox retention is 30 days.")
manifest = {original["id"]: manifest_entry(original)}
assert publish(original, manifest)["body"] == original["body"]
changed = dict(original, body="Sandbox retention is 365 days.")
try:
    publish(changed, manifest)
except PermissionError:
    pass
else:
    raise AssertionError("modified bytes were published")

# A compromised or mistaken approval can bless false content.
wrong_manifest = {changed["id"]: manifest_entry(changed)}
assert publish(changed, wrong_manifest)["body"] == changed["body"]
```

## Safe lab: versioned publication and rollback

Use synthetic documents in a private local workspace. Save the snippet as `publication_policy.py` and run it. The reference package is a deterministic authorization simulator, not a live ingestion platform. Its digest checks protect correspondence with approved fixture bytes; they do not authenticate publishers or judge truth. This module's manifest exercise is a separate learner-built extension.

### The target, version 1.4

The [poisoned-corpus target](../targets/poisoned_corpus/README.md) packages hours three to five below as a vulnerable assistant with a five-stage grader. Run `python3 -m targets.poisoned_corpus.target` from the course root to watch copies outvote the approved document, a quoted phrase become an action, and a revoked document keep being served from cache. Then implement `hardened.py` until `python3 -m targets.poisoned_corpus.check` prints all five flags. The grader's stage 3 is the trap this module warns about: the approved training note that quotes the attacker's phrase must still be served. Submit the target deliverables with this module's; Milestone B scores them.

### Setup and five-hour procedure

In hour one, write a threat model for three local actors: a contributor who can submit candidates, a reviewer who can approve them, and a reader who can retrieve published versions. Explain why allowing the contributor to update the manifest would defeat the boundary. In the snippet, separation is an assumption about who supplies `trusted_manifest`, not an implemented login or filesystem permission system.

In hour two, create candidates that change the body, tenant, source label, and version individually. Each change must be rejected by the original manifest. A source label is only metadata: matching the string `sandbox-handbook` does not prove that the handbook's owner wrote it. Test a candidate that copies that label while altering the body.

In hour three, add a local publication registry storing document identifier, version, approval decision, and reviewer fixture identifier. Enforce a rule that a contributor cannot approve their own submission. Keep the expected manifest separately from submitted candidate fields. Do not let an input object's `approved=True` flag grant publication. Document that fixture reviewer identity remains a simulation rather than real authentication.

In hour four, model retrieval using only the currently approved registry version. Approve a corrected version two, retire version one, then attempt to retrieve an old cached identifier/version pair. It should no longer be served. Test that a removed record is absent from both the retrieval list and citation lookup. An old model context already containing the text cannot be retroactively erased by changing the index; start a fresh simulated request.

In hour five, perform an incident drill. Mark the false version as revoked, identify affected request identifiers from metadata-only audit records, invalidate synthetic caches, and restore the known-good version. Write how a real system would rebuild indexes and identify downstream summaries or artifacts. The exercise changes local dictionaries only; it does not implement distributed rollback or discover actual customer exposure.

### Expected observations and negative tests

The unchanged approved document should pass. Unauthorized changes should fail before their body is exposed. The false document with an altered trusted manifest should pass the byte check, demonstrating the limit of that control. Your publication registry should reject self-approval and stale versions while allowing an independently approved corrected version.

Use the evaluation block to test a missing manifest entry, identical body under another tenant, a stale approved version, a forged approval flag, and a valid document containing a quotation about prompt injection. Rejecting every mention of an attack would damage useful teaching content without solving poisoning.

Submit runnable code, named assertions with expected results, a version-history log using identifiers rather than document bodies, and an incident timeline. Include two separate conclusions: which integrity invariant held and which truth or publisher-authentication questions remain unresolved. Do not label a successful checksum as validated knowledge.

## Designing beyond the exercise

Production publication may require authenticated contributors, independent review, source-access controls, immutable version records, key management, and monitored ingestion jobs. Review effort should follow consequence: a casual FAQ and a policy governing financial or safety decisions do not deserve identical acceptance criteria.

Corroboration can help, but three copies of the same poisoned source are not three independent witnesses. Record lineage so duplicated evidence is not counted repeatedly. Freshness also matters: a historically authentic policy may be obsolete. Cite the version actually used and preserve enough restricted evidence for investigation without putting sensitive source text in ordinary logs.

## Mastery gate

Pass when candidate content cannot approve itself, modified bytes and stale versions are denied, approved controls succeed, and your rollback covers retrieval and citations. You must explain why the intentionally false approved version passes the digest check and name the missing upstream trust assumption.

## Quiz

1. How can poisoning change an answer without containing an imperative instruction?
2. Which assumption makes a content digest useful for integrity verification?
3. Why do an authenticated publisher and matching digest still not establish truth?
4. Why can revoking a source leave risk in caches, summaries, or existing contexts?

## Primary-source reading

- [PoisonedRAG](https://arxiv.org/abs/2402.07867): read the threat model and retrieval-poisoning mechanism before interpreting experiments.
- [NIST adversarial ML taxonomy and terminology](https://www.nist.gov/publications/adversarial-machine-learning-taxonomy-and-terminology-attacks-and-mitigations-0): distinguish poisoning targets and attacker capabilities.
- [OWASP GenAI LLM Top 10, 2026](https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026): place corpus integrity within the wider application threat model.

Continue with [Module 08](08-tool-and-sql-security.md). See the [reference lab](../reference-lab/CONTRACT.md) and separate [instructor answers](../instructor/answers-05-08.md).

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Do: [L13 Target: the poisoned corpus](../MEDIA-LIBRARY.md#l13) (core, v1.4).
- Watch: [V46 DEF CON 32 - When Chatbots Go Rogue: Lessons Learned from Building and Defending LLM Applications (Javan Rasokat, Andra Lezza)](../MEDIA-LIBRARY.md#v46) (recommended, v1.4).
- Read: [B06 A small number of samples can poison LLMs](../MEDIA-LIBRARY.md#b06).
- Discuss/critique: [R07 Poisoning an owned RAG store: experiment and limitations](../MEDIA-LIBRARY.md#r07).
- Optional short commentary: [X03 Hidden PDF content and a reported Notion exfiltration path](../MEDIA-LIBRARY.md#x03).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
