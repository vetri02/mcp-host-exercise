# Module 04: Threat modeling and secure AI design

## Prerequisites and outcomes

Complete Modules 01-03 and retain your architecture diagram. Allocate ten hours. You will: (1) define an attacker by capabilities rather than vague labels; (2) connect a threat to assets, boundaries, effects, controls, and tests; (3) produce a release-oriented threat model that distinguishes assumptions, tested controls, and residual risk.

## Lesson: start with the system, not an attack list

A threat model is an explanation of how a particular system can fail under particular adversarial conditions. It is not a list of fashionable attacks. Begin with the assets and intended operations. For the support agent, assets include customer tickets, tenant-private policies, identities, approval authority, service credentials, audit records, and compute budget. Intended operations include authorized retrieval, read-only lookup, reviewed ticket updates, and local draft creation.

Draw components and data flows. Mark trust boundaries: browser to application, application to identity provider, retriever to document store, application to model provider, model proposal to executor, executor to downstream service, approval UI to approval registry, and application to log storage. A single box labelled AI obscures the boundaries where controls must live.

Attacker capabilities determine whether a scenario is plausible. A user may control a chat message but not the system prompt. A contributor may add a document but not approve it. An external website may control fetched page content. A compromised tool package may control implementation and metadata. An insider may access a registry. These adversaries differ in access, knowledge, budget, persistence, and intent, so every finding should state which one it assumes.

Avoid assuming unlimited attacker power by accident. If an experiment lets the attacker overwrite the trusted permission database, it no longer tests whether ordinary prompt injection bypasses authorization. Such a test can still explore administrator compromise, but label that assumption. Similarly, calling an internal Python object directly is not a remote exploit unless the deployed architecture exposes an equivalent path.

## Threat, vulnerability, exploit, and impact

A threat is a possible adversarial event. A vulnerability is a weakness that enables a prohibited outcome. An exploit is a concrete way to use that weakness. Impact is the consequence. In a report, prompt injection is the technique, unauthorized ticket access is the impact, and a missing resource-level check is the root cause, and keeping the three apart is what makes the report actionable.

One attack can cross several stages: a contributor inserts a malicious knowledge document; retrieval selects it; the model proposes a foreign-ticket read; the executor accepts it; private content appears in a response. Controls can break the chain at different points. Ingestion review reduces entry, retrieval permissions limit context, constrained tools reduce proposed capabilities, execution authorization blocks effect, and monitoring supports response. A stronger prompt is only one possible layer.

Every security outcome is a loss of one of three properties. Confidentiality: information reaches a party not entitled to it, such as a foreign ticket in Alice's context. Integrity: data or behavior is changed without authorization, including a correct-looking answer built on a false document. Availability: the service, its budget, or its approval path is denied to legitimate users. Name the property each threat record attacks; it determines the test oracle, which is the observable you will check to decide whether the threat was realized.

Classify both security and safety outcomes, but do not conflate them. Harmful advice may matter even without unauthorized data access. A business decision corrupted by false retrieved content may create integrity risk. An API action can violate authorization even if generated text is polite and harmless. Choose test oracles that match each outcome.

## Design principles and control placement

Defense in depth means independent controls at different boundaries, so that one failure is not sufficient for impact. "Independent" is the operative word: a prompt rule and an output filter that both depend on the model are one layer, not two. A deterministic authorization check, a network egress policy, and a human approval are three. Separation of duties is the organizational form of the same idea: no single identity may both propose and authorize a consequential change, so one compromised account cannot complete the chain alone.

Deny by default, minimize privileges, isolate tenants, treat external content as data, validate outputs before interpretation, and maintain independent execution policy. Prefer narrow operations over arbitrary interpreters. A tool that reads a scoped support record is easier to govern than one that runs arbitrary SQL, shell commands, or unrestricted browser actions.

Approval is useful only if its meaning is precise. Bind it to an actor, tenant, tool, parameters, relevant resource state, expiry, and one use where appropriate. Recheck policy at execution. If material details change, require renewed approval. The reference lab binds identity, tool, arguments, expiry, and use; resource-version binding and distributed atomic transactions are extension requirements, not already solved production features.

Security also includes availability and cost. A retried agent can exceed budgets without accessing forbidden data. Bound recursive loops and parallelism, enforce quotas outside model reasoning, and provide a kill switch. Failure modes should be designed: deny privileged execution during a policy outage, expire stale approvals, and avoid fallback to broader credentials.

## Worked example: a threat record

~~~text
Asset: beta support record
Attacker: alpha user who controls chat input
Goal: retrieve a beta record through the support assistant
Entry: model proposes read_ticket(B-200)
Boundary: proposed action -> backend executor
Root cause if successful: missing tenant/object authorization
Control: derive identity from trusted session; scope resource lookup
Evidence: denial trace and unchanged state; no beta text in context/output
Residual risk: other retrieval/export paths not yet tested
~~~

The residual-risk line prevents a narrow passing test from becoming an unsupported whole-system claim. It also directs the next test. A second record might cover poisoned content causing wrong but authorized advice, which needs a different control and oracle.

## Lab: threat model the evolving capstone

Use [the threat-model template](../templates/threat-model.md). Build a data-flow diagram and asset inventory for the synthetic support agent. Include the optional model provider, even if you have not connected one yet, and clearly mark that flow as planned. Identify trusted fixture identity, the approval component, and the registry as simulator assumptions.

Write at least eight scenarios spanning input manipulation, retrieval disclosure, tool overreach, persistent memory, supply-chain changes, output interpretation, resource exhaustion, and logging leakage. Each scenario needs attacker control, preconditions, desired effect, control owner, test oracle, and residual risk. Do not use attack names without explaining the causal chain.

Select three scenarios and create tests or exact test procedures. At least one must bypass the chat layer and call the executor directly. At least one must involve denied execution with unchanged state. At least one must test a legitimate task so that a defense that blocks everything is not mistaken for success.

Hold a review with a peer or record yourself explaining the model. Ask: Where does identity originate? What can retrieved content influence? Which credentials can the model see? What happens if approval or policy storage is unavailable? Can the same downstream tool be called from another path? Who can change approved tool definitions? Update the model when an answer reveals an assumption.

## Expected observations and deliverables

Different attacker capabilities yield different tests. A prompt-injection attempt can succeed at steering a proposal while failing at execution. Some integrity harms remain possible despite strict authorization. Resource and provider boundaries require controls not present in the offline simulator.

Deliver: a data-flow diagram; an asset and trust-boundary inventory; eight threat records; three test artifacts; and a prioritized remediation list. Use the [risk register](../templates/risk-register.csv) to name an owner and review date for unresolved items. A risk is a scenario with a likelihood (how plausible, given the attacker model and existing controls) and an impact (what is lost, in confidentiality, integrity, or availability terms, and for whom). Prioritization multiplies or ranks these, but usually only ordinal labels are available, so treat the product as a sort key, not a measurement. A rare catastrophic outcome must not be ranked below a frequent trivial one by arithmetic alone. Scores are decision aids, not measured frequencies unless supported by appropriate data.

## Mastery gate

A reviewer should be able to reconstruct the attacker-to-impact chain for three scenarios and identify the authoritative control at each boundary. No release statement may imply untested paths were verified. Include an explicit no-go condition such as any reproducible cross-tenant disclosure or unauthorized simulated write.

## Quiz

1. Why does overwriting a trusted permission store change the attacker model?
2. How can an injection steer the model without producing a security impact?
3. What additional risk remains when retrieval and tools are correctly authorized?
4. What makes a threat model useful for a release decision rather than just documentation?

Answers: [instructor key](../instructor/answers-01-04.md).

## Primary readings

- [MITRE ATLAS](https://atlas.mitre.org/): adversarial techniques and case-study framing.
- [OWASP AI Agent Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html): agent threats and controls.
- [NIST AI RMF Playbook](https://www.nist.gov/itl/ai-risk-management-framework/nist-ai-rmf-playbook): Govern, Map, Measure, Manage.
- [Microsoft red-team lessons](https://arxiv.org/abs/2501.07238): contextual, human-led assessment.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V04 Episode 1: What is AI Red Teaming? | AI Red Teaming 101 with Amanda and Gary](../MEDIA-LIBRARY.md#v04).
- Read: [B04 Designing AI agents to resist prompt injection](../MEDIA-LIBRARY.md#b04).
- Discuss/critique: [R01 Is AI security a dedicated job or a security-engineering specialization?](../MEDIA-LIBRARY.md#r01).
- Optional short commentary: [X01 MCP prompt-injection risk comes from tool access and untrusted inputs](../MEDIA-LIBRARY.md#x01).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
