# Module 17: Automated Red Teaming

## Prerequisites and outcomes

Bring basic Python testing skills, authorization invariants, and the evaluation-design concepts from earlier modules. Read the [reference lab contract](../reference-lab/CONTRACT.md). This module is 10 hours: concepts 2, practice 5, evaluation 2, writeup 1.

By completion, you will:

1. Translate three threat hypotheses into bounded, reproducible tests with positive and negative controls.
2. Run a deterministic authorization campaign and distinguish denied operations, observed violations, and execution errors.
3. Specify a provider-independent PyRIT or garak extension with explicit scope, budgets, scoring limitations, and stop conditions.

## Automation is an experimental method

Red teaming asks whether an adversary can violate a system's intended boundaries. Automation makes an experiment repeatable; it does not make the experiment comprehensive. Start with a falsifiable claim: “An alpha user cannot read a beta ticket.” Identify the entry point, trusted identity, resource ownership, expected decision, and observable side effect. A jailbreak-looking response is not the same as an unauthorized tool execution. Conversely, a friendly refusal does not prove that retrieval avoided foreign data.

Separate four components. A test producer supplies cases. A target is the system under assessment. An oracle judges an observable property. A recorder preserves the conditions and result. In this course, fixtures produce trusted identities and the target is a deterministic Python authorization simulation. The oracle can inspect exceptions and local state directly. There is no model, model adapter, network endpoint, actual MCP server, or cloud deployment.

For a real model extension, the producer might transform synthetic instructions, and a scorer might classify responses. Those scores are measurements with errors, not verdicts about authorization. Keep application invariants alongside model-behavior evaluations. Record ambiguous outputs separately and review them rather than forcing them into “safe.” Do not count a timeout as a refusal or silently discard an expensive failure.

## Worked example: a bounded campaign

Suppose your campaign has six cases: an owned read, a foreign read, an unapproved write, a reader write, an approved write, and approval replay. Six is the planned fixture count rather than a security benchmark, and the two positive controls are there because a deny-everything implementation would pass the four denial checks while breaking both legitimate workflows.

A valid replay check first proves that the approved operation succeeds. Only its second use should be denied. Otherwise an invalid token could produce a misleading “replay prevented” result. Reset the service for each independent case, but preserve state within the replay sequence. Do not reset away the property being tested.

## Safe lab: build an invariant campaign

### Setup

Work only in your own course checkout with synthetic fixtures. From `reference-lab`, run the contract's unittest discovery command. Save the following as `campaign17.py` in that working directory. It uses the standard library and the supplied local package; install no red-team framework for this lab.

```python
import json
from aisec_lab.fixtures import make_lab
from aisec_lab.errors import PolicyDenied, ArgumentError


def approved_write(s):
    actor = s.identities["alice"]
    args = {"ticket_id": "A-100", "status": "closed"}
    token = s.approvals.issue(
        actor=actor, approver=s.identities["supervisor"],
        tool="update_ticket", arguments=args, ttl_seconds=60)
    s.run_tool(actor, "update_ticket", args, approval=token)


cases = [
    ("read-owned", "allow", "alice", "read_ticket",
     {"ticket_id": "A-100"}),
    ("read-foreign", "deny", "alice", "read_ticket",
     {"ticket_id": "B-200"}),
    ("write-unapproved", "deny", "alice", "update_ticket",
     {"ticket_id": "A-100", "status": "closed"}),
    ("reader-write", "deny", "reader", "update_ticket",
     {"ticket_id": "A-100", "status": "closed"}),
]
for name, expected, actor, tool, args in cases:
    s = make_lab()
    try:
        s.run_tool(s.identities[actor], tool, args)
        observed = "allow"
    except (PolicyDenied, ArgumentError):
        observed = "deny"
    print(json.dumps(dict(case=name, expected=expected,
                          observed=observed)))

s = make_lab()
approved_write(s)  # Unexpected failure stops the campaign.
print(json.dumps(dict(case="write-approved", expected="allow",
                      observed="allow")))
s = make_lab()
a = s.identities["alice"]
args = {"ticket_id": "A-100", "status": "closed"}
t = s.approvals.issue(actor=a, approver=s.identities["supervisor"],
                      tool="update_ticket", arguments=args,
                      ttl_seconds=60)
s.run_tool(a, "update_ticket", args, approval=t)
try:
    s.run_tool(a, "update_ticket", args, approval=t)
    replay = "allow"
except (PolicyDenied, ArgumentError):
    replay = "deny"
print(json.dumps(dict(case="approval-replay", expected="deny",
                      observed=replay)))
```

### Steps and expected observations

1. Execute `python3 campaign17.py` and retain stdout as `campaign17.jsonl` in your learner evidence folder. Expect six records: two allows and four denials. Inspect audit metadata and ticket state, not only printed labels. Unexpected exceptions must remain failures of the campaign, not be reclassified as successful defense.
2. Add an unknown-tool case and a caller-supplied `tenant` argument case. Both must be rejected. Record whether rejection was argument validation or authorization. A shared deny label is useful for this baseline, but insufficient for diagnosis.
3. Add a legitimate second owned read after a denial. Confirm a denied request did not globally disable the service. Repeat the complete campaign with fresh fixtures and compare case-level decisions.
4. Review the approval invariant tests for argument binding, expiry, and single use. Report the actual test names and outcomes. Do not invent a clock API or use a timing race as reproducible expiry evidence.
5. Perform a deliberate oracle mutation: change the expected foreign-read result to allow. Your comparison must flag a mismatch. Separately model a deny-all target in a local test double; positive controls must fail.

### Negative tests and deliverables

Missing cases, duplicate identifiers, malformed JSON, unexpected exceptions, or changed fixture baselines invalidate a campaign summary. Preserve the original run and explain corrections in a new run. Deliver the script, JSONL, baseline revision, interpreter version, case catalogue, side-effect checks, and a one-page coverage statement. State explicitly that these are authorization-invariant results, not LLM attack-success rates, and carry the metadata into [Module 18](18-detection-and-incident-response.md).

### The target, version 1.5

The [multi-turn guard target](../targets/multi_turn/README.md) turns the campaign idea on a different failure: a guard that classifies each prompt on its own while the attack is a conversation. A simulated assistant (regular expressions and a rapport counter, no model) guards a synthetic secret; a supplied fuzzer runs a crescendo, fragment requests, a "no restrictions" persona and a groomed bulk export, each in two forms, plus three benign controls. Run `python3 -m targets.multi_turn.target` to watch the per-turn guard pass every attack and block one benign question. Implement `hardened.py` until `python3 -m targets.multi_turn.check` prints all five flags (the unit of judgement is the trajectory; benign conversations still flow; a persona does not change permissions; partial disclosures add up; the gate reports what it counted). The campaign's bypass rate is a smoke test over eight scripted sequences, not an attack-success rate; say so in the write-up, carry the gate idea into your own CI, and keep the written deliverables for Milestone E, which scores them.

## Framework extensions without accidental scanning

Primary documentation checked on 3 November 2026 shows PyRIT's local install as `pip install pyrit`; its `latest` documentation follows development `main`, so release notebooks may differ. It supports targets, attack strategies, scorers, and conversation memory. Current configuration guidance describes provider credentials and initializers, with persistent configuration under `~/.pyrit/`. Do not paste example credentials into source control.

The NVIDIA garak README currently installs with `python -m pip install -U garak` and describes generators, probes, detectors, and evaluators. It currently uses `--target_type`, `--target_name`, and `--spec`. Crucially, omitting a probe selection can run all probes. Never use scan-all as the course default.

For an optional extension, create a separate virtual environment for the selected framework, verify its installed version, then pin that version and use matching documentation. Consult `pyrit_scan --help` or `python -m garak --help` before constructing configuration. Listing plugins is not an assessment. Select one documented scenario or plugin and one explicitly authorized target. Learners must implement and test any custom simulation-to-framework adapter themselves; none is supplied here.

Budget every actor: target calls, adversarial generation, judges, retries, and multi-turn messages. For an illustrative plan, six objectives with two variants and two attempts require 24 target calls. Add 24 judge calls and 12 generation calls: 60 calls before retries. A 60-call hard cap therefore permits no retries unless work is removed. Also cap estimated total tokens, concurrency, elapsed time, and spend using current provider prices. Reserve budget before dispatch; an uncertain timeout still consumes its reservation. Stop on unauthorized side effects, unexpected sensitive data, scope drift, or exhausted budget. A local provider removes API charges, not resource costs or authorization requirements.

## Evaluating a guardrail

Input and output classifiers (an injection detector, a content-safety model, a rules engine) are the most common "AI security product." They are detectors in Module 18's sense: they produce a label with a false-positive and a false-negative rate, both of which depend on the distribution they see. They are not boundaries. Evaluate one the way this module evaluates anything else: a frozen case set with benign near-misses (quoted attack text, security documentation, code that mentions `curl | sh`), hostile cases that paraphrase rather than copy known payloads, and held-out carriers.

Published results set expectations. A vendor's own model card for a 2025 prompt-injection classifier reports high recall at a one percent false-positive rate on its own set and states that adaptive attackers can evade it; an independent 2025 study found character-level perturbations evading several commercial guardrails at high rates; a 2025 benchmark of context-aware cases found one commercial guard missing everything and another flagging everything. None of that makes classifiers useless. It makes them a measured layer whose numbers you report next to the deterministic invariants, with Module 16's intervals and denominators. With the local model from Module 21 you can run this evaluation at no cost; promptfoo, garak, PyRIT, and Inspect all target local endpoints.

## Mastery gate

Pass only when every declared case is accounted for, positive controls succeed, negative controls reject, oracle mutations fail, and observed side effects agree with decisions. Explain two untested attack surfaces and provide a bounded extension plan. A passing toy campaign alone cannot authorize production release.

## Quiz

1. Why does a deny-all target invalidate an apparently strong denial score?
2. Why must replay testing include a successful first operation?
3. How can an LLM scorer disagree with an application-invariant oracle?
4. Which calls must count toward an automated campaign's budget?

## Primary readings

- [Microsoft PyRIT local installation](https://microsoft.github.io/PyRIT/latest/getting-started/install-local)
- [Microsoft PyRIT configuration](https://microsoft.github.io/PyRIT/latest/getting-started/configuration)
- [NVIDIA garak repository and current README](https://github.com/NVIDIA/garak)

[Instructor answers](../instructor/answers-17-20.md#module-17)

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V04 Episode 1: What is AI Red Teaming? | AI Red Teaming 101 with Amanda and Gary](../MEDIA-LIBRARY.md#v04).
- Do: [L16 Target: the multi-turn guard](../MEDIA-LIBRARY.md#l16) (core, v1.5).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](../MEDIA-LIBRARY.md#b12).
- Discuss/critique: [R02 Getting into AI/LLM security and red teaming](../MEDIA-LIBRARY.md#r02).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
