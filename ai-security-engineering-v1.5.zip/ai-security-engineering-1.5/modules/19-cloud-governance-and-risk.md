# Module 19: Cloud Security, Governance, and Risk

## Prerequisites and outcomes

Bring the campaign evidence from [Module 17](17-automated-red-teaming.md), the telemetry gaps from [Module 18](18-detection-and-incident-response.md), and earlier identity and supply-chain concepts. This module is 10 hours: concepts 2, practice 5, evaluation 2, writeup 1.

By completion, you will:

1. Allocate responsibility for five AI-system controls across application, workload, platform, and supplier boundaries.
2. Evaluate a synthetic identity policy and release decision with explicit fail, unknown, and passed evidence states.
3. Produce an accountable risk register using NIST AI RMF functions without claiming legal compliance or certification.

## Cloud placement does not change the trust problem

A provider may secure physical facilities while your application still retrieves a foreign tenant's document. Managed inference does not decide whether a particular user may update a ticket. Workload credentials identify a service; they do not automatically carry the end-user's authorization context. A broad service account can turn an innocent retrieval query into excessive data access unless application and storage boundaries constrain it.

Draw two kinds of boundary. The control plane changes configuration, identities, deployments, model versions, and logging. The data plane processes requests, retrieves documents, invokes tools, and writes outputs. Separate deployment privileges from runtime privileges. A compromised runtime should not be able to install a new model, disable auditing, export weights, or grant itself additional permissions.

Treat the full data path as part of the inventory: source documents, embeddings, prompt caches, conversation memory, tool results, logs, evaluation corpora, backups, and deletion queues. Encryption is useful but does not authorize a decrypted read. A private endpoint reduces some network exposure but does not enforce tenant isolation. A document digest detects changed bytes relative to an approved digest; it does not prove truthful content or authenticated authorship.

Shared responsibility varies by the chosen service. For a managed service, verify who patches which layer, how customer configurations affect exposure, and what evidence supports inherited controls. Record contractual and technical unknowns about retention, training use, location, subprocessors, incident notice, and deletion. Do not replace these questions with a supplier's generic certification badge.

## Governance is a continuing decision process

NIST AI RMF is voluntary risk-management guidance, not a legal compliance certificate. Its GOVERN, MAP, MEASURE, and MANAGE functions organize responsibilities, context, measurement, and risk treatment. They are interdependent rather than a one-time checklist. GOVERN establishes accountable owners and decision authority. MAP identifies intended uses, stakeholders, harms, dependencies, and boundaries. MEASURE gathers suitable evidence and acknowledges uncertainty. MANAGE prioritizes responses, release limits, monitoring, and retirement.

Security evidence is only part of AI risk. Reliability, privacy, fairness, human oversight, and downstream impacts may need different expertise and measurements. A synthetic authorization lab cannot evaluate all those dimensions. Keep “not evaluated” distinct from “passed.” A risk score made by multiplying arbitrary ordinal labels can hide a catastrophic low-frequency outcome; explain impact and uncertainty before using prioritization shorthand.

OWASP AISVS supplies open, verifiable technical requirements and complements governance; it is not itself a governance or risk-management framework. At the 3 November 2026 source check, the OWASP project page described 1.0 as stable while the repository described 1.01 as stable. Therefore, choose and preserve a specific released artifact, record its version and retrieval date, and do not silently combine sources. This module uses chapter themes, not unverified requirement identifiers or claims of complete AISVS conformity.

## Worked example: user context survives service access

Assume a synthetic workload may retrieve both tenants' approved documents. That broad workload capability is necessary for this fixture, but it is not sufficient to authorize Alice's request. Intersect workload permission with the authenticated user's role and tenant. The following is a miniature local policy illustration, not cloud IAM syntax and not production authentication.

```python
from dataclasses import dataclass
import json


@dataclass(frozen=True)
class Principal:
    id: str
    tenant: str
    role: str


def may_retrieve(actor, resource, workload_actions):
    return bool(actor is not None and
                actor.role in {"reader", "operator"} and
                "retrieve" in workload_actions and
                actor.tenant == resource["tenant"] and
                resource["approved"])


def release(checks):
    blockers = [c["name"] for c in checks
                if c["critical"] and c["state"] != "pass"]
    return {"decision": "NO_GO" if blockers else "REVIEW",
            "blockers": blockers}


alice = Principal("alice", "alpha", "operator")
beta = {"tenant": "beta", "approved": True}
alpha = {"tenant": "alpha", "approved": True}
assert may_retrieve(alice, alpha, {"retrieve"})
assert not may_retrieve(alice, beta, {"retrieve"})
assert not may_retrieve(None, alpha, {"retrieve"})
assert not may_retrieve(alice, alpha, set())
checks = [
    {"name": "tenant isolation", "critical": True,
     "state": "pass"},
    {"name": "supplier retention for proposed extension",
     "critical": True, "state": "unknown"},
]
assert release(checks)["decision"] == "NO_GO"
print(json.dumps(release(checks)))
```

Even after all critical checks pass, the function returns REVIEW, not automatic permission to deploy. Someone with documented authority must decide whether scope, remaining gaps, and operating safeguards support release. Its inputs are declared evidence states; the code does not independently prove them.

## Safe lab: review a proposed cloud migration

### Setup and scenario

Save the example as `govern19.py` and execute it with the standard library. No cloud account, provider key, SDK, model, MCP transport, or infrastructure deployment is required. The actual course system remains the [deterministic reference lab](../reference-lab/CONTRACT.md). The scenario is a proposed migration of its ticket assistant to a managed environment, not a supplied implementation.

### Steps

1. Inventory the local components and separately list hypothetical additions: real identity federation, model endpoint, transport, persistent approvals, vector storage, workload credentials, and log sink. Label each “implemented,” “simulated,” or “proposed.” Fixture authentication and single-process atomicity cannot be promoted to distributed guarantees.
2. Draw a text-only trust-boundary description. Specify which component can issue approvals, what the runtime can read, who can deploy, and who can alter policy. Keep approval authority independent of the model and runtime tool interface.
3. Run the policy example. Expect the owned read to succeed, the foreign and missing-identity reads to fail, the missing-workload-permission read to fail, and the proposed extension to remain NO_GO because retention evidence is unknown.
4. Expand tests with an unapproved document, an unauthorized role, and a foreign document with the same display title. All must reject. Change a workload permission to a literal wildcard; this simple policy must not interpret it as broad permission. Explain how a real platform's wildcard semantics require separate testing.
5. Create five risk records. For each, include asset, failure scenario, harm, existing control, test or review evidence, uncertainty, accountable owner, action, deadline, release relevance, and residual risk. Include cross-tenant retrieval, approval replay across instances, supplier retention uncertainty, compromised deployment credentials, and logging outage.
6. Map your records to the four RMF functions in prose. For tenant isolation, GOVERN identifies the owner, MAP describes tenant data and retrieval boundaries, MEASURE references positive and negative tests, and MANAGE defines remediation and restricted release. Do not claim this mapping fulfills every RMF outcome.
7. Define a release boundary. A local, read-only, synthetic demonstration may be reviewable while a customer-facing extension is blocked. Record who may accept a noncritical exception, its compensating control and expiry. Failed isolation or approval integrity is a no-go, not an ordinary waiver.

### Negative tests and expected observations

Delete a required control record; the review must flag missing evidence rather than treating the reduced list as complete. Change an unknown critical check to a decorative “pending” label; it must remain a blocker. Test a purported provider guarantee with no dated artifact or service scope; mark it unknown. A retention control may be not applicable to the network-free local lab, but that rationale cannot transfer to a provider extension.

Deliver `govern19.py`, `decision19.json`, the negative tests, inventory, responsibility allocation, five-record risk register, source-version note, and a signed-by-role decision record. “Signed-by-role” means identifying the accountable reviewer in this classroom exercise, not generating a legal signature or certificate. Carry the evidence into [Module 20](20-assessment-and-portfolio.md).

## Regulation and standards, as of November 2026

Governance obligations attach to who controls a system and what evidence exists, which is exactly the argument Module 20 asks you to build. Three frameworks matter for an engineer in 2026; none replaces the evidence, and none of this is legal advice.

The EU AI Act's obligations for general-purpose model providers have applied since 2 August 2025. Transparency obligations under Article 50 applied from 2 August 2026, with a grace period for pre-existing systems. The Digital Omnibus on AI (Regulation (EU) 2026/1744, in force 27 July 2026) moved the Annex III high-risk obligations to 2 December 2027 and Annex I embedded systems to 2 August 2028. If you build or deploy an AI system for an EU market, your risk register needs a line that names the tier you believe applies and who decided.

NIST's AI Risk Management Framework remains voluntary and is being revised; its Generative AI Profile and Playbook are already in this course's sources. In February 2026 NIST's Center for AI Standards and Innovation launched an AI Agent Standards Initiative, and its applied-cybersecurity center published a concept paper on agent identity and authorization that proposes existing primitives (OAuth 2.1, OpenID Connect, SPIFFE) for agent principals. That is Module 10's position restated by a standards body.

OWASP's AI Security Verification Standard reached a 1.0 release in June 2026, with a 1.01 revision in progress. Module 20's rule stands: preserve one specific release artifact, cite requirement text rather than numbers alone, and do not claim conformity you did not verify. ISO/IEC 42001 defines an AI management system that organizations can be certified against; it attests to process, not to any particular system's security.

## Mastery gate

Pass when policy controls preserve user context, proposed infrastructure is honestly labeled, critical failures and unknowns block the relevant release, and every residual risk has an owner and review condition. Fail if cloud hosting is used as evidence of application authorization, supplier badges replace service-specific due diligence, or NIST alignment is called legal compliance.

## Regulation readings

- [European Commission: AI Act regulatory framework](https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai): authoritative dates, updated October 2026.
- [Future of Life Institute: AI Act implementation timeline](https://artificialintelligenceact.eu/implementation-timeline/): an independent tracker of the same dates.
- [NIST: AI Agent Standards Initiative](https://www.nist.gov/caisi/ai-agent-standards-initiative), February 2026.
- [OWASP AISVS repository](https://github.com/OWASP/AISVS): release artifacts and the 1.0/1.01 status.

## Quiz

1. Why are workload identity and end-user identity both needed?
2. What distinguishes a passed control, unknown evidence, and justified nonapplicability?
3. How do AISVS and NIST AI RMF serve different purposes?
4. Why does an all-pass input still lead to REVIEW in the example?

## Primary readings

- [NIST AI Risk Management Framework overview and resources](https://www.nist.gov/itl/ai-risk-management-framework)
- [AWS Well-Architected shared responsibility guidance](https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/shared-responsibility.html)
- [OWASP AISVS repository and release guidance](https://github.com/OWASP/AISVS)
- [OWASP AISVS access-control chapter, versioned source](https://github.com/OWASP/AISVS/blob/main/1.01/en/0x10-C05-Access-Control-and-Identity.md)

[Instructor answers](../instructor/answers-17-20.md#module-19)

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V43 Introduction to the NIST AI Risk Management Framework (AI RMF 1.0): An Explainer Video](../MEDIA-LIBRARY.md#v43) (core, v1.3).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](../MEDIA-LIBRARY.md#b12).
- Discuss/critique: [R04 Prompt injection in a self-hosted LLM deployment](../MEDIA-LIBRARY.md#r04).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
