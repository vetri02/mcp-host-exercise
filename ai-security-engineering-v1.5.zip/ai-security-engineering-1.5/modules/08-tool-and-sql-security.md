# Module 08: Tool Security and Generated SQL

## Prerequisites and measurable objectives

Complete [Modules 05](05-prompt-injection.md), [06](06-rag-authorization.md), and [07](07-knowledge-poisoning.md). You should understand resource authorization, independent approval, Python exceptions, and basic SQL selection.

By the end of this ten-hour module, you will:

1. Enforce tool-specific schemas and resource permissions independently of a proposed action's wording.
2. Demonstrate actor-, argument-, and single-use approval boundaries using the deterministic reference lab.
3. Build a small, constrained SQLite extension and explain why parameter binding does not authorize arbitrary generated SQL.

Allocate two hours to concepts and readings, five to practice, two to evaluation and quiz work, and one to the final writeup.

## A proposal is not a capability

Tools convert language into effects. Even a read operation can expose information; a write can change records or create an artifact that influences later decisions. If the application executes anything a model proposes under a broad service credential, the model has become a confused deputy: lower-trust input steers an actor holding greater authority.

Use three independent questions. Is this caller allowed to invoke this tool? Are the arguments well formed and restricted to permitted resources? Does this particular effect require a fresh independent approval? A valid JSON object answers none of those questions by itself. A perfectly formatted request can still name another tenant's ticket.

Define a closed tool registry rather than discovering arbitrary functions from a proposed name. Reject unknown keys so that an unexpected `tenant`, `actor`, or `command` cannot silently change execution context. Validate types and permitted values; obtain the principal from the application's trusted identity path. Then resolve the resource and check its ownership and role requirements at execution time.

Approval should bind actor, tenant, tool, canonical arguments, expiry, and single use. Canonicalization makes semantically identical validated argument objects comparable despite key order. It must not discard meaningful fields or allow duplicate or ambiguous representations. An approval for closing ticket A-100 must not authorize another ticket or a different tool.

The trusted approval component is not itself a model-invocable shortcut. An independent approver reviews the actual effect and the relevant resource, not merely a fluent explanation. If arguments change after approval, require new approval. Recheck authorization when executing because permissions may have changed while the request waited.

The reference simulator consumes approvals atomically in one process. Real deployments need transactional or equivalent concurrency controls across workers and durable state. Approval replay protection and idempotency solve different problems: consuming a token once does not automatically prevent duplicate effects caused by retries around a partially completed transaction.

## Worked example: closing a synthetic ticket

In the supplied [reference lab](../reference-lab/CONTRACT.md), Alice is an Alpha operator and the supervisor is an independent Alpha approver. A reader lacks write authority. These identities are fixtures, not authenticated browser sessions. Run this from `reference-lab`:

```python
from aisec_lab.fixtures import make_lab
from aisec_lab.errors import PolicyDenied

s = make_lab()
alice = s.identities["alice"]
supervisor = s.identities["supervisor"]
args = {"ticket_id": "A-100", "status": "closed"}
token = s.approvals.issue(
    actor=alice, approver=supervisor,
    tool="update_ticket", arguments=args, ttl_seconds=60,
)
s.run_tool(alice, "update_ticket", args, approval=token)
try:
    s.run_tool(alice, "update_ticket", args, approval=token)
except PolicyDenied:
    pass
else:
    raise AssertionError("approval replay succeeded")
```

The first call should perform the simulated update; the replay should fail. The opaque token is sensitive: do not print it or include it in the evidence package. The lab has no actual LLM, MCP transport, SQL executor, email delivery, or shell. Its `draft_email` tool stores a dictionary in an in-memory outbox; it does not contact a recipient.

## Generated SQL: structure is also authority

A model-generated statement can contain unauthorized tables, joins, predicates, functions, or operations. Parameter binding separates values from SQL syntax in a statement whose structure the developer controls. It does not make arbitrary statement text safe. A bound query can still select another tenant's rows if the statement omits the tenant predicate.

Prefer constrained intent such as `list_open_tickets` with bounded parameters, compiled into a fixed query by trusted code. If free-form SQL is genuinely necessary, treat it as a separate high-risk design requiring parsed structural policy, restricted database privileges, resource limits, and careful review. Keyword checks such as “starts with SELECT” are insufficient: a read can still expose sensitive data or consume excessive resources.

## Safe lab: policy gateway plus SQLite extension

Work only in a local synthetic environment. First run the supplied baselines:

```bash
python3 -m unittest discover -s tests -v
python3 -m aisec_lab.demo --mode hardened
```

The following SQLite exercise is an extension you create, not functionality prebuilt into the reference service. It uses Python's standard-library `sqlite3` and an in-memory database only. Save it as `bounded_query.py` in your own workspace.

```python
import sqlite3

SQL = """SELECT id, title FROM tickets
         WHERE tenant = ? AND status = ?
         ORDER BY id LIMIT ?"""

def list_tickets(db, trusted_tenant, status, limit):
    if status not in {"open", "closed"}:
        raise ValueError("unsupported status")
    if type(limit) is not int or not 1 <= limit <= 10:
        raise ValueError("invalid limit")
    return db.execute(SQL, (trusted_tenant, status, limit)).fetchall()

with sqlite3.connect(":memory:") as db:
    db.execute("""CREATE TABLE tickets
                  (id TEXT, tenant TEXT, status TEXT, title TEXT)""")
    db.executemany("INSERT INTO tickets VALUES (?, ?, ?, ?)", [
        ("A-100", "alpha", "open", "Printer demo"),
        ("B-200", "beta", "open", "Synthetic private issue"),
    ])
    db.commit()
    db.execute("PRAGMA query_only = ON")
    assert list_tickets(db, "alpha", "open", 5) == [
        ("A-100", "Printer demo")
    ]
    assert db.execute(SQL, (
        "alpha", "open' OR 1=1 --", 5
    )).fetchall() == []
```

The malicious-looking status is a literal value, so it matches no row. In the public function it should instead fail the status allowlist. The tenant parameter must come from trusted caller identity; this function does not authenticate its string argument. `query_only` is defense in depth, not a complete sandbox or an authorization system, and trusted code can turn it off.

### Five-hour procedure and expected outcomes

Use hour one to run the approved update example and inspect structured audit outcomes without tokens. Use hour two to build isolated tests for a missing approval, a reader attempting a write, a foreign ticket B-200, an unknown tool, and an extra `tenant` argument. Catch the expected policy or argument exception, then verify that ticket state and the outbox remain unchanged. Do not let any exception count as success without checking its cause.

In hour three, test approval binding using fresh fixtures for each case. Change one valid argument, substitute Bob as actor, and attempt a different tool. Each misuse must fail. Use the supplied invariant tests for expiration and single-use behavior; do not substitute a long sleep for a controlled expiry test. Confirm that a newly issued legitimate approval still works.

In hour four, run the SQLite snippet and add negative tests for an unsupported status, zero limit, boolean limit, and excessive limit. A Beta caller should retrieve only B-200 when the trusted tenant is Beta. Do not accept model-provided table names, tenant scopes, or SQL fragments. Check a write under `query_only` fails, while recognizing that the fixed template is the stronger application boundary here.

In hour five, describe optional extensions: a database authorizer restricting tables and operations, a truly read-only database connection, query cancellation budgets, and an isolated execution service. These are not supplied controls. SQLite's in-memory example does not implement production row-level security or a safe arbitrary-SQL evaluator.

### Evaluation and deliverables

Submit tool tests with expected denial reasons, evidence that denied operations preserve state, the bounded-query script, and a bullet-list threat model. Include a positive control for both tools and SQL. Identify the exact transition where proposal data becomes an authorized effect. Explain which production controls remain missing rather than presenting passing assertions as deployment approval.

## Mastery gate

Pass when malformed and unauthorized tool calls fail without effects, approval replay fails, legitimate approved calls work, and SQL requests cannot change query structure or tenant scope. Explain both parameter binding's guarantee and its limit. Replacing these checks with a model's statement that an action is safe does not pass.

## Quiz

1. Why does valid tool-call JSON not establish authorization?
2. Why must an approval bind canonical arguments as well as the tool name?
3. What can parameter binding prevent, and what can it not authorize?
4. Why are token single use and operation idempotency different controls?

## Primary-source reading

- [OWASP Top 10 for Agentic Applications, 2026](https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026): connect tool authority to agentic risks.
- [OWASP AI Agent Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html): review approval and least-privilege boundaries.
- [MCP security best practices](https://modelcontextprotocol.io/specification/latest/basic/security_best_practices): study protocol integration as a separate production extension.

[Instructor answers for modules 05-08](../instructor/answers-05-08.md) provide reasoning and assessment guidance.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V39 BSidesSF 2025 - GenAI Application Security: Not Just Prompt Injection (Ahmed Abugharbia)](../MEDIA-LIBRARY.md#v39) (recommended, v1.3).
- Watch: [V13 Prompt Injection, explained](../MEDIA-LIBRARY.md#v13).
- Read: [B10 Demystifying evals for AI agents](../MEDIA-LIBRARY.md#b10).
- Discuss/critique: [R03 Evaluating agentic AI security before production](../MEDIA-LIBRARY.md#r03).
- Optional short commentary: [X02 Design patterns for securing LLM agents: discussion and paper notes](../MEDIA-LIBRARY.md#x02).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
