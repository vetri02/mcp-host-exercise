# Module 10: MCP Identity, Authorization, and Supply-Chain Boundaries

## Prerequisites and learning objectives

Bring HTTP and OAuth vocabulary, Python exception tests, and [approval binding from Module 09](09-agent-memory-and-approvals.md). Read the [reference-lab contract](../reference-lab/CONTRACT.md). The supplied lab is a deterministic authorization simulator, not an MCP server, OAuth implementation, or language model.

By the end, you will be able to:

1. Distinguish token audience, resource-owner subject, client identity, scope, and application-level resource authorization.
2. Build offline negative tests for wrong-audience credentials, identity substitution, passthrough, and tool-manifest changes.
3. Specify a separately built local MCP integration with bounded privileges and attributable callers.

This module is **10 hours**: concepts 2, practice 5, evaluation 2, writeup 1. The protocol guidance below was inspected on 3 November 2026. The `latest` specification is mutable; record its resolved version when implementing an extension.

## A protocol is not an authority boundary

MCP standardizes how a host connects clients to servers exposing tools, resources, and prompts. The host remains responsible for deciding which servers to connect, what information they see, and which actions require review. A useful tool description is not proof that its publisher, package, or returned data is trustworthy.

Follow a request through separate boundaries: user to host, client to MCP server, and server to downstream service. Authentication at one boundary does not automatically establish identity at the next. A server with powerful downstream credentials can become a confused deputy if it performs every requested operation using its own privileges without checking the caller's entitlements.

Tool discovery is also input. Descriptions, parameter schemas, and results can contain misleading instructions. Keep policy outside those strings. Bind a reviewed tool to server identity, tool name, schema, and allowed effects. A changed manifest should trigger review or disable execution, not silently inherit the previous approval. Naming collisions should resolve through a server-qualified registry, not whichever description sounds more persuasive.

## OAuth: where, who, and what are different

The MCP Authorization specification's **Resource Parameter Implementation** requires the client to include `resource` in both authorization and token requests, identifying the intended MCP server. A requested scope describes access, not the token's recipient. A token carrying `tickets:read` can still be for an entirely different service.

The same specification's **Token Handling** requires the MCP server to validate access tokens and their intended audience. It must accept only tokens valid for its own resources, and must not accept or transit other tokens. Invalid or expired credentials receive HTTP 401; valid credentials with insufficient scope or permissions are an authorization failure, normally HTTP 403. Do not make an unauthorized resource distinguishable through verbose error content.

For JWT access tokens following **RFC 9068 section 4**, validate the access-token type, trusted issuer, expected audience, permitted cryptographic algorithm and signature, and expiry. Decoding a JWT is not validation. An ID token is not a substitute for an access token. Tokens can also be opaque; validate them through the deployment's trusted mechanism rather than assuming all tokens contain readable claims.

**RFC 9068 section 2.2** distinguishes `sub` from `client_id`. With a resource owner involved, `sub` should identify that owner; with client credentials, it should identify the client application according to the issuer's policy. `client_id` identifies the OAuth client. Do not infer a human user solely from a service token. Bind local policy identities to validated issuer-and-subject pairs and validated client identity as appropriate. Tenant membership and resource access still require trusted application policy; neither a prompt nor a tool argument may supply them.

OAuth bearer possession does not prove which physical process is using a stolen token. Preserve validated subject and client information for authorization and audit, but state this limitation. Caller identity is not a request's JSON `actor`, a model claim, or possession of a state handle. The MCP Security Best Practices **State Handle Hijacking** section requires user binding and checking inbound requests instead of treating handles as authentication.

## No token passthrough

The MCP Security Best Practices **Token Passthrough** section explains why accepting a token intended for a downstream API and forwarding it unchanged is forbidden. It erases a resource boundary and confuses accountability. The upstream token should be intended for the MCP server; any downstream credential must be independently obtained for its downstream audience under an explicit delegation or service-identity design.

This is not accomplished by editing `aud` in a token. The downstream issuer must authorize and issue the credential. Record the originating caller, MCP server, and downstream identity without logging bearer secrets. If the server is an OAuth proxy, per-client consent also matters: prior user consent to the proxy's static downstream client must not stand in for consent to every new MCP client.

## Supply chain and transport

A local server package executes code with the privileges granted to its process. “Local” is not “safe.” Review the exact executable, arguments, dependency versions, source, and update path. Pin reviewed artifacts, keep a dependency inventory, and avoid installation commands suggested by untrusted tool content. Signatures or hashes support artifact integrity, not benevolent behavior.

HTTP authorization guidance does not automatically apply to stdio. The MCP authorization specification describes HTTP transports and says stdio should instead retrieve credentials from its environment. Environment credentials still need least privilege and secret-safe handling; never inject production credentials into this course. Isolate local server processes and restrict inherited environment, files, and egress, as developed in [Module 12](12-isolation-and-resource-limits.md).

## What 2025 and 2026 added to the list

Tool poisoning (Invariant Labs, April 2025) put a sharp edge on "tool discovery is input." A tool description is read by the model and usually not shown to the user, so it is a hidden instruction channel. A demonstration description told the agent to read the user's SSH private key and pass it in an innocuous-looking extra argument. Tool shadowing is the same trick across servers: one server's description changes how the agent uses another server's tool. Rug-pull configurations extend it over time: a server that was benign when approved changes its manifest later. The control is the one above, made concrete: pin a digest of each reviewed description and schema, render the description to the approver, and disable execution when the digest changes.

Two incidents showed the confused deputy in production. An agent asked to review issues in a public repository followed an issue's instructions, read the user's private repositories through the same connection, and leaked their contents into a public pull request; the mitigation was a per-session policy binding the connection to one repository. A database integration ran with a service role that bypassed row-level security, so a support ticket's text was enough to make the agent dump an integration-tokens table into a visible message. Both are Module 02's rule, the executor must carry the end user's authority and no more, violated at the integration layer.

Several IDE agents were also found to start project-defined MCP servers automatically when a folder opened. Module 22 treats that as a coding-agent configuration problem; from this module's view it is an unreviewed manifest executing with local privileges.

## Worked example: audience is independent of scope

This is an offline policy predicate over **already trusted fixture records**, not JWT verification or an OAuth implementation:

```python
def fixture_identity(record, expected_audience, now):
    if record['issuer'] != 'fixture-issuer':
        raise ValueError('issuer rejected')
    if expected_audience not in record['audiences']:
        raise ValueError('audience rejected')
    if now >= record['expires_at']:
        raise ValueError('expired')
    return record['subject'], record['client_id']
```

A fixture with `tickets:read` scope but audience `downstream-fixture` must fail when the expected audience is `mcp-fixture`. Keep these identifiers as labels, not URLs to contact. A successful predicate does not grant permission to B-200: map the result through a trusted local identity registry and let `AgentService` enforce tenant and role policy. Never let a caller submit this supposedly verified record as real credentials.

## Safe lab: an offline MCP boundary extension

**Setup.** Run the reference tests from `reference-lab`. In a separate learner-owned directory, build an offline authorization-and-dispatch harness around `make_lab()`. It is an extension you author, not prebuilt MCP functionality. Use only synthetic fixture credentials, fixed manifests, and in-memory requests. No external network, real issuer, package download, or live model is needed.

**Practice steps, five hours.**

1. Create a trusted fixture registry mapping opaque test credential labels to issuer, subject, client, audience, expiry, and scopes. Accept credentials only through that registry. Use a fixed clock so time tests are reproducible. Keep the intentionally insecure “decode and trust” path separate and clearly labeled.
2. Define one approved server-qualified `read_ticket` manifest with an exact argument schema. Your dispatcher must select the authenticated principal from the registry, not request arguments, and call the supplied service. Check scope before dispatch and retain its resource authorization checks.
3. Test an Alpha operator reading A-100 successfully. Test missing, unknown, expired, wrong-issuer, and wrong-audience credentials. Then test insufficient scope, Alpha access to B-200, caller-supplied `actor` or `tenant`, and a valid reader attempting an update. Assert no rejected request changes state.
4. Add a fake downstream recorder. Verify that a downstream-audience token is never accepted upstream and that the incoming credential is never forwarded. Any separately configured downstream fixture credential must have the downstream audience and preserve attribution metadata without recording secrets.
5. Modify a tool description, change a schema, and shadow a tool name under a different server identity. Deny unreviewed versions. Test a stolen workflow handle under a different principal. A handle must not change the authenticated caller.

**Actual MCP implementation is a separate extension.** If you implement a real transport, use a separately reviewed SDK or implement the protocol in a separate project. Prefer local stdio to avoid opening a listening service. Use prerecorded request fixtures and synthetic data, prohibit external network, and document protocol/version conformance independently. The offline harness is not evidence of wire-protocol or cryptographic correctness; never call it an OAuth server.

**Expected observations and deliverables.** Valid reads work; authentication failures precede dispatch, while scope and tenant denials remain independent. Manifest changes require review, and downstream recordings contain no upstream bearer credential. Submit executable offline tests, a boundary diagram in text, the reviewed manifest and digest, and a caller-identity mapping specification. Include a transport-extension plan and an explicit list of untested guarantees.

### The target, version 1.5

The [MCP host target](../targets/mcp_shield/README.md) is the vulnerable counterpart of this lab: a host that shows the model every tool two servers announce, routes by bare name, forwards the user's upstream token, passes arguments through, and executes whatever `next_call` a result asks for. Run `python3 -m targets.mcp_shield.target` from the course root and read the six observations. Implement `hardened.py` until `python3 -m targets.mcp_shield.check` prints all five flags (only pinned definitions reach the model; a changed definition is a new tool; the upstream token never leaves the host; a result is data, not a call; arguments meet the pinned schema), then do step 5 above with your host in place of the harness and keep the written deliverables for Milestone C, which scores them.

## Evaluation and mastery gate

Spend two hours reviewing the distinction between authentication failures and authorization denials, then one hour documenting results. Pass only if all negative fixtures fail closed without side effects, no incoming credential reaches the downstream recorder, and you correctly distinguish subject, client, audience, and tenant. Claiming cryptographic validation or MCP conformance from fixture tests fails the gate.

## Quiz

1. Why can a correctly signed token with the right scope still be unacceptable?
2. How do `sub` and `client_id` differ, especially with client credentials?
3. Why is downstream-token passthrough forbidden, and what replaces it?
4. Which parts of a tool-manifest change require renewed review?

See the [instructor key](../instructor/answers-09-12.md) and [output security](11-leakage-and-output-security.md).

## Primary-source readings

- [MCP Authorization, Token Handling](https://modelcontextprotocol.io/specification/latest/basic/authorization#token-handling), together with Resource Parameter Implementation and Protocol Requirements on the same page.
- [MCP Security Best Practices, Token Passthrough](https://modelcontextprotocol.io/specification/latest/basic/security_best_practices#token-passthrough), together with Confused Deputy Problem, State Handle Hijacking, and Local MCP Server Compromise.
- [RFC 9068 section 2.2: JWT access-token claims](https://www.rfc-editor.org/rfc/rfc9068.html#section-2.2), especially `sub` and `client_id`.
- [RFC 9068 section 4: validating JWT access tokens](https://www.rfc-editor.org/rfc/rfc9068.html#section-4), for the resource server's exact validation requirements.
- [Invariant Labs: MCP tool poisoning attacks](https://invariantlabs.ai/blog/mcp-security-notification-tool-poisoning-attacks) and [the GitHub MCP incident](https://invariantlabs.ai/blog/mcp-github-vulnerability), April and May 2025.
- [Willison: the Supabase MCP lethal trifecta](https://simonwillison.net/2025/Jul/06/supabase-mcp-lethal-trifecta/), July 2025.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V42 Security in Model Context Protocol: An Analysis of the OWASP MCP Top 10](../MEDIA-LIBRARY.md#v42) (core, v1.3).
- Watch: [V38 OAuth 2.0 and OpenID Connect (in plain English)](../MEDIA-LIBRARY.md#v38) (core, v1.3).
- Do: [L15 Target: the MCP host](../MEDIA-LIBRARY.md#l15) (core, v1.5).
- Read: [B01 The lethal trifecta for AI agents: private data, untrusted content, and external communication](../MEDIA-LIBRARY.md#b01).
- Discuss/critique: [R06 Handling MCP authorization-boundary failures](../MEDIA-LIBRARY.md#r06).
- Optional short commentary: [X01 MCP prompt-injection risk comes from tool access and untrusted inputs](../MEDIA-LIBRARY.md#x01).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
