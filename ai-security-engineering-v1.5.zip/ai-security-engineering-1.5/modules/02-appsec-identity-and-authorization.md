# Module 02: Application security, identity, and authorization

## Prerequisites and outcomes

Complete Module 01 and its state-based tests. Spend ten hours using the course's two/five/two/one reading, building, testing, and writing rhythm. At completion you can: (1) separate authentication, authorization, approval, and audit; (2) implement and test resource-level authorization independently of a model; (3) explain why read-only access and encrypted storage are insufficient for tenant isolation.

## Lesson: authority belongs to the application

Identity answers who is calling. Authorization answers whether that caller may perform this action on this resource now. Approval adds a deliberate decision for an otherwise permitted high-impact action. Audit records what was requested, decided, and executed. These are different controls. An approval should not turn a forbidden action into a permitted one, and a log should not be mistaken for prevention.

Consider a support application with alpha and beta tenants. Alice is an alpha operator. Bob is a beta operator. Both may read tickets, but that does not mean either may read all tickets. A role check alone is insufficient: role operator must be combined with tenant membership and resource ownership. Conversely, tenant membership alone does not authorize a reader to close a ticket, which is why application policy has to compose these attributes rather than check any one of them.

The reference lab demonstrates a small combination of role-based and attribute-based checks. Its policy requires a trusted principal, an allowed tool, exactly the expected argument keys and types, an existing own-tenant resource, an appropriate role, and independent approval for simulated writes. The order is explicit and denial is the default. A model cannot add itself to the identity set by producing an actor field, and the tool schema rejects that extra field.

In production, a principal comes from verified authentication rather than Python object identity. Roles, membership, and resource classification must come from authoritative stores. A model-generated tenant filter is not authoritative. Never combine a client-supplied tenant with a resource query and assume the query is scoped; an attacker can choose the other tenant. Derive the tenant from a validated session or delegated authorization context, and enforce it at each data access path.

## Broken object and function authorization

Object authorization governs access to a particular record. Function authorization governs access to an operation. Reading ticket B-200 as an alpha user is an object-level failure. Calling a privileged export tool as a reader is a function-level failure. An AI assistant can amplify both because natural language makes operations easier to discover and compose, but the root controls are conventional application security.

Test all paths, not just the chat endpoint. Direct tool calls, background jobs, batched exports, retrievers, caches, administrative endpoints, and internal service calls can bypass the visible UI. If the policy exists only in a prompt or chat controller, those other paths may remain open. A shared policy layer helps, but it must be invoked at the actual execution boundary and validated by negative tests.

Read-only credentials prevent changes, not disclosure. A read-only database connection with access to every tenant can still expose every tenant. Encryption at rest protects stored bytes from certain storage threats and does nothing to stop an authenticated service from retrieving the wrong customer's plaintext. Output filtering acts after access and should not be the main authorization mechanism.

## Session and token fundamentals

OAuth provides delegated API authorization; OpenID Connect supplies an identity layer. An ID token is not a general-purpose API access token. A service should validate access-token audience and scope before accepting it, and then enforce resource policy. Avoid token passthrough to unrelated services. A token valid for one resource is not automatically valid for another.

For user-facing applications, prefer maintained identity middleware and secure session management. Protect against CSRF where cookies confer authority. Use short-lived scoped credentials for downstream tools rather than a universal service administrator account. Credentials are capabilities: whoever holds them may exercise their permissions. Do not place them into model context or logs.

Two words from the security literature make this precise. Ambient authority is permission a component has merely because of where it runs: a service account in the environment, a database connection every tool shares. A capability is authority carried by an unforgeable reference to one specific thing. An agent with ambient authority turns every injected instruction into that authority's full reach; scoped, short-lived tokens and single-use approvals (Modules 08 and 09) are capability-style designs that shrink what any one manipulated step can do. When a component uses its own broad authority to act on a caller's behalf without checking the caller's entitlement, it is a confused deputy. Most of the course's attack chains are confused-deputy chains.

OAuth has four parties: the resource owner (the user), the client (your application), the authorization server (which issues tokens after consent), and the resource server (your API). An access token is a bearer credential: whoever holds it can use it, so its issuer, audience (which resource server), scope (which operations), and expiry are the only things limiting damage. OpenID Connect adds an ID token asserting who logged in to the client, and that token is meant for the client rather than for APIs, a distinction Module 10 builds on.

The relevant question for an agent is whose authority each action uses. A service account might authenticate the connection while the user's permissions still need to govern the operation. Logging only the service account loses that distinction. Preserve the initiating principal and delegated scope through every hop.

## Worked policy example

A policy decision can be expressed as a conjunction:

~~~text
allow = authenticated_context
        AND tool_is_allowed
        AND arguments_match_contract
        AND resource.tenant == principal.tenant
        AND role_allows_action
        AND (action_is_low_impact OR exact_action_is_approved)
~~~

This is a design explanation, not a production policy language. Each term needs an authoritative source and a test. If the permission service is unavailable, a high-impact execution should not silently proceed. Define error behavior deliberately: fail closed for privileged actions, communicate a temporary failure, and record the policy-dependency outage.

## Lab: permission matrix and bypass testing

Use the reference lab from its directory. Read service.py and tests/test_security.py. Create a permission matrix covering six fixture principals, three tools, own-tenant and foreign-tenant resources, and approval states. Record expected allow or deny before running tests. A matrix can be a CSV rather than a large prose list.

Step 1: show that Alice can read A-100 and Bob can read B-200. Step 2: show that both foreign reads are denied with a generic resource-not-available reason. Step 3: demonstrate that reader cannot update A-100, even though it is in the same tenant. Step 4: issue a legitimate supervisor approval for Alice and verify that it cannot authorize another actor or a foreign resource. Step 5: call run_tool directly to show that protections do not depend on a chat front end.

Add negative tests for an extra actor argument, an extra tenant argument, an unknown tool, a nonexistent object, and a foreign object. The generic response for nonexistent and foreign resources should avoid revealing existence, but do not call this perfect side-channel resistance: timing and other signals require separate analysis, and inspect state after every denied write.

A side channel leaks information through an observable that is not the response body: latency, response length, token count, error type, or whether a cache was warm. If "not found" returns in 5 ms and "forbidden" in 40 ms because the second path loaded the record first, the existence of foreign resources is disclosed. Make denial paths structurally similar, and treat timing as a residual risk you measure rather than assume away.

Extension: build a small authenticated HTTP adapter using a maintained framework and test client. This is learner-built, not included. Map a verified test session to a principal on the server side. Use synthetic sessions only. Never accept a role or tenant from the request body. Keep the adapter bound to loopback and do not deploy the deliberately vulnerable component.

## Expected observations and deliverables

Role and tenant checks block different requests. Independent approval does not replace either check. Direct calls are still governed. The same principal can be allowed to read and denied to update. Caller-controlled argument keys cannot replace trusted identity.

Deliver: the permission matrix; at least eight allowed/denied cases with state evidence; an explanation of identity provenance; and a note on policy dependency failure. If your extension supports delegation, show the original user and service identity separately in the trace.

## Mastery gate

You must explain and demonstrate why read-only SQL access, encrypted storage, an instruction to respect permissions, and a supervisor approval are each insufficient on their own. The gate fails if any unauthorized write changes state or if any foreign record reaches an unauthorized caller.

## Quiz

1. What is the difference between object-level and function-level authorization?
2. Why can a read-only database account still cause a serious security incident?
3. When should user identity be derived, and from what source?
4. Why should approval not override a failed ownership check?

Use [the instructor key](../instructor/answers-01-04.md) after attempting the questions.

## Primary readings

- [OWASP Authorization Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html).
- [OWASP OAuth2 Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/OAuth2_Cheat_Sheet.html).
- [RFC 9700: OAuth 2.0 Security Best Current Practice](https://www.rfc-editor.org/rfc/rfc9700).
- [OWASP AI Agent Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html).

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V38 OAuth 2.0 and OpenID Connect (in plain English)](../MEDIA-LIBRARY.md#v38) (core, v1.3).
- Read: [B05 Propagating SharePoint Document Permissions to AI Search and RAG Pipelines](../MEDIA-LIBRARY.md#b05).
- Discuss/critique: [R01 Is AI security a dedicated job or a security-engineering specialization?](../MEDIA-LIBRARY.md#r01).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
