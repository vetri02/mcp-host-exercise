# Module 01: Python, HTTP, and security testing foundations

## Prerequisites and outcomes

This chapter assumes basic programming literacy. If functions, dictionaries, exceptions, command-line navigation, and Git commits are unfamiliar, complete the [foundation bridge](../FOUNDATION-BRIDGE.md) first. Allocate ten hours: two for concepts, five for implementation, two for testing, and one for evidence.

By the end, you can: (1) trace untrusted data through a Python function and identify an effect; (2) express a security invariant as a test that checks state, not just text; (3) explain where an HTTP service must obtain identity and where authorization belongs.

## Lesson: the security boundary is where data becomes authority

A program receives bytes, interprets them, makes decisions, and changes state. Security is about which interpretations and effects are permitted. An LLM adds a probabilistic interpreter to this pipeline; it does not remove the need for deterministic decisions. When a model emits a tool request, treat it as a proposed request from an untrusted caller, not as a trusted program instruction.

Start by distinguishing values, control flow, and effects. A dictionary containing a ticket identifier is a value. Choosing a function from an allowlist is control flow. Changing a database row, sending a message, or reading a private record is an effect. A secure design checks permission before the effect and records what actually happened. If a model proposes a valid JSON object that names another customer's record, the object can be syntactically valid while the action remains unauthorized.

Python makes prototypes easy, but convenience can hide boundaries. Avoid mutable default arguments, catch only exceptions you understand, and preserve clear types at component interfaces. A broad exception handler that returns success can transform a denied operation into a misleading result. Conversely, a crash is not automatically a demonstrated exploit: record whether it changes state, exposes data, or causes availability impact.

The reference lab uses PolicyDenied for controlled denials and ArgumentError for invalid tool arguments. ArgumentError is a kind of PolicyDenied, so callers can uniformly handle safe rejection. The flip side is that `except PolicyDenied` also swallows validation errors; when a later campaign needs to count the two separately (Modules 09 and 17), catch ArgumentError first or inspect the exception type. These error codes contain no raw document text or credentials. In a real HTTP adapter, convert them into appropriate generic responses while retaining a protected internal trace. Do not expose stack traces or foreign-resource existence to an unauthorized caller.

## HTTP, identity, and request context

An HTTP request has a method, path, headers, and sometimes a body. All are attacker-controlled until a trusted component validates them. A JSON field named user_id, tenant, or role is not proof of identity. A header is not trusted merely because its name looks internal; an edge proxy must remove externally supplied copies before adding a trusted identity header, and the application must only accept traffic from that proxy.

Authentication establishes a subject. Authorization evaluates that subject's ability to perform a particular action on a particular resource. Do not confuse a signed token with unrestricted access: validate its signature, issuer, audience, lifetime, and intended use, then evaluate application permissions. Use a maintained identity library rather than implementing cryptographic verification in this course. The offline lab intentionally represents authentication with trusted fixture objects. It is not a login system.

Safe request handling is a pipeline: parse bounded input; derive identity from the authenticated session; validate the proposed action; load the resource through an authorized path; evaluate policy; execute; log a redacted result. This order matters. Loading a private document into model context before checking permissions already discloses it to that component, even if a later answer filter hides it from the user.

## Worked example: assert the effect

From the reference-lab directory, use the supplied objects:

~~~python
from aisec_lab.fixtures import make_lab
from aisec_lab.errors import PolicyDenied

s = make_lab()
alice = s.identities['alice']
before = s.tickets['B-200'].status
try:
    s.run_tool(alice, 'update_ticket',
               {'ticket_id': 'B-200', 'status': 'closed'})
except PolicyDenied:
    pass
else:
    raise AssertionError('Expected an authorization denial')
assert s.tickets['B-200'].status == before
assert not s.outbox
~~~

The important assertions inspect the protected record and outbox. An assertion that the response contains the word denied is weaker: a program could print that word after performing the effect. This pattern also explains why an LLM claiming to have deleted something is not enough evidence of deletion.

## Lab: establish your reproducible workspace

Use Python 3.10 or newer. The reference lab has no third-party dependencies and makes no network calls. Extract the course package into a personal working folder, open a terminal in reference-lab, and run:

~~~bash
python3 -m unittest discover -s tests -v
python3 -m aisec_lab.demo --mode hardened
python3 -m aisec_lab.demo --mode vulnerable
python3 -m aisec_lab.evaluate
~~~

The vulnerable demonstration explicitly opts into an unsafe synthetic component. It reads a beta-tenant canary using an alpha principal and changes a synthetic foreign ticket. The hardened demonstration allows an own-tenant read, rejects the foreign read, and permits an independently approved own-tenant update. No email is sent, no provider is contacted, and no real customer record exists.

Step 1: record your Python version, operating system, course version, and command outputs. Step 2: read `fixtures.py` and `errors.py` in `reference-lab/aisec_lab/`, and one cross-tenant test. Draw the path from a fixture principal through run_tool to the ticket store. Step 3: write three new tests: an unknown tool, an extra caller-supplied tenant argument, and a denied update that preserves both ticket version and outbox length. Step 4: commit your evidence and tests, excluding caches, credentials, and generated binaries.

Do not modify the supplied tests to make a failure disappear. If you intentionally remove a control on an isolated branch, demonstrate a failing test and then restore the control. A positive control should show the vulnerable behavior is actually reachable; a negative test should show the hardened boundary rejects it. Both are necessary to avoid a test that passes because its setup never exercised the path.

## Expected observations and deliverables

You should see successful test execution, a synthetic leak only in vulnerable mode, and explicit boundary enforcement in hardened mode. Your evaluator output is labelled deterministic. It is not an LLM attack-success benchmark. If commands fail, record the full error, verify the working directory and Python version, and fix the environment before continuing.

Deliver: a workspace log; a trust-boundary sketch; three new state-based tests; and a short paragraph identifying what the supplied lab does not implement. Include actual HTTP authentication, real model inference, vector retrieval, persistent approvals, and distributed concurrency among the limitations.

## Mastery gate

Explain without notes why a tool request with valid JSON can still be forbidden. Demonstrate one allowed operation and one denied operation, checking actual state in each case. If you cannot do this, repeat the lab rather than progressing to prompt injection.

## Quiz

1. Why is a user_id field in an HTTP body not a reliable authenticated identity?
2. A response says access denied, but a row was changed. Did your security test pass? Why?
3. Which boundary is crossed when retrieved private content enters an LLM context?
4. What does the deterministic evaluator establish, and what does it not establish?

Answers are in [the instructor key](../instructor/answers-01-04.md). Attempt them before opening the key.

## Primary readings

- [Python unittest documentation](https://docs.python.org/3/library/unittest.html): test discovery, assertions, and fixtures.
- [OWASP Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html): trusted identity and session handling.
- [OWASP Authorization Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html): permission checks and deny-by-default design.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V37 Python Tutorial: Unit Testing Your Code with the unittest Module](../MEDIA-LIBRARY.md#v37) (core, v1.3).
- Read: [B10 Demystifying evals for AI agents](../MEDIA-LIBRARY.md#b10).
- Discuss/critique: [R02 Getting into AI/LLM security and red teaming](../MEDIA-LIBRARY.md#r02).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
