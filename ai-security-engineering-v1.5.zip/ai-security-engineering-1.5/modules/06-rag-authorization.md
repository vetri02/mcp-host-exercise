# Module 06: Authorization Throughout RAG

## Prerequisites and measurable objectives

Complete [Module 05](05-prompt-injection.md), or explain why a model proposal is not an authorization decision. You need basic Python collections, HTTP identity concepts, and resource-level access checks.

By the end of this ten-hour module, you will:

1. Specify retrieval permissions as an invariant over trusted principals and document resources.
2. Implement a synthetic retrieval boundary and test cross-tenant, unapproved, and direct-object requests.
3. Identify authorization requirements for citations, caches, indexing, and downstream tools, not only the first search.

Spend two hours on concepts and primary readings, five on the lab, two on evaluation and quiz work, and one on the final writeup.

## Retrieval does not create permission

Retrieval-augmented generation places selected external material in a model's context. A typical pipeline parses a query, retrieves candidates, ranks them, builds context, asks a model for an answer, and formats citations. Authorization must govern the movement of data through this pipeline. Finding a relevant document is not evidence that the requester may read it.

Express the basic invariant as: every document supplied to an answer-producing component must be readable by the authenticated principal at the moment of use. “Authenticated” matters because a tenant label in the user's message or a model-generated filter is an assertion, not trusted identity. The application supplies identity from a verified session. The reference lab substitutes trusted fixture principals for this step; it does not implement authentication.

Separate ingestion eligibility from access eligibility. An approved document can still belong to another tenant. A document in the right tenant can still be unapproved, revoked, or restricted by role. Real systems may require group membership, project membership, confidentiality labels, and row-level policy in addition to tenant equality. This module's small simulator deliberately models only tenant and publication eligibility.

Enforce eligibility before content enters context. Server-bound filters can narrow candidate generation, while an independent final check protects against stale indexes or incorrectly labeled candidates. A vector database's filtering feature can participate in enforcement, but its presence alone does not establish that every retrieval route uses it correctly. Test the actual application path.

Authorization after global top-k selection also has a completeness problem: unauthorized candidates can consume all the ranking slots, leaving no allowed material. Filtering those candidates before they reach the model can protect confidentiality, but the resulting empty answer is not proof that no authorized information exists. Prefer authorized candidate selection followed by ranking within that set where the architecture supports it.

## Worked example: a shared troubleshooting corpus

Consider a synthetic corpus with one approved Alpha support note, one approved Beta support note, and one unpublished Alpha draft. Alice is an Alpha operator. A query containing “support” matches all three. Global lexical relevance does not distinguish which ones Alice may read.

The policy should return only the approved Alpha note. A query that explicitly names Beta must not change Alice's tenant. Asking for the unpublished draft by its exact identifier must not bypass publication state. These are three distinct negative cases, not variations of a single keyword filter.

The following implementation uses exact token overlap for ranking. It has no embeddings, model, or network. Its small allowlist is an educational policy, not a substitute for your organization's access model.

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class Caller:
    tenant: str

DOCS = [
    {"id": "A1", "tenant": "alpha", "approved": True,
     "body": "support reset account"},
    {"id": "B1", "tenant": "beta", "approved": True,
     "body": "support beta account"},
    {"id": "A2", "tenant": "alpha", "approved": False,
     "body": "support unpublished workaround"},
]

def allowed(caller, doc):
    return doc["tenant"] == caller.tenant and doc["approved"]

def retrieve(caller, query, limit=2):
    if not isinstance(query, str):
        raise ValueError("query must be text")
    if type(limit) is not int or not 1 <= limit <= 5:
        raise ValueError("invalid limit")
    terms = set(query.casefold().split())
    scored = []
    for doc in DOCS:
        if not allowed(caller, doc):
            continue
        score = len(terms & set(doc["body"].casefold().split()))
        if score:
            scored.append((score, doc))
    scored.sort(key=lambda item: (-item[0], item[1]["id"]))
    return [doc for _, doc in scored[:limit]]

alice = Caller("alpha")
assert [d["id"] for d in retrieve(alice, "support")] == ["A1"]
assert retrieve(alice, "beta") == []
assert retrieve(alice, "unpublished") == []
assert [d["id"] for d in retrieve(Caller("beta"), "support")] == ["B1"]
```

## Safe lab: authorize every retrieval route

Use a private local workspace and synthetic fixtures only. Run the snippet as `retrieval_policy.py`. Read the [reference lab contract](../reference-lab/CONTRACT.md); from the `reference-lab` folder, run:

```bash
python3 -m unittest discover -s tests -v
python3 -m aisec_lab.demo --mode hardened
```

The reference lab is a deterministic authorization simulator. Search is lexical over approved tenant documents with digest checks. It does not contain a vector store or an LLM, and ticket reading is a separate resource operation.

### Setup and five-hour procedure

In hour one, run both baselines and record the expected identifiers in your extension. Inspect the reference fixture search results using `s.search(alice, 'support')` after constructing `s` with `make_lab()`. The supplied Alice fixture belongs to Alpha; Bob belongs to Beta. Compare synthetic results without copying raw contents into your report.

In hour two, add an explicit `read_document` function to your extension. Find the resource by identifier, then apply the same `allowed` predicate before returning its body. Do not return body text or reveal foreign ownership in a denial. Test A1 as Alice, B1 as Alice, A2 as Alice, and a missing identifier. Only the first read should succeed. A search check alone would leave this direct-object route uncovered.

In hour three, add a small cache keyed by trusted tenant and query. First intentionally use only the query as a key in an isolated unsafe function. Warm it with Bob's “support” request, then make Alice's same request. Observe the synthetic leak. Repair the key and reapply eligibility to cached results. Real policies often require user, role, group state, policy version, and corpus version too. Tenant-only caching is appropriate only for this deliberately simple policy.

In hour four, revoke A1 by changing its approved flag. Confirm that the cache cannot continue serving it. Store cached identifiers rather than treating old body snapshots as indefinitely authorized. Discuss distributed invalidation and the race between checking permission and using data. This single-process exercise does not solve those production problems.

In hour five, check the supplied ticket route independently:

```python
from aisec_lab.fixtures import make_lab
from aisec_lab.errors import PolicyDenied
s = make_lab()
alice = s.identities["alice"]
try:
    s.run_tool(alice, "read_ticket", {"ticket_id": "B-200"})
except PolicyDenied:
    pass
else:
    raise AssertionError("foreign ticket was returned")
```

### Expected outcomes, negative tests, and deliverables

The authorized baseline should work before and after your changes. Foreign and unpublished records must never reach the returned result or citation body. After revocation, A1 must disappear even with a warm cache. Unknown identifiers should produce a generic denial rather than foreign document metadata.

During evaluation, include empty queries, non-text queries, invalid limits, a query claiming administrative status, and Bob's own authorized search. Verify that your citation lookup uses `read_document` rather than a separate unguarded dictionary lookup. A citation URL that serves the document without authentication would bypass otherwise correct retrieval filtering.

Submit code and assertions, before-and-after cache traces using identifiers only, a data-flow diagram covering search and citation lookup, and a policy matrix described as bullet lists. State that the lab omits group ACLs, distributed caches, real authentication, embeddings, and probabilistic generation.

## Mastery gate

Pass when search, direct lookup, cached results, and citations all enforce the stated policy; authorized controls still succeed; and you explain why tenant filtering is necessary but insufficient for a richer access model. A model refusing to quote a foreign document is not an acceptable substitute for preventing its retrieval.

## Quiz

1. Why must the application bind tenant scope rather than accept a tenant named in the query?
2. How can filtering after global top-k selection preserve confidentiality yet damage completeness?
3. Why is a query-only answer cache unsafe in a multi-tenant application?
4. What additional boundary exists when an answer exposes a clickable citation?

## Primary-source reading

- [OWASP GenAI LLM Top 10, 2026](https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026): relate retrieval design to disclosure and data integrity.
- [OWASP AI Agent Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html): review least privilege and independent enforcement.
- [OWASP MCP Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/MCP_Security_Cheat_Sheet.html): examine authorization when retrieval becomes a tool operation.

Next: [Module 07](07-knowledge-poisoning.md). [Instructor answers](../instructor/answers-05-08.md) are separate.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V46 DEF CON 32 - When Chatbots Go Rogue: Lessons Learned from Building and Defending LLM Applications (Javan Rasokat, Andra Lezza)](../MEDIA-LIBRARY.md#v46) (optional, v1.4).
- Watch: [V39 BSidesSF 2025 - GenAI Application Security: Not Just Prompt Injection (Ahmed Abugharbia)](../MEDIA-LIBRARY.md#v39) (recommended, v1.3).
- Read: [B05 Propagating SharePoint Document Permissions to AI Search and RAG Pipelines](../MEDIA-LIBRARY.md#b05).
- Discuss/critique: [R04 Prompt injection in a self-hosted LLM deployment](../MEDIA-LIBRARY.md#r04).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
