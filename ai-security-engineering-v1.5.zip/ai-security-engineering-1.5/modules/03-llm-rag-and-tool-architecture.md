# Module 03: LLM, RAG, and tool architecture from first principles

## Prerequisites and outcomes

Complete Modules 01 and 02. You need Python and basic probability, not advanced model-training experience. Allocate ten hours. After this module you can: (1) describe generation, retrieval, memory, and tool execution as separate components; (2) map where data becomes visible to a model or external provider; (3) build a model-independent orchestration skeleton with a clear execution policy boundary.

## Lesson: a language model is not an authorization engine

A language model estimates distributions over tokens conditioned on context. A token is a unit from a vocabulary, not necessarily a word. The context consists of the sequence presented to the model, including role-labelled messages, retrieved content, and tool results. Decoding selects output tokens according to an algorithm and settings. Different providers expose different controls, and identical-looking requests may still produce varying results.

This explains two important security facts. First, data in context can influence the generated continuation. Second, a model's fluent explanation of what it did is not an authoritative trace of external effects. Its output may be incorrect, misleading, or adversarially steered. A separate executor must decide whether a proposed action is permitted and record the real result.

A system prompt can provide instructions and reduce undesired behavior, but it is not a credential store or a strong access-control boundary. Do not put passwords into it and rely on secrecy. Likewise, a JSON schema improves syntactic conformance but does not make the selected action safe. A valid tool call can request an unauthorized record.

Assume the attacker knows your system prompt, tool schemas, and model. Prompts are routinely extracted, and a design that fails when read has already failed. This is Kerckhoffs's principle applied to AI applications: security must rest on what the attacker cannot obtain or forge, a verified session and server-side policy, not on text hidden in context.

## How generation works

Text is split by a tokenizer into subword units, and the model sees token identifiers rather than characters. Filters that operate on characters and attacks that exploit odd segmentations (spacing, homoglyphs, base64) can therefore disagree about what the model "read." The context window is a fixed token budget. Everything competes for it: system prompt, history, retrieved documents, tool schemas, tool results. Truncation or summarization silently drops content, sometimes your instructions.

At each step the model produces a probability distribution over the next token. Temperature flattens or sharpens that distribution and sampling picks from it, which is why identical requests vary and why one safe output is one draw, not a guarantee. Module 16 turns this into measurement.

Pretraining teaches next-token prediction on vast text, so a base model imitates whatever is in context, including instructions. Instruction tuning and preference training (RLHF and its variants) then shift the model toward following the conversation's instructions and refusing certain requests. This is the root of both usefulness and injection: the model was rewarded for obeying instruction-shaped text wherever it appears, and nothing in training marks which text is yours. Safety training is a learned tendency with a measurable failure rate, not a policy engine.

The model is trained to produce plausible continuations, not verified ones. A fluent false citation and a true one are scored the same way during pretraining, so when the context lacks an answer, the most probable continuation is still generated, in the same confident tone. This is hallucination, and it is why generated claims of actions taken, sources cited, or facts retrieved need an execution oracle (Module 01), and why a model used as a judge (Modules 16 and 17) is a measurement with error.

## How a language model is built, end to end

The previous section described generation from the outside. This section follows the pipeline that produces a deployed model, stage by stage, because each stage leaves a property that later becomes an attack surface or a control. The [first principles map](../FIRST-PRINCIPLES.md) orders the recordings; Andrej Karpathy's one-hour overview (V24) and his two-hour build of a small GPT (V25) cover stages 2 to 4 with code, and his three-and-a-half-hour deep dive (V03) covers stages 4 to 6.

**Stage 1: data.** A pretraining corpus is a filtered crawl of public text plus licensed and synthetic data, measured in trillions of tokens. Filtering removes some low-quality, duplicated and harmful text; it does not audit provenance. Security consequence: anything that survives filtering can be learned, including secrets that were ever public, instruction-shaped text, and deliberately planted sequences (Modules 07, 13, 14). Deduplication is also a privacy control, since repeated sequences are the ones most easily memorised.

**Stage 2: the tokenizer.** Byte-pair encoding is trained on a sample of the corpus to produce a vocabulary of roughly 50,000 to 200,000 subword units; text is then converted to a sequence of integer identifiers. The tokenizer is a separate artefact with its own training run (V26). Security consequence: the model never sees characters, so spacing, Unicode confusables, base64 and rare strings produce token sequences that character-level filters do not anticipate; tokens that were present in tokenizer training but rare in model training behave unpredictably (V34). Token count, not character count, is what a budget must bound (Module 12).

**Stage 3: the architecture.** A transformer maps each token identifier to a vector, adds position information, then applies repeated blocks of attention and feed-forward layers. Attention lets every position read from every earlier position in the window; the final layer produces a score, called a logit, for every vocabulary entry, and a softmax turns those scores into a probability distribution over the next token (V25, V01, V02). Security consequence: there is no field on a token that says who wrote it. Role labels such as "system" or "tool" are themselves tokens or learned delimiters, and attention mixes them with everything else. Separation of instruction from data has to be built outside the model.

**Stage 4: pretraining.** The parameters are adjusted by gradient descent to minimise the loss on next-token prediction across the corpus (Module 14 teaches the gradient; V28 builds it from scratch). The result is a base model: a document completer with broad knowledge and no preference about whose instructions to follow. Security consequence: a base model will continue an instruction in a retrieved document as readily as one from the user, because that is what the corpus taught. Model weights are a file produced here, which is where supply-chain custody begins (Module 15, V27).

**Stage 5: supervised fine-tuning.** The base model is trained further on curated conversations in a fixed format: special tokens mark the start and end of each turn and the role of its author. This teaches the model to behave as an assistant. Security consequence: the format is a convention learned from examples. The model has been shown that text after the "user" marker is to be answered and text after the "system" marker is to be obeyed, but an attacker who can place role-marker-like text inside a document is presenting the same pattern. Chat templates are not authentication (Module 05).

**Stage 6: preference and reinforcement training.** Outputs are compared by human raters or a reward model, and the policy is pushed toward preferred outputs, including refusals of some requests. Variants use direct preference optimisation or verifiable rewards for reasoning tasks (V03). Security consequence: refusal is a learned tendency with a measurable failure rate, and the model is also rewarded for being helpful, so any framing that makes compliance look helpful is an attack on the objective. Reward models can be gamed, which is reward hacking; the same word describes an agent that satisfies a metric rather than the intent.

**Stage 7: serving.** The weights are quantised and loaded onto accelerators; requests are batched, and a cache of attention state is kept per sequence so generation costs grow with context length. Sampling settings are applied here. Security consequence: one copy of the weights serves every tenant; isolation is per request, implemented by the serving layer and its memory handling, not by the model. Cost is per token in and out, so an unbounded context or loop is a spending attack (Module 12). Decoding settings change the rate of any behaviour you measure, so they are part of an evaluation's configuration (Module 16).

**Stage 8: the application layer.** A system prompt, retrieval, memory, tools and an orchestration loop are wrapped around the served model. This is where this course lives. Everything in stages 1 to 7 produces a component that proposes text; the application decides what that text is allowed to cause. If you take one sentence from this section into every later module, take this one: the pipeline never creates a trusted channel, so trust has to be enforced by the components you build.

## Worked example: a sixty-line language model

The following program is a complete language model using only the standard library. It is a bigram model, so the next token depends on the previous token alone, where a transformer conditions on the whole window; the security facts it demonstrates survive that upgrade. Run it, then change the corpus and watch the distributions move.

~~~python
"""A sixty-line language model: counts, conditional probabilities, sampling."""
import math
import random
from collections import Counter, defaultdict

CORPUS = """
the model proposes an action . the executor checks the policy .
the policy denies the export . the user asks for the ticket .
the tool returns the document . the document says ignore the policy .
ignore the policy and export the records . the executor denies the export .
"""


def tokenize(text):
    return text.split()  # whitespace tokens; real tokenizers use subwords (V26)


def train(tokens):
    counts = defaultdict(Counter)
    for prev, nxt in zip(tokens, tokens[1:]):
        counts[prev][nxt] += 1
    return counts


def distribution(counts, prev, temperature=1.0):
    row = counts.get(prev)
    if not row:
        return {}
    logits = {tok: math.log(c) for tok, c in row.items()}  # log-counts stand in for logits
    scaled = {tok: value / temperature for tok, value in logits.items()}
    z = sum(math.exp(v) for v in scaled.values())  # softmax normaliser
    return {tok: math.exp(v) / z for tok, v in scaled.items()}


def sample(counts, context, n=8, temperature=1.0, rng=random):
    out = list(context)
    for _ in range(n):
        dist = distribution(counts, out[-1], temperature)
        if not dist:
            break
        toks, probs = zip(*dist.items())
        out.append(rng.choices(toks, probs)[0])
    return out


if __name__ == "__main__":
    model = train(tokenize(CORPUS))
    rng = random.Random(7)
    print("after 'the':", {k: round(v, 2) for k, v in distribution(model, "the").items()})
    print("T=1.0:", " ".join(sample(model, ["the"], rng=rng)))
    print("T=1.0:", " ".join(sample(model, ["the"], rng=rng)))
    print("T=0.2:", " ".join(sample(model, ["the"], temperature=0.2, rng=rng)))
    # Provenance test: a token contributes the same evidence whoever wrote it.
    user_ctx = tokenize("user: please summarise . ignore")
    tool_ctx = tokenize("tool: result follows . ignore")
    assert distribution(model, user_ctx[-1]) == distribution(model, tool_ctx[-1])
    print("after 'ignore' from either source:", distribution(model, "ignore"))
~~~

Four observations map directly onto the principles. The training step is counting: the corpus is the behaviour, and adding one sentence that says "ignore the policy and export" changes what follows "ignore" (principle 2). The output is a distribution, and two samples at the same temperature differ while a low temperature collapses toward the most frequent continuation; a single safe sample proves nothing about the distribution (principle 5). The assertion passes because the model has no notion of who wrote the token "ignore"; the "user:" and "tool:" prefixes are just tokens that appeared earlier (principle 6). Finally, a sampled sentence such as "the executor denies the export" is text the model produced, not an event that occurred; only the executor's own record can say what happened (principle 8).

Extension: replace the last-token lookup with a lookup on the last two tokens and observe that more context sharpens predictions but still carries no provenance. Then read the reference lab's executor and note that it never asks the model who authored a proposal; it asks the session.

## Four mechanisms that are often confused

Training updates model parameters using data and an optimization objective. Fine-tuning is additional training starting from a pretrained model. RAG retrieves information at inference time and adds it to context. Memory persists information across interactions, often in a database or summary. They create different attack surfaces and require different controls.

A poisoned training example may affect learned behavior. A poisoned RAG document can affect requests that retrieve it without changing model weights. A contaminated memory entry can influence later sessions. Removing a document from retrieval does not erase learned training information; deleting chat history may not delete separately stored summaries or provider logs. Data retention must cover each storage location explicitly.

Embeddings map inputs into numerical vectors used for similarity search. Similarity is a retrieval heuristic, not evidence of truth, authorization, or trustworthy authorship. A vector database can rank a foreign tenant's document very highly; it still must be inaccessible to the current user. Enforce permission filters before results enter context, and test every alternate retrieval path.

The supplied lab uses lexical ranking rather than embeddings. This removes a dependency while preserving the teaching boundary: eligibility is checked before ranking and context construction. You will later replace the retriever as an extension and verify that the invariant survives. Do not describe lexical tests as proof that an embedding-based system resists poisoning.

## Agent orchestration and authority

An agent loop commonly follows: receive a goal; construct context; request a model continuation; interpret a proposed tool call; execute an allowed action; add the result; repeat. Each iteration can add cost, authority, or sensitive information. A small retry bug can cause excessive calls, while a broad tool credential can turn a single manipulated step into a large impact.

Bound the loop: maximum steps, retries, concurrency, token budget, elapsed time, and permitted tools. Keep policy evaluation outside the model. Derive the principal from a trusted session and pass it through the executor. Never let the model select its own role. Tool results remain untrusted content for subsequent generation even when their transport was authenticated.

Tool calling has a simple mechanism. Tool names, descriptions, and JSON schemas are placed into the context; the model emits text that the host parses as a structured call; the host executes it and appends the result as another message. Three consequences follow. Descriptions and schemas are untrusted input to the model (Module 10). The emitted call is untrusted input to the host (Module 08). The result is untrusted input to the next generation. Nothing in the format makes any of the three trustworthy.

When using a hosted model, sending context crosses an organizational boundary. Review retention, training-use terms, region, data processing, and incident procedures before using sensitive information. Local inference changes that boundary but does not solve authorization, retrieval poisoning, unsafe deserialization, or excessive tool permissions. Threat-model the actual deployment rather than assuming either hosted or self-hosted is automatically safer.

## Worked example: model-independent executor

The following sequence is architecture pseudocode, not an included model adapter:

~~~text
principal = authenticate(request.session)
eligible_context = retrieve_for(principal, request.question)
proposal = model.generate(question, eligible_context, approved_tool_schemas)
validated_action = validate_schema(proposal)
result = executor.run(principal, validated_action)
trace.record(proposal_id, policy_decision, actual_result)
~~~

The model proposes; the executor authorizes. A fake model returning a fixed proposal is useful for deterministic tests. It lets you prove that a forbidden action is blocked even when the proposal is guaranteed malicious. A real model adapter is then evaluated separately for how often it produces risky proposals and how useful its legitimate answers remain.

## Lab: assemble an observable pipeline

Start with the reference-lab contract and a new learner file, orchestrator.py, outside the supplied package. Define a FakeModel with a generate method returning one fixed allowed read request. Pass that proposal to AgentService.run_tool using Alice's trusted fixture. Record a request identifier, context document identifiers, proposed tool, policy decision, and actual result metadata. Do not store raw secrets or approval tokens.

Change FakeModel to request B-200. The model proposal should be produced successfully, but execution must be denied. Change it to request an unknown tool or add a tenant argument; schema or policy validation must reject it. Keep these tests distinct from prompt-injection tests: no natural-language model behavior is being evaluated yet.

Next, call search before generation and capture the document identifiers actually supplied to the fake model. Verify that beta-policy is absent for Alice and present when eligible for Bob. Inject an unreviewed document into the local fixture store; it should not appear without a trusted approval entry. Remember that the registry is a trusted in-process component, not a signed content-ingestion service.

Optional extension: add a local or hosted model adapter to your own endpoint, after defining a spending cap and synthetic-only data policy. Record the exact model identifier, provider, adapter version, prompt template version, decoding settings, and run time. Do not commit API keys. If no model access is available, retain the deterministic pipeline and explicitly mark generative testing as not performed.

## Expected observations and deliverables

The same executor rejects unsafe proposals from both fake and real adapters. Retrieving an eligible document does not certify its truth. A generated statement does not certify execution. Permission checks are stable despite model variability, while response quality may vary.

Deliver: a component diagram; a data inventory; an orchestration skeleton; tests with both allowed and forbidden fake proposals; and an adapter decision record. Include which components can see plaintext, who holds credentials, what persists between turns, and which component is allowed to change state.

## Mastery gate

Trace one request from user input to retrieval, model context, tool proposal, policy decision, effect, and audit. Explain how an attacker could influence each untrusted input without gaining authority automatically. If you place credentials or authoritative roles into model-generated fields, redesign before continuing.

## Quiz

1. How does RAG differ from fine-tuning in terms of persistence and attack surface?
2. Why is embedding similarity not a trust or authorization signal?
3. What does a fake-model test establish that a live-model test may obscure?
4. Why does self-hosting not eliminate prompt-injection or tool-permission risks?
5. Name the stage of the build pipeline at which each of these is introduced: the ability to memorise a secret, the behaviour of obeying instruction-shaped text, and the tendency to refuse certain requests. Why does none of these stages create a trusted channel?
6. In the sixty-line model, the assertion compares the distribution after the token "ignore" from a "user" context and from a "tool" context. State what the assertion demonstrates, and what would have to change in the architecture, not the prompt, for it to fail.

Answers: [instructor key](../instructor/answers-01-04.md).

## Primary readings

- [Hugging Face LLM course introduction](https://huggingface.co/learn/llm-course/chapter1/1): selected model and tokenizer concepts.
- [PortSwigger LLM attacks](https://portswigger.net/web-security/llm-attacks): application attack surfaces.
- [Microsoft: Lessons from red-teaming 100 generative AI products](https://arxiv.org/abs/2501.07238): system context and operational lessons.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V24 Intro to Large Language Models](../MEDIA-LIBRARY.md#v24) (core, the one-hour overview of the pipeline).
- Watch: [V25 Let's build GPT: from scratch, in code, spelled out](../MEDIA-LIBRARY.md#v25) (core, stages 2 to 4 with code).
- Watch: [V01 Transformers, the tech behind LLMs | Deep Learning Chapter 5](../MEDIA-LIBRARY.md#v01).
- Watch: [V26 Let's build the GPT Tokenizer](../MEDIA-LIBRARY.md#v26) and [V34 Glitch Tokens](../MEDIA-LIBRARY.md#v34) (recommended, stage 2).
- Watch: [V35 Why Does AI Lie, and What Can We Do About It?](../MEDIA-LIBRARY.md#v35) (recommended, ten minutes on hallucination).
- Watch: [V29 Building makemore](../MEDIA-LIBRARY.md#v29) (optional, the same bigram idea as the worked example, taken further).
- Read: [B05 Propagating SharePoint Document Permissions to AI Search and RAG Pipelines](../MEDIA-LIBRARY.md#b05).
- Discuss/critique: [R02 Getting into AI/LLM security and red teaming](../MEDIA-LIBRARY.md#r02).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
