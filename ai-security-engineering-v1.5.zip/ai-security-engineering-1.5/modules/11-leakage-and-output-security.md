# Module 11: Data Leakage and Contextual Output Security

## Prerequisites and learning objectives

You need Python serialization, parameterized-query concepts, and the authorization boundaries from [Module 10](10-mcp-security.md). Read the [reference-lab contract](../reference-lab/CONTRACT.md). Its outbox holds local draft dictionaries; it never sends email. There is no browser renderer, SQL executor, or language model in the supplied simulator.

By the end, you will be able to:

1. Trace synthetic sensitive data from retrieval to response, tool arguments, logs, and draft destinations.
2. Select controls appropriate to text, URL, SQL, structured-tool, and rich-content output contexts.
3. Build negative tests demonstrating authorization, destination, and contextual-handling boundaries without making unsupported leakage claims.

Spend **10 hours**: concepts 2, practice 5, evaluation 2, and writeup 1. Treat output security as a data-flow problem, not a search for one perfect sanitizer.

## Leakage begins before generation

A system can disclose information even when the model follows its instructions. Too much context may be retrieved, an authorized response may be delivered to the wrong audience, or debug logs may retain private values. The first defense is therefore data minimization and authorization before context construction.

Trace a synthetic support note through each sink: retrieval result, prompt context, generated answer, tool arguments, memory, audit events, and cached response. Ask who can read each representation and how long it survives. Information authorized for one operator's view is not automatically authorized for an external draft, analytics service, or another tenant's cache.

Separate input confidentiality from output behavior. Keeping a secret out of context reduces opportunities for disclosure; asking a model not to reveal a secret it already sees is a weaker boundary. Secrets should remain in a trusted credential component and be substituted only at a narrowly authorized integration boundary, not handed to a model as ordinary text.

Tenant-filtered retrieval is necessary but does not settle every sharing decision. A recipient may belong outside the tenant, a document may require a narrower audience, or a response may reveal more than a task needs. Define both source-access and destination-access rules. The simulator enforces its fixture tenant boundaries and recipient allowlist; richer classifications and policy labels are extensions.

## Generated output is untrusted input at the next boundary

Output can be wrong, maliciously influenced, or valid-looking but unsafe. Treat it as a proposal that must pass the consumer's schema, authorization, and contextual handling. JSON syntax does not confer authority. A well-formed object can still request a foreign ticket or unsupported operation.

For plain-text display, use a text API that does not interpret content as markup. For a web view, prefer framework auto-escaping in the correct context. If rich content is genuinely required, use a maintained sanitizer and a constrained rendering pipeline. Markdown renderers can admit embedded markup, links, or remote images; disabling raw markup alone does not decide which destinations may be loaded.

Encoding is context-dependent. HTML text encoding is not sufficient for JavaScript, CSS, or URL contexts. Validate URL scheme and approved destination separately, then encode for the containing attribute where necessary. Prefer avoiding dynamic values in executable contexts altogether. A content-security policy is defense in depth, not a replacement for safe sinks.

For SQL, keep query structure fixed and pass values through driver parameters. Escaping for a browser does not secure a query. A validated structured tool call still needs actor, tenant, resource, and approval checks. Never pass generated text to a shell or treat a generated code block as an instruction to execute. This course contains no arbitrary shell-execution tool.

## Exfiltration can use legitimate-looking channels

Exfiltration is unauthorized movement of data, not necessarily an obvious “send secret” action. A search query, link path, image request, email subject, error trace, or monitoring event can carry a private value. Restricting only the final answer misses these channels.

A useful compression of this chapter, due to Simon Willison (2025), is the lethal trifecta: exfiltration needs private data in context, untrusted content that can steer the model, and a channel out. Remove any one leg and the class of attack is gone. Retrieval eligibility (Module 06) limits the first, injection controls (Module 05) reduce but cannot eliminate the second, and sink and egress policy (this module and Module 12) remove the third. When reviewing a design, ask which leg each control removes; a design with all three legs present is exploitable regardless of prompt wording. Browser agents, in Module 23, have all three by default.

Exfiltration does not require clicking. A 2025 zero-click chain against an enterprise assistant arrived as one email: its instructions were paraphrased past an injection classifier, a reference-style Markdown link evaded the link filter, and an allowed proxy domain satisfied the content-security policy, so the assistant's own rendering fetched a URL carrying private data. Each filter was reasonable; the chain found the gap between them.

Constrain tool destinations and arguments before execution. A destination allowlist should identify approved services and permitted operations, not merely accept anything with a familiar hostname substring. Prevent unapproved redirects and remote resource loading. A draft recipient is security-relevant even when the draft is not sent, because the intended audience has changed.

Data-loss-prevention scanning can identify some patterns, such as a known synthetic canary. It cannot prove absence of leakage: values may be transformed, split, summarized, or unknown to the detector. Place DLP after robust access controls as an additional signal, not as permission to bypass them. Tests should include harmless near-matches to measure whether the defense blocks legitimate work.

Audit structured decisions without raw prompts, document bodies, credentials, or approval tokens. Log actor, tenant, tool, decision, and correlation metadata as supported by the implementation. Retain enough information to investigate denials while limiting access and retention. Error handling should not copy sensitive values into exceptions shown to unauthorized callers.

## Hidden context and the approver as a target

The 2026 OWASP LLM list renamed "system prompt leakage" to hidden context exposure. The change matters. A system prompt, tool schema, approval rule, or internal identifier disclosed to a user is rarely a secret worth protecting in itself (Module 03 told you to assume the attacker has it) but it is reconnaissance: it tells the attacker which tool to name, which argument to forge, and which phrasing the approval step expects. Treat tool manifests and policy text as internal, keep them out of error messages and model-visible context where the model does not need them, and do not rely on their secrecy.

The approver is also a sink. An agent that asks a human to confirm an action presents that action in words the model chose; a steered model can describe a harmful action innocuously, or request a broad "don't ask again" that covers later actions. The 2026 agentic list calls this human-agent trust exploitation. The control is the one from Module 09: the approval binds to the exact action the executor will run, rendered from the validated arguments rather than from the model's description, and never to a category.

## Worked example: context determines the safe transformation

The following uses only standard-library functions and synthetic text:

```python
import html
import json
import sqlite3

proposal = 'Synthetic note: <tag> & "quoted"'
text_fragment = html.escape(proposal, quote=True)
wire_value = json.dumps({'note': proposal})

db = sqlite3.connect(':memory:')
db.execute('CREATE TABLE notes (body TEXT)')
db.execute('INSERT INTO notes(body) VALUES (?)', (proposal,))
assert db.execute('SELECT body FROM notes').fetchone()[0] == proposal
```

`text_fragment` is appropriate for an HTML text fragment, not a general URL or script sanitizer. `wire_value` serializes JSON but does not authorize its meaning or make it safe for direct embedding in a script. The parameterized query stores the exact data instead of interpreting it as SQL syntax. No rendered page or output artifact is required: inspect strings and database rows locally.

## Safe lab: constrain outputs and destinations

**Setup.** Run the reference test suite from `reference-lab`. Use fresh fixtures and invented canaries such as `SYNTHETIC-ALPHA-CANARY`; never insert real credentials or personal information. Build a learner-owned output-policy wrapper separately. It receives prerecorded proposed outputs rather than calling a model.

**Practice steps, five hours.**

1. Document the sinks exposed by the simulator: approved document search, ticket reads, per-user memory, tool arguments, local outbox, and structured audit events. Record which controls already exist and which your wrapper will add. Confirm that lexical retrieval and digest checks do not establish factual correctness.
2. Retrieve and read as Alice, then attempt Bob's ticket and compare tenant-filtered search results. Assert no foreign data appears in a successful Alpha response. Do not interpret an empty search result as evidence that every possible disclosure is prevented.
3. Create an approved `draft_email` request for A-100 addressed to `support@alpha.example.test`. Verify a local outbox entry and no network effect. Change the recipient to `support@beta.example.test` or an unapproved synthetic address; expect rejection and an unchanged outbox. Also mutate the recipient after approval: the old token must not authorize the new draft.
4. Implement a wrapper that accepts only the intended structured output fields and bounded strings. Reject unknown fields, wrong types, and attempts to supply actor or tenant. Run local tests for text escaping and SQLite parameterization using the worked example. Keep URL-policy tests purely in memory: classify approved fixture URLs, forbidden schemes, and remote-resource references without fetching them.
5. Add a simple known-canary check across proposed replies, tool arguments, and captured logs. Test direct disclosure, a split canary, and a harmless near-match. Observe detector misses and false positives honestly. Improve coverage, but keep authorization and destination controls mandatory regardless of the scan result.

**Expected observations and negative tests.** Valid tenant reads and approved local drafts succeed. Foreign resources, unapproved recipients, altered approved arguments, and malformed proposals fail without side effects. The SQL row retains adversarial-looking text as data. Escaping prevents text-fragment interpretation only in its designated context. A string-based canary scan may miss split or transformed values; that is a documented limitation, not a surprising authorization bypass.

**Deliverables.** Submit tests, a prose source-to-sink inventory, a sink-specific control rationale, redacted outbox assertions, and a detector limitation report. Check audit events for fixture canaries and approval-token values without printing tokens. Distinguish controls tested in the simulator, controls tested in your wrapper, and web-rendering behavior that remains unimplemented.

## Evaluation and mastery gate

Use two hours for peer review and failure analysis, then one hour for the writeup. Pass when every sink has an explicit audience and interpretation rule, rejected drafts leave the outbox unchanged, and positive controls still work. You must explain why “no canary found” is not “no leakage,” and why one universal escaping function cannot secure all consumers. Unsupported production guarantees fail the gate.

## Quiz

1. Why should retrieval authorization happen before prompt construction?
2. Why is HTML escaping not a SQL or URL security control?
3. How can a permitted tool become an exfiltration channel?
4. What does a successful canary test establish, and what does it leave unknown?

See the [instructor key](../instructor/answers-09-12.md). Continue to [isolation and resource limits](12-isolation-and-resource-limits.md).

## Primary-source readings

- [OWASP Top 10 for LLM Applications 2026](https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026), for sensitive-information disclosure and insecure-output risks; use the published taxonomy rather than inventing rankings.
- [OWASP AI Agent Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html), especially sensitive-data handling, tool boundaries, and logging.
- [OWASP Cross Site Scripting Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html), for context-specific encoding, safe sinks, and sanitization.
- [PortSwigger Web LLM Attacks](https://portswigger.net/web-security/llm-attacks), for how untrusted model-connected data can influence downstream consumers. Read the explanations; do not attack external targets.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V07 DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](../MEDIA-LIBRARY.md#v07).
- Read: [B04 Designing AI agents to resist prompt injection](../MEDIA-LIBRARY.md#b04).
- Discuss/critique: [R08 Handling prompt injection when agents have production access](../MEDIA-LIBRARY.md#r08).
- Optional short commentary: [X03 Hidden PDF content and a reported Notion exfiltration path](../MEDIA-LIBRARY.md#x03).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
