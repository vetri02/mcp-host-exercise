# Module 14: Adversarial Machine Learning

## Prerequisites, objectives, and time

You need Python lists, distance calculations, and the training/inference distinction from [Module 13](13-model-privacy-and-extraction.md). Review how a classifier turns features into a decision. This chapter introduces broader ML security without requiring neural-network expertise.

By the end, you can:

1. Classify an attack by lifecycle stage, attacker control, and objective.
2. Demonstrate constrained evasion, training poisoning, and a trigger-dependent backdoor on an isolated synthetic classifier.
3. Evaluate clean utility and targeted failures separately, including negative controls and limitations.

Allocate 2 hours to concepts, 5 to practice, 2 to evaluation, and 1 to the writeup. These exercises develop investigative competence, not mastery of every adversarial ML method.

## What changes, and when?

Learning chooses parameters from training data. Inference applies those parameters to a new input. An attacker can intervene at either stage, and the distinction determines where a control belongs.

**Evasion** changes inference-time inputs to cause an undesired prediction, without necessarily changing the trained parameters. A malicious input must still satisfy the attack's validity constraints. An arbitrary corrupted image is not automatically a meaningful adversarial example. In a security classifier, ask which fields an attacker can actually alter and whether the resulting input retains the property being classified.

**Training-data poisoning** alters data or labels used during learning. It can seek broad accuracy degradation or a targeted misclassification. Clean-label poisoning preserves supplied labels while manipulating other aspects of training examples; label-flipping is only one possible mechanism. If an attacker modifies preprocessing code rather than examples, describe that additional supply-chain capability instead of hiding it inside “data poisoning.”

**Backdoors** create behavior activated by a particular trigger while often preserving useful behavior elsewhere. Training poisoning is one route to a backdoor; direct modification of weights or a compromised pretrained artifact is another. A backdoor is defined by conditional behavior, not by the existence of one misclassification. Trigger tests need clean, triggered, and irrelevant-trigger controls.

**RAG poisoning** changes a retrieved corpus or index and thereby influences runtime context. It does not require changing model weights. The model can remain frozen while its answers change because its evidence changed. If retrieved material is later reused for fine-tuning, a second training-poisoning path appears. Track the transition explicitly. Prompt injection concerns interpretation of instructions across a trust boundary and can coexist with false factual evidence; these are not interchangeable descriptions.

## First principles: geometry and optimization

A classifier partitions feature space. Inputs near a decision boundary may cross it after a small feature change. “Small” requires a metric: a bounded Euclidean distance, a maximum per-feature change, or a domain-specific edit budget. Features with different units require scaling; otherwise the largest numerical unit can dominate distance.

For a differentiable loss `L(theta, x, y)`, the input gradient describes local directions that increase error. The fast gradient sign idea perturbs an input in the sign of that gradient under a maximum-coordinate budget. This is useful intuition, not a universal recipe: discrete text, categorical fields, preprocessing, and physical constraints complicate it. Gradient-free queries are another capability, not evidence that gradients are always necessary.

Poisoning instead changes the training objective through altered examples. A learner may discover a shortcut that correlates with the supplied labels. A trigger can become that shortcut. Defenses must therefore examine the data-generation process and training pipeline, not merely sanitize runtime inputs. Ordinary random validation may miss a rare trigger because it never contains the relevant condition.

## Worked example: a nearest-centroid learner

We use two numeric features: a mutable sensor proxy and a marker. Labels describe a synthetic latent class. The marker is zero in clean training data. Each class is represented by the mean of its feature vectors; prediction chooses the nearer mean.

```python
from math import dist

clean = [((0.1, 0), 0), ((0.2, 0), 0),
         ((0.8, 0), 1), ((0.9, 0), 1)]

def train(rows):
    centers = {}
    for label in (0, 1):
        points = [x for x, y in rows if y == label]
        if not points:
            raise ValueError("both classes need examples")
        centers[label] = tuple(
            sum(p[j] for p in points) / len(points)
            for j in range(2))
    return centers

def predict(centers, point):
    return min(centers, key=lambda y: (dist(point, centers[y]), y))

base = train(clean)
assert predict(base, (0.45, 0)) == 0
assert predict(base, (0.55, 0)) == 1
```

The tie-breaking rule is explicit and deterministic. We stipulate that changing this noisy proxy by at most 0.10 preserves the example's latent class. That assumption makes the second prediction an evasion candidate for the first example. It would be invalid if the feature itself defined the true label. This tiny geometric classifier is not a faithful replica of neural adversarial examples or all poisoning attacks.

## Safe lab: four boundaries, four explanations

### Setup

Create a local standard-library script containing the learner. Keep `clean` immutable and create new lists for each intervention. Use no remote models, customer data, or downloaded artifacts. Reserve clean evaluation points `(0.15, 0)` with label 0 and `(0.85, 0)` with label 1. Store labels separately from prediction inputs. Make a log that records intervention, training rows, centers, input, and prediction.

### Steps

1. **Evasion:** train once on clean data. Compare the latent-class-0 point `(0.45, 0)` with `(0.55, 0)`. Check the change against the 0.10 proxy budget with a floating-point tolerance. Evaluate `(0.15, 0)` under the same positive change. Verify training centers did not change.
2. **Ordinary poisoning:** retrain after adding three copies of `((0.15, 0), 1)`. These are deliberately mislabeled synthetic rows. Calculate the new class-1 center by hand, then test `(0.35, 0)`, stipulated class 0. Compare with the clean model. Count altered rows and state their fraction of this tiny training set.
3. **Backdoor poisoning:** start again from clean data, not the previous poisoned set. Append `((0.1, 1), 1)` and `((0.2, 1), 1)`. Test both reserved clean points, then apply marker 1 to the class-0 point. Compare those predictions with the clean-trained model on the identical marked input. Do not assume a marker is a trigger until the comparison supports it.
4. **RAG contrast:** create an in-memory corpus with an approved fictional fact, “The synthetic depot code is BLUE.” Add a separate unapproved record claiming RED. Write a deterministic retrieval function that returns the newest eligible record. First allow all records; then require an approved flag from a separate local policy fixture. Observe the selected text without retraining any classifier. An approval flag here is a fixture, not real authentication or proof of truth.

### Expected observations and negative tests

Evasion can cross the clean boundary near 0.50 but does not necessarily affect a point far from it. Ordinary poisoning shifts the learned center. The backdoor fixture can preserve the two clean predictions while changing a marked class-0 prediction. Corpus poisoning changes selected evidence while leaving all classifier centers unchanged. These are expectations derived from the fixtures, not benchmark claims.

Reject an over-budget evasion input instead of counting it as a successful valid attack. Test an irrelevant marker, such as 0.1, and an unmarked input under both models. Verify the clean model does not acquire a backdoor merely because an input has a marker. Test removal of poisoned rows followed by retraining, not just removal from the stored dataset. For retrieval, an unapproved record must be excluded and an approved benign record must remain usable. Record failures even when they undermine your intended narrative.

### Deliverables

Submit the executable script, hand-calculated centers, a lifecycle diagram written as bullets, and results separated into clean accuracy, valid evasion outcomes, and targeted marked-input outcomes. Include counts and denominators. Explain why two clean test cases cannot certify backdoor absence and why approval of evidence is different from its factual correctness.

## Defense follows the intervention

For evasion, establish realistic input constraints, evaluate robustness under those constraints, and consider abstention or human review where errors are consequential. Adversarial training can improve robustness under particular threat models; it does not establish universal robustness. For training poisoning, control data writers, preserve lineage, review labeling changes, and evaluate suspicious slices. Aggregate accuracy can conceal targeted failures.

For backdoors, scrutinize pretrained artifacts and training provenance, test plausible trigger families, and retain recovery options. No finite trigger list covers all triggers. For RAG poisoning, govern ingestion, enforce authorization, preserve source identity, and compare conflicting evidence. Digest checks detect changed bytes relative to a trusted reference; they do not establish that a statement is true. [Module 15](15-secure-mlops-and-supply-chain.md) extends these controls into release engineering.

Fine-tuning deserves its own line because it is the intervention most teams actually perform. It changes weights, so it can introduce a backdoor, and it can erode safety training even with benign data, since the tuning objective says nothing about preserving refusals. A downloaded adapter (a LoRA, for example) is executable behavior layered onto a trusted base and needs the same provenance review as the base. A fine-tuned model also memorizes its tuning set, reopening Module 13's extraction risks for that data.

## Quiz

1. Which lifecycle stage separates inference evasion from training poisoning?
2. Why can a backdoor pass ordinary clean validation?
3. Is a malicious retrieved document necessarily training-data poisoning? Explain the boundary.
4. Why must a perturbation budget be accompanied by a semantic-validity assumption?

## Mastery gate

Pass when all four demonstrations have distinct causal explanations, negative controls run, and you can identify what remained fixed in each experiment. A claimed neural-attack replication or comprehensive robustness guarantee does not pass. Answers are in the [instructor file](../instructor/answers-13-16.md).

## Primary readings

- [MITRE ATLAS: Extract AI Model, via MITRE D3FEND](https://d3fend.mitre.org/offensive-technique/attack/AML.T0024.002/): contrast extraction with this chapter's integrity objectives.
- [Goodfellow et al.: Explaining and Harnessing Adversarial Examples](https://arxiv.org/abs/1412.6572): study the assumptions behind gradient-based evasion.
- [Gu et al.: BadNets](https://arxiv.org/abs/1708.06733): distinguish clean performance from trigger behavior.
- [Zou et al.: PoisonedRAG](https://arxiv.org/abs/2402.07867): identify the knowledge-database intervention rather than assuming weight changes.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V28 The spelled-out intro to neural networks and backpropagation: building micrograd](../MEDIA-LIBRARY.md#v28) (core, v1.3).
- Watch: [V30 But what is a neural network? | Deep learning chapter 1](../MEDIA-LIBRARY.md#v30) (core, v1.3).
- Watch: [V31 Gradient descent, how neural networks learn | Deep Learning Chapter 2](../MEDIA-LIBRARY.md#v31) (core, v1.3).
- Watch: [V32 Backpropagation, intuitively | Deep Learning Chapter 3](../MEDIA-LIBRARY.md#v32) (optional, v1.3).
- Watch: [V08 Overview of Adversarial Machine Learning](../MEDIA-LIBRARY.md#v08).
- Read: [B06 A small number of samples can poison LLMs](../MEDIA-LIBRARY.md#b06).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
