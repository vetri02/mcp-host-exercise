# Module 12: Isolation, SSRF Defenses, and Resource Budgets

## Prerequisites and learning objectives

You need URL parsing, unit tests, and the source-to-sink reasoning in [Module 11](11-leakage-and-output-security.md). Read the [reference-lab contract](../reference-lab/CONTRACT.md). The supplied simulator performs no network requests and provides no operating-system sandbox. SSRF and resource-control exercises below are separately built extensions using local fixtures.

By the end, you will be able to:

1. Specify distinct process, filesystem, credential, and egress boundaries for an agent workload.
2. Test URL-policy decisions, redirects, and simulated DNS changes without making network requests.
3. Implement reproducible budget tests that stop repeated actions, oversized output, and quota races while preserving valid work.

Allocate **10 hours**: concepts 2, practice 5, evaluation 2, and writeup 1. Infrastructure controls must be distinguished from application checks throughout your report.

## Isolation limits what a compromised component can reach

An agent can be policy-compliant most of the time yet process attacker-controlled data. A local extension may also contain a software defect. Plan for a component making a forbidden request despite its prompt. Isolation reduces the resources available to that compromised component.

A process boundary is not automatically a security boundary. A child process running as the same unrestricted user may read the same credentials and files. A container can provide useful isolation, but shared host mounts, a container-engine socket, elevated capabilities, or a privileged runtime can defeat the intended boundary. Do not describe “runs in Docker” as a complete sandbox specification.

Describe the actual policy: nonprivileged identity, minimal filesystem mounts, read-only inputs, bounded writable scratch space, restricted syscalls where supported, no host-management sockets, minimal environment, no ambient production credentials, and cleanup after each job. Patch the isolation mechanism and define its limitations. Stronger workload separation may require an appropriately configured VM or other isolation technology, depending on the threat model.

Separate model reasoning from tool execution. A broker should validate a narrow request and expose only a scoped operation, not hand the agent general filesystem or shell access. The course's tools simulate tickets and drafts; the reference lab is not a sandbox test and does not justify claims about containing arbitrary code.

## SSRF is misuse of the application's network authority

Server-side request forgery occurs when untrusted input influences a request made by a component with network access. An agent need not have a generic fetch tool to create this risk. OAuth discovery metadata, document ingestion, callbacks, and remote image loading can all introduce URL inputs.

The MCP Security Best Practices **Server-Side Request Forgery** section identifies discovery surfaces including `resource_metadata`, `authorization_servers`, and authorization-server endpoints. These are data to validate, not trusted destinations merely because they arrived during an authentication flow.

Start with the business requirement. If only specific services are necessary, choose a destination allowlist and narrow methods, ports, and paths. Reject unsupported schemes, embedded user information, malformed names, and unexpected ports. Use established parsers rather than string prefixes. A host ending in the approved characters is not necessarily the approved host.

The general rule is canonicalize, then compare. Unicode normalization, case folding, percent-decoding, and path and host normalization must happen before an allowlist check, and the canonical form must be the one actually used, or the check and the use diverge. The same rule governs approval arguments in Modules 08 and 09 and file paths in Module 22.

Resolution creates another boundary. Inspect all candidate addresses and reject private, loopback, link-local, or otherwise forbidden ranges according to deployment policy. Consider IPv6 and IPv4-mapped addresses. Do not assume one public DNS answer makes every answer acceptable. A host can resolve differently between validation and connection, creating a DNS TOCTOU flaw.

The validated address must remain coupled to the connection, while preserving intended hostname and TLS verification. Connection pools, proxies, and retries can complicate that coupling. Disable automatic redirects or apply the full policy to every hop. Limit response bytes, redirects, and time. Independent egress enforcement provides a second boundary if application validation is bypassed.

Production default-deny policy differs from a deliberate development exception. This course never contacts metadata services or other internal endpoints. Even loopback URLs are strings in the mandatory extension tests, not services to probe. If a later authorized integration uses loopback, scope the exception explicitly rather than weakening the production rule.

## Quotas are authorization over resources

A tool loop can exhaust CPU, memory, storage, concurrency, or a paid service budget without violating a per-call schema. Limits must apply to the whole workflow and to the aggregate user or tenant, not just one request. Resetting the counter on every retry defeats the control.

Use layered budgets: maximum steps, tool calls, retries, output bytes, document sizes, wall-clock duration, concurrent jobs, and retained memory. With a real model adapter, add input/output token and monetary ceilings using measured accounting. The simulator has no model tokens or paid API; its numeric budgets are illustrative teaching fixtures, not performance benchmarks.

Reserve capacity before work and reconcile actual use afterward. Use a shared atomic counter for concurrent workers. Deny or defer work if the accounting service is unavailable. Decide how canceled jobs release unused reservations and how already performed work remains charged. A timeout should not spawn unlimited retries or erase usage.

OS-level CPU and memory enforcement protects the host even if application counters fail. Conversely, an OS limit does not enforce a tenant's business quota. Bounded logs, queue lengths, and temporary files matter too. Distinguish an action rejected by policy, one canceled on deadline, and one whose external outcome is uncertain.

## Rate limiting and unbounded consumption

The per-instance attempt quota in the reference lab is the smallest member of a family. OWASP's LLM list calls the risk unbounded consumption: tokens, tool calls, recursion depth, and wall-clock time are resources that an injected agent, an abusive user, or a bug can spend on the operator's bill (denial of wallet), on other users' availability, or on reconstructing the model through high-volume querying (Module 13). Each resource needs a limit enforced outside model reasoning.

A rate limit bounds requests per principal per window; a fixed window is simple, a sliding window is fairer at the boundary; the response on exceeding it is a 429 with no partial effect. A token budget bounds input and output size per request and per session; apply it to retrieved context as well as user text, or a large document becomes a cost attack. A loop budget bounds steps, retries, and fan-out in the orchestrator, and in a multi-agent system (Module 24) it must shrink at every hop. Reserve the budget before the effect, as the worked example below does, so that a failure between reservation and effect fails closed. Record the reservation in the trace; a budget that was exceeded silently is a detection gap for Module 18.

## Worked example: reserve before the effect

This single-threaded, offline example uses deliberately small fixture limits:

```python
class Budget:
    def __init__(self, calls=3, bytes_left=64):
        self.calls = calls
        self.bytes_left = bytes_left

    def reserve(self, result_bound):
        if result_bound < 0:
            raise ValueError('invalid bound')
        if self.calls < 1 or result_bound > self.bytes_left:
            raise RuntimeError('budget exhausted')
        self.calls -= 1
        self.bytes_left -= result_bound

budget = Budget()
for _ in range(3):
    budget.reserve(16)
assert budget.calls == 0
```

A fourth reservation must fail before a tool effect occurs. Count encoded bytes, not characters, when enforcing byte limits. This example conservatively charges the reserved amount; it has no refund, synchronization, wall-clock watchdog, or OS containment. Those limitations are part of the exercise, not hidden implementation guarantees.

## Safe lab: separately built egress and budget extensions

**Setup.** Run the reference tests from `reference-lab`, then create a learner-owned extension directory. Use `unittest`, `urllib.parse`, `ipaddress`, and in-memory fixtures only. Do not start a network server, resolve real DNS, make HTTP requests, or invoke an external target. Keep all traffic simulated.

**Practice steps, five hours.**

1. Write a sandbox policy describing identity, mounts, environment, process limits, scratch quota, and egress. Identify which controls need infrastructure and cannot be validated by `AgentService`. Do not execute arbitrary generated code to “test” the policy.
2. Build a URL-policy evaluator and fake resolver. Use a fixed approved hostname such as `docs.example.test`, permitted HTTPS port, and a documentation-range IP label. Because documentation addresses are not public destinations, make their allowance an explicit fixture-only rule, never a production allowlist. The fake transport maps labels to canned responses and has no sockets.
3. Build local cases for an approved fixture, an unapproved hostname, user-info confusion, disallowed schemes, wrong ports, loopback, private IPv4, link-local, and IPv4-mapped IPv6. Represent addresses as strings only. Classify every returned address; mixed acceptable/forbidden answer sets must not bypass policy.
4. Simulate an approved response redirecting to a denied destination and a DNS answer changing between check and use. Instrument the fake connection with the validated address; verify it never selects the later forbidden address. Cap redirect count and canned response bytes. This tests your policy model, not a real HTTP client's behavior.
5. Wrap simulator tool calls with budgets for calls and bytes. Use three-call and 64-byte fixture limits initially. Verify positive work, the rejected fourth reservation, an oversized prerecorded response, invalid negative reservations, and retries retaining usage. Add a locked shared reservation implementation and two concurrent contenders for one remaining slot; at most one may obtain it. Use injected time for deadline tests.

**Expected observations and negative tests.** An approved fixture succeeds. Disallowed destinations and redirect hops fail without any fake request to their label. DNS changes do not substitute an unvalidated address. Exhausted budgets stop before a ticket update or draft mutation. A cancellation does not reset consumed quota, and a concurrent reservation cannot overdraw it.

**Deliverables.** Submit executable offline tests, the sandbox policy, fake resolution/redirect traces, and before/after ticket and outbox assertions. Explain which guarantees require OS enforcement or a real transport extension. A future real SSRF integration remains separately built, explicitly authorized, local-only, and egress-denied; it is not included in this simulator or demonstrated by these tests.

## Evaluation and mastery gate

Spend two hours challenging the policy and quota implementation, then one hour reporting. Pass when negative destinations never reach even the fake transport, valid fixtures still succeed, and quota denials precede effects. Explain DNS TOCTOU, aggregate accounting, and the difference between a Python policy function and a sandbox. Claims of production SSRF resistance from finite fixture tests fail the gate.

## Quiz

1. Why is a container label insufficient evidence of isolation?
2. Why must redirect targets and all resolved addresses be checked?
3. How does a DNS TOCTOU flaw arise, and which two layers reduce its risk?
4. Why must retries and concurrent workers share a workflow budget?

See the [instructor key](../instructor/answers-09-12.md) and revisit [MCP boundaries](10-mcp-security.md) when applying discovery policies.

## Primary-source readings

- [MCP Security Best Practices, Server-Side Request Forgery](https://modelcontextprotocol.io/specification/latest/basic/security_best_practices#server-side-request-forgery-ssrf), including redirects, egress proxies, and DNS TOCTOU.
- [OWASP SSRF Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html), for application and network-layer defenses.
- [OWASP AI Agent Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html), for isolation, least privilege, and resource-consumption controls.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V07 DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](../MEDIA-LIBRARY.md#v07).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](../MEDIA-LIBRARY.md#b12).
- Discuss/critique: [R06 Handling MCP authorization-boundary failures](../MEDIA-LIBRARY.md#r06).
- Optional short commentary: [X04 Restrict agent actions rather than giving arbitrary execution authority](../MEDIA-LIBRARY.md#x04).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
