# Module 13: Model Privacy and Extraction

## Prerequisites, objectives, and time

You need Python functions, dictionaries, basic probability, and the distinction between training and inference. A model learns parameters from examples; an inference interface exposes predictions from those parameters. You do not need to train a neural network in this module.

By the end, you can:

1. Distinguish model extraction, membership inference, and memorization-based training-data extraction in a written threat model.
2. Measure query cost, held-out functional agreement, and membership false positives on synthetic fixtures.
3. Propose controls at data, training, and serving boundaries without claiming a finite test proves privacy.

Spend 2 hours on concepts, 5 on practice, 2 on evaluation, and 1 on the writeup. These are estimated learning hours, not a certification of expertise.

## Three different questions

**Model extraction** asks, “Can I reproduce the model's useful behavior?” A requester collects input-output pairs and constructs a substitute. Sometimes parameters can be recovered algebraically; often only behavior on a distribution is approximated. High agreement does not establish identical weights, architecture, or training records. Intellectual-property theft and preparation for other attacks are distinct possible consequences.

**Membership inference** asks, “Was this particular record used for training?” The attacker already has a candidate record and uses evidence such as loss or confidence to infer its membership. A successful prediction does not reconstruct the record. Overfitting can create a signal because training examples receive systematically different outputs, but high confidence alone is not proof. Easy nonmembers can look like members; difficult members can look like nonmembers.

**Memorization** is a property: training-specific content influences a model strongly enough that particular content can be reproduced. **Training-data extraction** is an attack objective: recover training examples not already supplied by the requester. Verbatim generation is evidence requiring investigation, not automatic proof of a private training source. The same string might be public, in the prompt, in retrieval context, or in an application cache. A retrieved secret is a retrieval authorization failure, not necessarily model memorization.

The terminology matters operationally. Disabling retrieval may address one leak while doing nothing to information already encoded in weights. Restricting probability outputs may reduce one extraction channel while label-only queries remain informative. Deleting a training file does not by itself remove its influence from an already-trained model.

## First principles: information crosses an interface

A prediction conveys information. If an interface reveals enough independent constraints about a small model, a requester may solve for its parameters. If outputs differ between neighboring training datasets, they may convey membership evidence. If a generator assigns unusually high probability to a distinctive training sequence, sampling or targeted queries may expose it.

Specify the attacker's access before measuring anything: label versus score outputs, query budget, candidate records, background knowledge, and whether weights are accessible. White-box and black-box settings should not be mixed in a single claim. Membership evaluation also needs a population assumption. A balanced test set is convenient, but it does not represent a deployment in which membership is rare. Precision changes with prevalence even if true-positive and false-positive rates remain constant.

For example, assume a hypothetical detector has sensitivity 0.8 and false-positive rate 0.1. If only one percent of candidates are members, its expected precision is `0.008 / (0.008 + 0.099)`, about 7.5 percent. This is arithmetic under stated assumptions, not a measured detector result.

## Worked example: recovering a tiny score model

This local logistic function has two unknown coefficients. Assume exact, unrounded probabilities and a known model family. The logit, `log(p / (1-p))`, turns the output back into a linear equation. Two independent queries therefore determine two coefficients.

```python
import math

def score(x):
    # Entirely synthetic teacher, not a hosted model.
    return 1 / (1 + math.exp(-(4 * x - 1)))

def logit(p):
    if not 0 < p < 1:
        raise ValueError("logit requires an interior probability")
    return math.log(p / (1 - p))

p0, p1 = score(0), score(1)
b = logit(p0)
a = logit(p1) - b
assert math.isclose(a, 4, abs_tol=1e-9)
assert math.isclose(b, -1, abs_tol=1e-9)
```

This is equation solving, not a faithful replica of arbitrary model theft. Unknown architecture, rounding, noise, calibration, dimensions, and limited input access change the problem. Returning labels removes these equations, but exposes the decision boundary. For this fixture the boundary is where `4*x-1=0`; bisection can estimate it without recovering the score function. Functional fidelity must therefore specify which outputs count as agreement.

## Safe lab: a privacy evidence notebook

### Setup

Use Python's standard library in a disposable local working directory. No network, real personal records, external model, or API key is needed. Copy the worked example into your own script. Create three fixture components: the score function, a label wrapper returning `int(score(x) >= 0.5)`, and a deliberately constructed dictionary containing `{"SYN-CANARY": "TRAIN_ONLY_SYNTHETIC_17"}`. The dictionary is a leakage simulator, not a language model.

### Steps

1. Count score queries and recover the two coefficients. Compare a substitute against the teacher on `[-0.5, 0.1, 0.25, 0.7, 1.5]`, reserved for evaluation. Report score error separately from label agreement.
2. Expose only labels. Start a search interval at `[0, 1]`; repeatedly query its midpoint and keep the half containing the transition. Stop after eight queries. Record the final interval and test both endpoints. Do not claim the slope was recovered.
3. Create membership fixtures with member scores `[0.95, 0.80, 0.45, 0.60]` and nonmember scores `[0.90, 0.55, 0.40, 0.30]`. Classify scores at least 0.70 as members. Calculate all four confusion-matrix counts, sensitivity, specificity, and precision. These scores deliberately encode overlap; they are not outputs of a trained attack.
4. Evaluate thresholds 0.50 and 0.90 on a development copy. Choose a threshold for a stated false-positive tolerance, then freeze it. Make a fresh synthetic holdout with different values before claiming generalization. Keep the membership labels hidden from the detector.
5. Implement canary lookup, then a version that suppresses the synthetic canary output. Record exactly which channel was closed. Compare that intervention with removing probabilities from the logistic endpoint; explain why they target different risks.

### Expected observations and negative tests

Exact scores permit coefficient recovery within floating-point tolerance. Label bisection narrows a boundary interval, not a complete probability function. Overlapping membership fixtures produce both false positives and false negatives at the initial threshold. Canary suppression affects dictionary output but not the independently defined score endpoint.

Negative tests must include an invalid logit input, an easy nonmember with high confidence, an unknown canary key, and a non-canary request that should remain usable. Repeat evaluation after rounding score outputs. Record observed changes rather than assuming rounding solves extraction. An interval entirely on one side of the boundary must fail your bisection precondition instead of producing a misleading estimate.

### Deliverables

Submit code, query counts, frozen evaluation inputs, confusion counts, and a one-page threat model. Separate calculated fixture expectations from actual execution logs. Include a statement that neither the dictionary nor supplied membership scores reproduce neural memorization or a statistically trained inference attack.

## Controls and their limits

Minimize and govern training data, remove unnecessary sensitive fields, track dataset lineage, and investigate duplication. Regularization and early stopping can reduce overfitting but are not universal privacy guarantees. Differential privacy provides a formal neighboring-dataset guarantee when its assumptions, clipping, randomness, and privacy accounting are implemented correctly; an epsilon value without that context is inadequate. Implementing and auditing private training is an extension project, not this lab.

At serving time, consider authentication, per-principal quotas, restricted output detail, and monitoring for unusual query patterns. These can change cost and exposure without eliminating extraction. Protect weights and backups as confidential artifacts. For deletion requests, distinguish removing source data, rebuilding indexes, retraining, and evaluating residual model influence. Plan for incident response rather than relying exclusively on an output filter.

## Quiz

1. A requester reproduces labels accurately but cannot identify training records. Which objective was demonstrated?
2. Why can a high-confidence membership rule have poor precision in a low-prevalence population?
3. A secret disappears when retrieval is disabled. What evidence would you need before attributing it to memorization?
4. Why does returning labels instead of probabilities not establish extraction resistance?

## Mastery gate

Pass when you can reproduce the local calculations, explain every confusion count, distinguish all three attack objectives, and defend one control per relevant boundary. You must explicitly reject an unsupported privacy guarantee. See [instructor guidance](../instructor/answers-13-16.md) and continue with [adversarial ML](14-adversarial-machine-learning.md).

## Primary readings

- [NIST AI 100-2e2025: AML taxonomy](https://www.nist.gov/publications/adversarial-machine-learning-taxonomy-and-terminology-attacks-and-mitigations-0): compare privacy objectives and attacker access.
- [Tramèr et al.: Stealing Machine Learning Models via Prediction APIs](https://arxiv.org/abs/1609.02943): inspect output assumptions, not just reported fidelity.
- [Shokri et al.: Membership Inference Attacks](https://arxiv.org/abs/1610.05820): distinguish candidate membership from record reconstruction.
- [Carlini et al.: Extracting Training Data from Large Language Models](https://arxiv.org/abs/2012.07805): examine the evidence used to identify extracted examples.

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V33 How might LLMs store facts | Deep Learning Chapter 7](../MEDIA-LIBRARY.md#v33) (recommended, v1.3).
- Watch: [V08 Overview of Adversarial Machine Learning](../MEDIA-LIBRARY.md#v08).
- Read: [B09 Extracting (Even More) Training Data From Production Language Models](../MEDIA-LIBRARY.md#b09).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
