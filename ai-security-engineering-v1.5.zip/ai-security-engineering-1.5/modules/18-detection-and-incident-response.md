# Module 18: Detection and Incident Response

## Prerequisites and outcomes

Complete the bounded campaign in [Module 17](17-automated-red-teaming.md). Know the difference between authenticated fixture identity and untrusted content. This module is 10 hours: concepts 2, practice 5, evaluation 2, writeup 1.

By completion, you will:

1. Design an audit schema that supports three security questions without retaining raw secrets.
2. Implement and test deterministic detection rules against labeled synthetic sequences, including benign controls and telemetry gaps.
3. Produce an incident timeline, proportionate containment decision, and evidence-backed recovery criteria.

## Observe decisions, not just suspicious language

An agent's conversation is only one view of an operation. Relevant evidence also includes retrieval authorization, approval issuance and consumption, tool validation, memory changes, and policy version. A prompt containing “ignore instructions” may be quoted training material. A mundane request can expose a genuine tenant-filter failure. Detection should prioritize invariant violations and meaningful correlations rather than treating particular words as proof of compromise.

Design events around who, what, when, where, and outcome. Useful fields include schema version, event identifier, interaction identifier, authenticated actor reference, tenant, resource reference, policy version, action, decision, and bounded reason code. Distinguish event time from collection time. Workload identity and end-user identity answer different questions. A model-generated actor name is not an authenticated principal.

Collect enough to reconstruct a decision, but avoid raw prompts, customer documents, credentials, opaque approval tokens, and unrestricted tool arguments. Pseudonymous identifiers can still be sensitive. Protect them with access controls and purpose-specific retention. Content needed for an authorized investigation belongs in a separately restricted evidence process, not a default verbose log. Structured JSON escapes delimiters, but does not automatically make content nonsensitive or trustworthy.

An event can be missing, duplicated, late, forged, or mislabeled. Sequence checks need a trustworthy source and baseline. A hash detects a change relative to a retained digest; it does not authenticate the original source or prevent an attacker from replacing both. Production evidence protection requires controls beyond this in-memory lab.

Before the example, one piece of arithmetic that governs every alert. If one in ten thousand sessions is an attack and a rule fires on one percent of benign sessions, then in a million sessions the rule raises roughly ten thousand benign alerts against at most a hundred real ones, regardless of how sensitive it is. Alert precision depends on the base rate. A rule's operational value is its false-positive rate times traffic volume, not its hit rate on labelled attack fixtures; Module 13 derived the same result for membership inference.

## Worked example: detection confidence

A burst of denied foreign-ticket reads is a triage signal. Three denials by one actor in one tenant within 60 seconds is an illustrative lab threshold, not a researched production baseline. A usability bug could produce that sequence. An allowed cross-tenant read is stronger evidence of a broken invariant, but its event must still be corroborated with actual resource ownership and returned state.

Separate three claims: “the rule matched,” “an unauthorized operation occurred,” and “data left the system.” They require different evidence. If the read was denied, say attempted access. If collection stopped, say visibility is incomplete. Absence of a recorded alert does not prove absence of compromise.

## Safe lab: replay a synthetic incident

### Setup

Run only local Python. This exercise defines its own synthetic event schema; it is not a prebuilt adapter for the reference lab's audit list. Save the following as `detect18.py` in your learner workspace. Integer times are fixture seconds, not wall-clock timestamps. Every record is synthetic.

```python
import json
from collections import defaultdict, deque


def event(n, t, actor="alice", tenant="alpha",
          outcome="deny", reason="tenant", resource_tenant=None):
    return dict(id=f"E{n}", seq=n, time=t, actor=actor,
                tenant=tenant, outcome=outcome, reason=reason,
                resource_tenant=resource_tenant or tenant)


def detect(events):
    seen, alerts, gaps = set(), [], []
    windows = defaultdict(deque)
    previous = 0
    for e in events:
        if e["id"] in seen:
            continue
        seen.add(e["id"])
        if e["seq"] != previous + 1:
            gaps.append((previous, e["seq"]))
        previous = e["seq"]
        if e["outcome"] == "deny":
            q = windows[(e["tenant"], e["actor"])]
            while q and q[0] < e["time"] - 60:
                q.popleft()
            q.append(e["time"])
            if len(q) == 3:
                alerts.append(("deny_burst", e["id"]))
        if e["reason"] == "approval_replay":
            alerts.append(("approval_replay", e["id"]))
        if (e["outcome"] == "allow" and
                e["tenant"] != e["resource_tenant"]):
            alerts.append(("cross_tenant_allow", e["id"]))
    return dict(alerts=alerts, sequence_gaps=gaps)


fixtures = [
    event(1, 0, outcome="allow", reason="owned_read"),
    event(2, 10), event(3, 20),
    event(4, 25, actor="bob", tenant="beta"),
    event(5, 30),
    event(6, 40, outcome="allow", reason="approved_update"),
    event(7, 50, reason="approval_replay"),
    event(8, 60, outcome="allow", reason="synthetic_violation",
          resource_tenant="beta"),
]
result = detect(fixtures)
assert result["alerts"] == [
    ("deny_burst", "E5"), ("approval_replay", "E7"),
    ("cross_tenant_allow", "E8")]
assert result["sequence_gaps"] == []
assert detect(fixtures + [fixtures[4]]) == result
print(json.dumps(result))
```

### Investigation steps

1. Run the script and preserve the fixture revision and output as `detection18.json`. Expect exactly the three specified alerts and no sequence gaps. Bob's denied event must not contribute to Alice's burst.
2. Construct a benign sequence with owned reads and approved updates. Expect no security alerts. Construct two denials within the window; expect no burst. Move the third denial outside the window and verify it does not trigger the threshold.
3. Remove E6. Expect a sequence gap from 5 to 7 and retain the security alerts. Remove the final event separately: explain why this unanchored detector cannot discover truncation at the end. Duplicate E5: it must not inflate the burst count.
4. Add schema validation for missing fields, unknown outcomes, noninteger times, and oversized identifiers. Route invalid records to a bounded diagnostic counter, never silently count them as clean events. Reject duplicate identifiers with conflicting payloads rather than trusting this example's simple deduplication.
5. Inspect actual `s.audit.events` from the [reference lab](../reference-lab/CONTRACT.md). Document observed field names before writing a normalization function. Map only supported fields; mark unavailable timing or resource-ownership evidence as unknown. Do not claim the synthetic detector was integrated merely because its fixtures ran.
6. Write a timeline distinguishing normal use, denied attempts, replay, and the deliberately injected allowed foreign read. E8 is fabricated to test detection, not a demonstrated vulnerability in the hardened reference service.

### Negative tests and response drill

Replay out-of-order input. The demonstration assumes ordered fixture timestamps and one sequence stream; document its incorrect or ambiguous behavior rather than reporting a valid production detection. Your improved implementation should distinguish late collection from a gap, partition sequences by source, and cap stored windows. A single noisy user must not exhaust memory or cause automated suspension of another tenant.

Using only paper decisions or local state, assign an incident commander and preserve original evidence. For an observed authorization breach, contain the affected tool or tenant workflow, invalidate relevant approvals, and pause simulated drafts while maintaining safe read-only service when justified. Do not send real email, revoke production accounts, or perform cloud actions. Identify affected retrieval material and memory entries; quarantining content must not destroy the forensic copy.

Recovery requires a corrected control, replayed regression and legitimate-use tests, restored telemetry, and an accountable approval. A restart or reassuring model response is insufficient. Record what data was accessible, what was actually observed, and what cannot be established. Legal reporting obligations depend on jurisdiction and facts; this lab does not determine them.

## Operationalizing the lessons

NIST SP 800-61 Revision 3 integrates incident response into cybersecurity risk management using CSF 2.0. Preparation includes roles, evidence access, communication paths, and tested recovery. Keep a decision log when scope expands or containment changes. Review false positives, blind spots, and time-to-detection using actual exercise timestamps, not invented metrics.

Build a logging-failure policy appropriate to the operation. For a high-impact write, an unavailable required audit sink may warrant failing closed or disabling writes. For a low-risk read, bounded buffering may be acceptable if authorized. Specify the tradeoff and monitor dropped records; “logging must never affect availability” is not a universal safety rule. Test retention, access, disposal, and detection-health signals as well as the detection query itself.

## Deliverables and mastery gate

Deliver the detector and fixture set, baseline output, at least six negative or benign tests, schema and retention rationale, timeline, containment decision, recovery checklist, and an uncertainty section. Preserve metadata only. Feed evidence gaps and accountable ownership into [Module 19](19-cloud-governance-and-risk.md).

Pass when alerts match labeled fixtures, benign controls remain usable, duplicate and gap cases are explained, and recovery is tied to verified controls. The gate fails if you call denied access confirmed leakage, claim final-event truncation detection without an anchor, or present fabricated E8 as a real incident.

## Quiz

1. Why is a denial burst not conclusive evidence of data leakage?
2. What separates event integrity from source authenticity?
3. Why can deleting the final event evade this sequence-gap rule?
4. Which evidence should justify restoring a disabled write workflow?

## Primary readings

- [NIST SP 800-61 Revision 3, final publication](https://csrc.nist.gov/pubs/sp/800/61/r3/final)
- [OWASP Logging Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html)
- [OWASP AISVS monitoring and logging chapter, versioned source](https://github.com/OWASP/AISVS/blob/main/1.01/en/0x10-C12-Monitoring-and-Logging.md)

[Instructor answers](../instructor/answers-17-20.md#module-18)

## Curated media and discussion

Use these alongside the lesson, not instead of its lab. See [the full module index](../MEDIA-INDEX.md) for additional choices.

- Watch: [V40 BSidesSF 2025 - When AI Goes Awry: Responding to AI Incidents (Eoin Wickens, Marta Janus)](../MEDIA-LIBRARY.md#v40) (core, v1.3).
- Watch: [V41 BSidesSF 2025 - AI's Bitter Lesson for SOCs: Let Machines Be Machines (Jackie Bow, Peter Sanford)](../MEDIA-LIBRARY.md#v41) (optional, v1.3).
- Watch: [V07 DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](../MEDIA-LIBRARY.md#v07).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](../MEDIA-LIBRARY.md#b12).
- Discuss/critique: [R03 Evaluating agentic AI security before production](../MEDIA-LIBRARY.md#r03).
- Optional short commentary: [X03 Hidden PDF content and a reported Notion exfiltration path](../MEDIA-LIBRARY.md#x03).

The linked resource entries include publication context, exercises, limitations and verification notes. Social discussions are optional, not technical authority.
