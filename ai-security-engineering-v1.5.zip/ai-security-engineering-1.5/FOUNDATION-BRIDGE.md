# Optional foundation bridge

## Who needs this

Use this bridge if the diagnostic reveals gaps in Python, Git, HTTP, SQL, or basic security reasoning. Budget twenty additional hours. If programming is entirely new, take an introductory Python course first; twenty hours is not a realistic substitute for becoming comfortable with code.

The bridge produces a small reproducible workspace, not an AI application. Its exercises use synthetic data and the standard library. Complete the exit gate before beginning the core course.

## Block 1: Python and command line, five hours

Learn functions, dictionaries, lists, immutable strings, exceptions, context managers, imports, and dataclasses. Distinguish equality from object identity. Explain what a type annotation does and does not enforce at runtime. Practice navigating directories, running a module, and reading a traceback.

Build a function that accepts a dictionary with exactly ticket_id and status string keys and values. Reject missing keys, extra keys, non-string values, empty strings, and unknown statuses. Return a new normalized object rather than mutating the input. Use an explicit exception type for rejection.

Write tests for valid input, a list instead of a dictionary, a numeric ticket identifier, an extra tenant field, and a status outside the allowlist. Assert that the caller's dictionary is unchanged. Do not print credentials or raw attacker input in error messages.

Primary reading, relevant sections only at first: the [Python tutorial](https://docs.python.org/3/tutorial/) and [unittest](https://docs.python.org/3/library/unittest.html).

## Block 2: Git and testing, four hours

Create a local repository. Commit a baseline, create a branch, change a control, observe a failing test, restore the control, and inspect the diff. Add a .gitignore for Python caches, virtual environments, local credential files, and generated artifacts. Git history is not a secret store: deleting a committed key from the latest file does not remove it from history or revoke it.

Build a small suite where one intentionally broken function returns another tenant's record. The positive control should reproduce the disclosure. The fixed function should require tenant equality. Preserve both expected behaviors as explicit teaching fixtures; do not make the default implementation vulnerable.

Exit evidence: a commit log, green defended tests, one screenshot or saved output of the intentional failing test, and an explanation of why you restored rather than deleted the assertion.

Primary reading: [Git documentation](https://git-scm.com/doc) and the supplied reference lab's tests.

## Block 3: HTTP, JSON, and identity, four hours

Explain methods, paths, headers, bodies, status codes, and cookies. Distinguish syntax validity from permission. Parse JSON into typed application data. A field named admin is data unless a trusted policy source makes it authoritative. A signed token also requires issuer, audience, expiry, and permission checks.

Use two saved JSON request fixtures rather than calling an external service. One requests an own-tenant ticket; the other supplies a forged tenant field. Define a trusted session fixture separately from the request. Your handler must derive tenant from the session, reject unsupported argument keys, and return a generic resource-not-available result for unauthorized access.

Explain why browser UI restrictions do not prevent direct HTTP requests. Write a bypass test that calls the handler without the UI.

Primary readings: [OWASP Authentication](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html) and [Authorization](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html) cheat sheets.

## Block 4: SQL and basic probability, four hours

Use Python's sqlite3 module with an in-memory database. Create a tickets table with tenant and ticket_id columns. Insert two synthetic records. Write a parameterized query that includes the trusted tenant and identifier. Do not concatenate user input into SQL. Parameters bind data values; they do not make arbitrary identifiers or SQL syntax safe.

Test a normal lookup, a foreign identifier, a nonexistent identifier, and punctuation-heavy input. The foreign and nonexistent records should both be unavailable. Read-only access is not enough if the query can read every tenant.

For probability, compute a simple fraction of successes over attempts and explain why the denominator matters. Ten repeated variants of one attack are not ten independent attack families. A toy pass rate is not a universal security probability.

Primary reading: the [Python sqlite3 documentation](https://docs.python.org/3/library/sqlite3.html), used with in-memory fixtures only.

## Block 5: exit gate, three hours

Complete the diagnostic again without the answer key. Demonstrate input validation, tenant-scoped read, one denied operation with unchanged state, and a Git diff showing the control. Explain authentication, authorization, approval, and audit in your own words.

The exit gate requires all four practical tasks and at least eight of ten diagnostic answers. If the gate fails, repeat the weak block. Record missing knowledge rather than guessing. After passing, begin Module 01; it uses these fundamentals in an AI-system context.
