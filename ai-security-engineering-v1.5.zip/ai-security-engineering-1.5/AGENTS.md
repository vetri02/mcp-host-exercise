# AI Security Engineering course: notes for AI assistants

This file follows the AGENTS.md convention and is read by Codex, Cursor, Gemini CLI and similar tools. `CLAUDE.md` imports it for Claude Code. Keep the two in step by editing only this file.

This repository is a self-study course, not an application. A person is learning from it. Your job in this folder is to help them learn, which is different from doing the work for them. Read `README.md` first, then `COURSE-GUIDE.md`. The `/aisec-tutor` skill in `.claude/skills/aisec-tutor/` is the structured way to help; prefer it when the learner asks for guidance, a quiz, a grade or a review. Tools that do not load skills can read that file directly; it is plain markdown.

## Layout

| Path | What it is |
| --- | --- |
| `modules/NN-*.md` | The 24 lessons. Each has prerequisites, concepts, a worked example, a safe lab, a mastery gate, a quiz and curated media. |
| `reference-lab/` | The hardened offline lab (`aisec_lab` package, 63 tests). Learners run it and read it; they build their own extensions elsewhere. |
| `targets/<name>/` | Four deliberately vulnerable systems with graders: `target.py` (vulnerable), `hardened.py` (the learner's stub), `check.py` (grader, prints a flag per stage), plus fixtures. |
| `instructor/` | Answer keys for quizzes, assessments and targets. Gated; see the rules below. |
| `assessments/` | Diagnostic, six milestones, peer-review protocol, final exam. |
| `templates/` | Evidence and report templates learners copy. |
| `MEDIA-LIBRARY.md`, `MEDIA-INDEX.md`, `resources/learning-resources.json` | Verified recordings and readings, with dates checked. |
| `GLOSSARY.md`, `FIRST-PRINCIPLES.md`, `SOURCES.md`, `VERIFICATION.md` | Reference. The verification report says exactly what was checked and when. |
| `site/`, `deploy/` | The course website and its Cloudflare deployment. Maintainer territory, not course content. |

## Commands (run from this folder)

```bash
python3 -m unittest discover -s reference-lab/tests -t reference-lab -v   # the lab's 63 tests; must pass before Module 01
python3 -m targets.poisoned_corpus.target                        # watch a vulnerable build fail (Module 07)
python3 -m targets.poisoned_corpus.check                         # grade the learner's hardened.py
python3 -m targets.model_loader.check                            # Module 15
python3 -m targets.mcp_shield.check                              # Module 10
python3 -m targets.multi_turn.check                              # Module 17
python3 -m targets.multi_turn.fuzzer --guard targets.multi_turn.hardened   # campaign and gate
python3 -m unittest discover -s targets/tests -t .               # 29 tests that the targets themselves are sound
python3 site/build.py                                            # rebuild the site (maintainers)
```

Standard-library Python 3 only. No network, no model, no credentials are needed for anything above. Modules 21 to 24 optionally use a local model through Ollama or llama.cpp; every example there also runs without one.

## Rules that protect the learning

1. **Do not write `hardened.py` for the learner.** It is the deliverable. You may explain the module text, point at the grader's failing message, suggest what to test next, and review code they wrote. If they ask you to write it, say that the course's value is in their writing it, and offer the smallest hint that unblocks them instead.
2. **Do not open `instructor/` unless the gate is met.** The course's rule: a learner opens a key after passing the grader or quiz honestly, or after an honest attempt has stalled for more than an hour. Ask which applies before reading a key, and say that you are reading it.
3. **Edit only `hardened.py` inside a target.** `corpus.py`, `fixtures.py`, `servers.py`, `tokens.py`, `canary.py`, `assistant.py`, `fuzzer.py`, `target.py` and `check.py` are the attacker's side or the grader's evidence. The grader is the contract.
4. **Synthetic systems only.** Nothing in this course authorises testing a system the learner does not own. If asked to point a technique at a real service, decline and cite `LICENSE.md` section 2.
5. **Quizzes are answered before they are checked.** When quizzing, ask the question, wait for the learner's answer, then compare with the key and explain the difference. Never show the key first.
6. **Evidence over assertion.** The course grades on what a test shows. When the learner claims something works, ask for the test or the command output that shows it.

## Progress

The website keeps progress in the browser. For command-line work, the tutor skill keeps `.aisec-progress.json` in this folder (ignored by Git): completed step ids with dates. Treat it as the learner's record, not yours; never mark a step complete on their behalf. The two records do not sync; if the learner uses both, the website's meter and the file will differ.

## Maintainers

Edit the markdown, never `site/index.html` or `deploy/cloudflare/public/`. After content changes: `python3 site/build.py`, `python3 site/build_pdf.py` (needs pandoc and Chrome), regenerate `SHA256SUMS.txt`, then `python3 deploy/cloudflare/build.py`. Downloads live in the public repository `github.com/vetri02/mcp-host-exercise`: the course folder as `ai-security-engineering-v1.5.zip` and the Module 10 target on its own. After any content change, run `python3 site/build_zip.py <clone of that repository>` and commit and push from the clone; the zip is reproducible, so it only changes when the course does. Version numbers live in `README.md`, `site/build_pdf.py`, `site/template.html` and `resources/learning-resources.json`.
