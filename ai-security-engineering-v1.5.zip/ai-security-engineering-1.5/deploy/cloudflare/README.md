# Deploy the course site to Cloudflare

This folder turns the course into a static site served by a Cloudflare Worker: every course page pre-rendered at its own URL, with the embedded recordings. No server code runs; Cloudflare serves the files in `public/`.

## What you need

- Node 18 or newer (`node --version`)
- Python 3 (the site is assembled from the course markdown)
- A Cloudflare account; the free plan is enough

## First deploy

```bash
cd deploy/cloudflare
npm install            # installs wrangler locally
npx wrangler login     # opens the browser once; grants the CLI access to your account
npm run deploy         # builds public/ and uploads it
```

The last command prints the URL, of the form `https://ai-security-engineering.<your-subdomain>.workers.dev`. Every later change is the same `npm run deploy`.

## Preview locally first

```bash
npm run dev            # serves http://localhost:8787 with the same headers as production
```

## Use your own domain

In the Cloudflare dashboard open Workers & Pages, choose `ai-security-engineering`, then Settings, then Domains & Routes, and add the hostname. The zone must already be on Cloudflare, and nothing in this folder needs to change.

## Deploy from Git instead of your laptop

Push the course repository to GitHub or GitLab, then in Workers & Pages choose Create, Import a repository, and set:

| Setting | Value |
| --- | --- |
| Root directory | `deploy/cloudflare` |
| Build command | `npm ci && npm run build` |
| Deploy command | `npx wrangler deploy` |

Each push to the default branch redeploys. `npm ci` matters: the pre-renderer needs the `marked` package, which is not committed.

If you created a Pages project instead of a Worker, the equivalent settings are build command `cd deploy/cloudflare && npm ci && npm run build` and build output directory `deploy/cloudflare/public`, with the root directory left at the repository root.

**How to tell the deploy is wrong.** If `https://<your-host>/llms.txt` or `https://<your-host>/m01` returns 404 while the home page works, the project is publishing `site/index.html` on its own (for example, a Pages project with the output directory set to `site` and no build command). That single file still works as an app behind `#` routes, but the per-page URLs, the sitemap, `llms.txt`, the markdown sources and the favicon only exist in `public/`, which this build produces. Change the settings to the table above and redeploy.

## What the build does

`build.py` runs `site/build.py` to regenerate `site/index.html` from the markdown, writes `robots.txt`, and copies `_headers`. `public/` is generated and ignored by Git; edit the sources, not the output.

## Search engines and answer engines

The deployed site is not a single page behind `#hash` routes. `build.py` runs `prerender.mjs`, which writes one static HTML file per course page at its own URL (`/m05`, `/target-10`, `/glossary`, and so on) with the content already rendered, so a crawler or an answer engine that does not run JavaScript still sees the whole page. When the page loads in a browser, the app takes over the same URL and navigates with `history.pushState`.

Each page carries its own `<title>`, meta description, canonical link, Open Graph and Twitter Card tags, and JSON-LD structured data: `Course` and `WebSite` on the home page, `LearningResource` and `BreadcrumbList` on every other page. The course data lives in a separate `course-data.<hash>.js` file with a one-year cache so the hundred pages stay small.

For answer engines the build also writes `/llms.txt` (an index of every page with a one-line description, following the llms.txt convention), `/llms-full.txt` (the whole course as one markdown file), and the original markdown under `/md/`, excluding the instructor answer keys. `/sitemap.xml` lists every page and `/robots.txt` points at it. Unknown URLs return a real 404 with `noindex`.

The origin used in canonical links, the sitemap and `llms.txt` is `https://aisec.engineering`. Override it with `SITE_ORIGIN=https://example.com python3 build.py` for a different domain. After the first deploy, submit the sitemap in Google Search Console and Bing Webmaster Tools; nothing else needs registering. The Open Graph image is `og.png` in this folder; regenerate it if the course name or tagline changes.

## Headers and the embedded players

`_headers` sets a content security policy that allows exactly what the page uses: the marked library from cdnjs, YouTube thumbnails from `i.ytimg.com`, the YouTube no-cookie player in a frame, and the DEF CON archive as a media source. Everything else is refused. If you add a recording from a new host, add that host to `frame-src` (for an embedded player) or `media-src` (for a direct video file), or the page falls back to an open-in-new-tab card for it.

The page's own script is inline, which is why `script-src` carries `'unsafe-inline'`. Replacing it with a hash would mean recomputing the hash on every rebuild, so the trade is documented here instead.

## Privacy

`wrangler.jsonc` enables Workers observability, which keeps request logs in your Cloudflare account. Set `"observability": { "enabled": false }` if you would rather keep none. The page itself stores progress in the reader's browser and sends nothing to you; see section 8 of the course `LICENSE.md`.

## Limits

- Workers static assets accept files up to 25 MiB each; the largest file here is the course data script, under 1 MiB. The handbook PDF and the course-folder zip are downloaded from the public GitHub repository, not from this host.
- The free plan serves assets without counting against request limits; only Worker code invocations are metered, and this project has none.
- Recordings stream from YouTube and DEF CON, not from Cloudflare. If either host is unreachable the page shows the open-elsewhere card for that item.
