// Pre-render every course page to static HTML for crawlers and answer engines.
//
//   node prerender.mjs <course-data.json> <shell.html> <public dir> <course root> <origin>
//
// Each page is the full app shell with the step's content already in #page,
// its own <title>, description, canonical, Open Graph and JSON-LD. The app's
// JavaScript then takes over and re-renders identically. Also writes
// sitemap.xml, robots.txt, llms.txt, llms-full.txt and the markdown sources
// under /md/ so answer engines can read the course as text.
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { marked } from 'marked';

const [dataPath, shellPath, pub, courseRoot, origin] = process.argv.slice(2);
const DATA = JSON.parse(readFileSync(dataPath, 'utf8'));
const shell = readFileSync(shellPath, 'utf8');
const today = new Date().toISOString().slice(0, 10);
const byId = Object.fromEntries(DATA.steps.map(s => [s.id, s]));
const flow = DATA.steps.filter(s => s.flow);

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const slug = t => t.toLowerCase().trim().replace(/[^\w\s-]/g, '').replace(/\s/g, '-');
const href = id => (id === 'welcome' ? '/' : '/' + id);
function normPath(base, rel) {
  const parts = (base ? base.split('/') : []).concat(rel.split('/'));
  const out = [];
  for (const p of parts) { if (p === '..') out.pop(); else if (p && p !== '.') out.push(p); }
  return out.join('/').replace(/\/$/, '');
}

function render(step) {
  const renderer = new marked.Renderer();
  // marked 12 renderer signatures: heading(text, level), link(href, title, text)
  renderer.heading = (text, depth) => {
    const plain = text.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"');
    return `<h${depth} id="${slug(plain)}">${text}</h${depth}>\n`;
  };
  renderer.link = (h, title, text) => {
    const t = title ? ` title="${esc(title)}"` : '';
    if (/^https?:/i.test(h)) return `<a href="${esc(h)}"${t} target="_blank" rel="noopener noreferrer">${text}</a>`;
    if (h.startsWith('#') || h.startsWith('mailto:')) return `<a href="${esc(h)}"${t}>${text}</a>`;
    let [p, frag] = h.split('#');
    let id = DATA.paths[normPath(step.base, p)];
    const km = /^instructor\/answers-/.test(normPath(step.base, p)) && frag && frag.match(/^module-(\d\d)$/);
    if (km && byId['m' + km[1]]) { id = 'm' + km[1]; frag = ''; }   // the key is rendered by the app, not pre-rendered
    if (!id) return `<span class="dead">${text}</span>`;
    return `<a href="${href(id)}${frag ? '#' + frag : ''}"${t}>${text}</a>`;
  };
  const text = (step.md || '').replace(/^# .+\n+/, '');
  if (step.kind === 'code' || step.kind === 'csv') {
    return `<div class="prose"><pre><code>${esc(step.raw || '')}</code></pre></div>`;
  }
  return `<div class="prose" id="doc">${marked.parse(text, { gfm: true, renderer })}</div>`;
}

function railHtml(current) {
  const groups = [];
  for (const s of DATA.steps) {
    let g = groups.find(g => g.name === s.group);
    if (!g) groups.push(g = { name: s.group, items: [] });
    g.items.push(s);
  }
  return groups.map(g => `<h3><span>${esc(g.name)}</span></h3><ol>` + g.items.map(s =>
    `<li><a href="${href(s.id)}"${s.id === current ? ' aria-current="page"' : ''}><span>${esc(s.title)}</span></a></li>`).join('') + '</ol>').join('');
}

function jsonLd(step) {
  const url = origin + href(step.id);
  const author = { '@type': 'Person', name: 'Vetrichelvan Jeyapalpandy' };
  const course = {
    '@context': 'https://schema.org', '@type': 'Course',
    name: 'AI Security Engineering: Build, Break, Defend',
    description: byId.welcome.description, url: origin + '/',
    provider: { '@type': 'Person', name: author.name, url: origin + '/' },
    author, inLanguage: 'en', isAccessibleForFree: true,
    license: 'https://creativecommons.org/licenses/by/4.0/',
    educationalLevel: 'Intermediate',
    teaches: DATA.steps.filter(s => s.kind === 'module').map(s => s.title),
    hasCourseInstance: [{ '@type': 'CourseInstance', courseMode: 'Online', courseWorkload: 'PT280H', instructor: author }],
    offers: [{ '@type': 'Offer', category: 'Free', price: 0, priceCurrency: 'USD' }],
  };
  if (step.id === 'welcome') {
    return [course, { '@context': 'https://schema.org', '@type': 'WebSite', name: 'AI Security Engineering', url: origin + '/' }];
  }
  const crumbs = [{ '@type': 'ListItem', position: 1, name: 'AI Security Engineering', item: origin + '/' },
    { '@type': 'ListItem', position: 2, name: step.group, item: origin + href((DATA.steps.find(s => s.group === step.group) || step).id) },
    { '@type': 'ListItem', position: 3, name: step.title, item: url }];
  return [{
    '@context': 'https://schema.org', '@type': 'LearningResource',
    name: step.kind === 'module' ? 'Module ' + step.id.slice(1) + ': ' + step.title : step.title,
    description: step.description, url, inLanguage: 'en', isAccessibleForFree: true, author,
    license: 'https://creativecommons.org/licenses/by/4.0/',
    learningResourceType: step.kind === 'module' ? 'Lesson' : step.kind === 'assessment' || step.kind === 'milestone' ? 'Assessment' : step.kind === 'target' ? 'Exercise' : 'Reading',
    timeRequired: step.hours ? 'PT' + step.hours + 'H' : undefined,
    isPartOf: { '@type': 'Course', name: course.name, url: origin + '/' },
  }, { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: crumbs }];
}

function page(step) {
  const title = step.kind === 'welcome' ? 'AI Security Engineering: a free course on securing AI applications, agents and models'
    : (step.kind === 'module' ? 'Module ' + step.id.slice(1) + ': ' : '') + step.title + ' · AI Security Engineering';
  const url = origin + href(step.id);
  const head = [
    `<meta name="description" content="${esc(step.description)}">`,
    `<link rel="canonical" href="${url}">`,
    `<meta property="og:type" content="${step.kind === 'welcome' ? 'website' : 'article'}">`,
    `<meta property="og:site_name" content="AI Security Engineering">`,
    `<meta property="og:title" content="${esc(title)}">`,
    `<meta property="og:description" content="${esc(step.description)}">`,
    `<meta property="og:url" content="${url}">`,
    `<meta property="og:image" content="${origin}/og.png">`,
    `<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">`,
    `<meta name="twitter:card" content="summary_large_image">`,
    `<meta name="twitter:title" content="${esc(title)}">`,
    `<meta name="twitter:description" content="${esc(step.description)}">`,
    `<meta name="twitter:image" content="${origin}/og.png">`,
    `<script type="application/ld+json">${JSON.stringify(jsonLd(step)).replace(/</g, '\\u003c')}</script>`,
  ].join('\n');
  const h1 = step.kind === 'welcome' ? '' : `<div class="eyebrow"><b>${esc(step.group)}</b>${step.blurb ? '<span>' + esc(step.blurb) + '</span>' : ''}</div><h1 class="title">${esc(step.kind === 'module' ? 'Module ' + step.id.slice(1) + ': ' + step.title : step.title)}</h1>`;
  const fi = flow.indexOf(step);
  const prev = fi > 0 ? flow[fi - 1] : null, next = fi >= 0 ? flow[fi + 1] : null;
  const pager = `<nav class="pager">${prev ? `<a href="${href(prev.id)}"><small>Previous</small><span>${esc(prev.title)}</span></a>` : ''}${next ? `<a class="nx" href="${href(next.id)}"><small>Next</small><span>${esc(next.title)}</span></a>` : ''}</nav>`;
  const body = h1 + render(step) + `<div class="foot">${pager}</div>` +
    `<p class="legal">Free to use: code MIT, writing CC BY 4.0, third-party media under its owners’ terms. <a href="/license">Licence and terms</a>.</p>`;
  let html = shell.replace(/<title>[^<]*<\/title>/, `<title>${esc(title)}</title>`)
    .replace('<!--__HEAD__-->', head)
    .replace('<nav class="rail" id="rail" aria-label="Course path"></nav>', `<nav class="rail" id="rail" aria-label="Course path">${railHtml(step.id)}</nav>`)
    .replace('<main id="main"><div class="page" id="page"></div></main>', `<main id="main"><div class="page" id="page">${body}</div></main>`);
  return html;
}

// ---- pages ----
let count = 0;
for (const step of DATA.steps) {
  const out = step.id === 'welcome' ? join(pub, 'index.html') : join(pub, step.id, 'index.html');
  mkdirSync(dirname(out), { recursive: true });
  writeFileSync(out, page(step));
  count += 1;
}

// ---- 404 page ----
writeFileSync(join(pub, '404.html'), shell.replace(/<title>[^<]*<\/title>/, '<title>Page not found · AI Security Engineering</title>')
  .replace('<!--__HEAD__-->', '<meta name="robots" content="noindex">')
  .replace('<nav class="rail" id="rail" aria-label="Course path"></nav>', `<nav class="rail" id="rail" aria-label="Course path">${railHtml('')}</nav>`)
  .replace('<main id="main"><div class="page" id="page"></div></main>', '<main id="main"><div class="page" id="page"><h1 class="title">Page not found</h1><p>There is no page at this address. <a href="/">Start at the course home</a>, or pick a step from the path.</p></div></main>')
  .replace('<script src="/', '<script data-nojs="1" src="/'));

// ---- sitemap, robots ----
const urls = DATA.steps.map(s => `  <url><loc>${origin}${href(s.id)}</loc><lastmod>${today}</lastmod><changefreq>monthly</changefreq><priority>${s.id === 'welcome' ? '1.0' : s.kind === 'module' ? '0.8' : '0.5'}</priority></url>`);
writeFileSync(join(pub, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join('\n')}\n</urlset>\n`);
writeFileSync(join(pub, 'robots.txt'), `User-agent: *\nAllow: /\n\nSitemap: ${origin}/sitemap.xml\n`);

// ---- markdown sources and llms.txt ----
const mdFiles = [];
for (const [path, id] of Object.entries(DATA.paths)) {
  if (!path.endsWith('.md') || path.startsWith('instructor/')) continue;   // answer keys stay out of the crawlable text
  const src = join(courseRoot, path);
  if (!existsSync(src)) continue;
  const dst = join(pub, 'md', path);
  mkdirSync(dirname(dst), { recursive: true });
  copyFileSync(src, dst);
  mdFiles.push({ path, id });
}
const line = s => `- [${s.kind === 'module' ? 'Module ' + s.id.slice(1) + ': ' : ''}${s.title}](${origin}${href(s.id)}): ${s.description}`;
const groups = [...new Set(DATA.steps.map(s => s.group))];
const llms = [`# AI Security Engineering: Build, Break, Defend`, '',
  `> ${byId.welcome.description}`, '',
  `A free, self-paced course (MIT code, CC BY 4.0 text) on securing AI applications, agents and model lifecycles: 24 modules, an offline reference lab, four graded hands-on targets, milestone assessments, a capstone, a verified media library, and a handbook PDF. Every page below is also available as the original markdown under ${origin}/md/ (listed at the end), and the whole course as one file at ${origin}/llms-full.txt. The runnable parts (reference lab, targets, templates, tutor skill) download as https://github.com/vetri02/mcp-host-exercise/raw/main/ai-security-engineering-v1.5.zip; the same public repository holds one target on its own, the MCP host from Module 10, as a first exercise.`, '',
  ...groups.flatMap(g => [`## ${g}`, '', ...DATA.steps.filter(s => s.group === g).map(line), '']),
  '## Markdown sources', '', ...mdFiles.map(f => `- [${f.path}](${origin}/md/${f.path})`), ''].join('\n');
writeFileSync(join(pub, 'llms.txt'), llms);
const full = [`# AI Security Engineering: Build, Break, Defend`, '', `Source: ${origin}/ · Licence: MIT (code) and CC BY 4.0 (text) · Built ${today}`, '',
  ...DATA.steps.filter(s => s.md).map(s => `\n\n---\n\n<!-- ${origin}${href(s.id)} -->\n\n${s.md.trim()}`)].join('\n');
writeFileSync(join(pub, 'llms-full.txt'), full);
console.log(`prerendered ${count} pages, ${urls.length} sitemap entries, ${mdFiles.length} markdown sources, llms-full.txt ${(full.length / 1024) | 0} KB`);
