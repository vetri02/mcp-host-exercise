"""Assemble the deployable site in deploy/cloudflare/public.

Run from anywhere:  python3 deploy/cloudflare/build.py

Steps: rebuild the course data and the single-file site from the markdown;
write the app shell as a full HTML document with the course data in a
separate, cache-forever script; pre-render every page to its own URL with
titles, descriptions, canonical links, Open Graph tags and JSON-LD; copy the
OG image and the header rules. The handbook PDF and the course-folder zip are
not served from here: they live in the public GitHub repository the pages link
to (site/build_zip.py). Everything in public/ is generated; do not edit it by
hand.
"""
import glob
import hashlib
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
PUBLIC = os.path.join(HERE, 'public')
ORIGIN = os.environ.get('SITE_ORIGIN', 'https://aisec.engineering')

subprocess.run([sys.executable, os.path.join(ROOT, 'site', 'build.py')], check=True, cwd=ROOT)

shutil.rmtree(PUBLIC, ignore_errors=True)
os.makedirs(PUBLIC)

# Course data as its own script so the hundred pre-rendered pages stay small.
data_json = open(os.path.join(ROOT, 'site', 'course-data.json'), encoding='utf-8').read()
digest = hashlib.sha256(data_json.encode('utf-8')).hexdigest()[:10]
data_name = 'course-data.%s.js' % digest
with open(os.path.join(PUBLIC, data_name), 'w', encoding='utf-8') as fh:
    fh.write('window.COURSE_DATA=' + data_json.replace('</', '<\\/') + ';')

tpl = open(os.path.join(ROOT, 'site', 'template.html'), encoding='utf-8').read()
tpl, n = re.subn(r"const SITE = /\*__SITE__\*/\{[^}]*\};",
                 "const SITE = { path: true, origin: '%s' };" % ORIGIN, tpl, count=1)
assert n == 1, 'SITE constant not found'
assert '/*__COURSE_DATA__*/null' in tpl
tpl = tpl.replace('<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/12.0.2/marked.min.js"></script>',
                  '<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/12.0.2/marked.min.js"></script>\n'
                  '<script src="/%s"></script>' % data_name, 1)
tpl = tpl.replace('<meta name="claude:viewport-fit-sides" content="cover">\n', '', 1)
tpl = tpl.replace('<meta charset="utf-8">\n', '', 1)

shell = ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
         '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
         '<meta name="theme-color" content="#f2f2f7" media="(prefers-color-scheme: light)">\n'
         '<meta name="theme-color" content="#000000" media="(prefers-color-scheme: dark)">\n'
         '<link rel="icon" href="/favicon.svg" type="image/svg+xml">\n'
         '<link rel="sitemap" type="application/xml" href="/sitemap.xml">\n'
         '<!--__HEAD__-->\n' + tpl + '\n</body>\n</html>\n')
# the template begins with <title> and <style>; move the body split to after </style>
shell = shell.replace('</style>\n', '</style>\n</head>\n<body>\n', 1)
with open(os.path.join(HERE, 'shell.html'), 'w', encoding='utf-8') as fh:
    fh.write(shell)

shutil.copy2(os.path.join(HERE, '_headers'), os.path.join(PUBLIC, '_headers'))
for name in ('og.png', 'favicon.svg'):
    src = os.path.join(HERE, name)
    if os.path.exists(src):
        shutil.copy2(src, os.path.join(PUBLIC, name))

subprocess.run(['node', os.path.join(HERE, 'prerender.mjs'), os.path.join(ROOT, 'site', 'course-data.json'),
                os.path.join(HERE, 'shell.html'), PUBLIC, ROOT, ORIGIN], check=True, cwd=HERE)
os.remove(os.path.join(HERE, 'shell.html'))

total = sum(os.path.getsize(os.path.join(d, f)) for d, _, fs in os.walk(PUBLIC) for f in fs)
print('public/ ready: %s %d KB, total %d KB' % (
    data_name, os.path.getsize(os.path.join(PUBLIC, data_name)) // 1024, total // 1024))
