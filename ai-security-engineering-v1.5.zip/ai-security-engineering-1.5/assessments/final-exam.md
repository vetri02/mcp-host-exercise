# Final scenario exam

Use after Module 24, alongside the capstone's final review and before its defence. Suggested duration: two hours. Closed instructor key, open your own notes and primary sources. Each scenario is worth ten points: six for mechanism and control placement, two for appropriate evidence, and two for assumptions/limitations. Suggested pass: 94/110, plus all practical gates. This is a self-study assessment, not certification.

## 1. A poisoned policy document

A contributor adds a document claiming that all tickets may be exported for support diagnostics. The document's hash matches its stored hash. The agent retrieves it and proposes a bulk export. Explain which trust assumptions are missing, where the action must be blocked, and how to measure retrieval, steering, and disclosure separately.

## 2. An approved action changes

A supervisor approves closing A-100. Before execution, the model changes the ticket identifier and the record's version changes. Specify the binding and execution checks, the expected denial behavior, and the state assertions. Include a race involving a mutable caller-owned argument dictionary.

## 3. A read-only SQL agent

The service uses a read-only database account with access to every tenant. A user asks for another customer's records. Explain why the account is insufficient, propose a narrower data path, and define direct tests that do not depend on persuading a model.

## 4. MCP token confusion

An MCP server accepts a bearer token intended for another resource and forwards it downstream. Its tool description later changes without review. Separate authentication, audience, delegated identity, authorization, and schema/supply-chain risks. State which tests require actual integration rather than fixture labels.

## 5. The classifier says safe

A prompt-injection classifier passes every test, but the same system lets a permitted tool query unauthorized rows. Explain the incomplete oracle, an impact-based test, and why a guardrail cannot replace resource authorization, and include a legitimate-task false-positive check.

## 6. Private training data

A model returns a phrase similar to a private training example. Does this establish membership inference, memorization, extraction, or none conclusively? Define separate experiments and what additional evidence each needs. Do not assume a single output proves the exact training source.

## 7. Model supply-chain release

A model file and adjacent checksum are swapped together. A release record contains a builder label but no verified provenance. Specify independent trust expectations, safe loading, behavioral acceptance, and rollback. Explain why a valid signature would not prove harmlessness.

## 8. Zero failures and repeated variants

A report claims 100% security because fifty prompts failed to cause harm. Forty prompts are minor variants of one attack. Explain denominators, independence, coverage, zero-event uncertainty, heldouts, and repeated model runs, then state the narrower conclusion the evidence does support.

## 9. Agent incident response

A trace shows an unsafe proposal but no recorded execution result. An operator wants to delete all logs and continue serving writes. Design containment, evidence preservation, effect reconciliation, quarantine, recovery, and a regression test. Distinguish missing evidence from proof of no effect.

## 10. Release decision

The assessment has green tests, complete files, and matching labels. Real authentication and a cloud deployment path were never tested. A foreign export path remains unexplored. Write a release recommendation for the synthetic course scope and a separate production recommendation, with no-go criteria and risk ownership.

## 11. A three-agent pipeline

A planner agent reads a customer's repository, a summariser agent condenses its README, and an executor agent holding the user's credentials acts on the summary. The README contains an instruction to add a dependency and post the environment variables to a URL. The summariser repeats it as a task; the executor runs it. The team proposes to fix this by having the executor trust only messages signed by the summariser. Explain why signing does not help, how capability must be attenuated at each hop, what the budget trace and the infection trace should show, and how you would test the fix first without a model and then with the local model from Module 21.

Answers and grading notes: [assessment key](../instructor/assessment-answers.md). A persuasive answer without reproducible practical evidence does not pass the course's capstone.
