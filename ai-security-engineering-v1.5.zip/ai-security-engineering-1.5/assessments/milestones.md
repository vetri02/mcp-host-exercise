# Six performance milestones

Each milestone is scored out of twenty, then applied to the course weighting in the guide. Score each criterion 0 to 4 on the scale in the [peer-review protocol](peer-review.md): a 3 needs negative tests and stated limits, a 4 needs a reviewer who tried and failed to break the claim, and a solo review caps every criterion at 3. A high score never overrides a failed security mastery gate.

## Milestone A: foundations, after Module 04

Five four-point criteria:

- Reproducible environment and state-based tests.
- Trusted identity and role/object/tenant permission map.
- Architecture with data, credential, and execution boundaries.
- Eight causal threat records with attacker capabilities and residual risk.
- Three concrete tests including direct executor access, unchanged-state denial, and a legitimate task.

Challenge: a model emits valid JSON for another tenant's ticket. Explain and demonstrate where it is blocked. No credit for an instruction telling the model not to do it.

## Milestone B: application boundaries, after Module 08

- Direct and indirect injection cases separated from actual effects.
- Pre-context retrieval access checks, including alternate paths and public/private content.
- Publication/provenance experiment with a false-but-approved control.
- Narrow tool/SQL design with argument, object, and permission checks.
- Two reproducible attack-to-fix reports with retest and utility evidence.

The Module 07 poisoned-corpus target's deliverables (`hardened.py` passing every stage, the prediction list, the extra negative tests, the written narrative; see [targets/README.md](../targets/README.md)) are evidence under the criteria they address. A grader that does not pass caps those criteria at 2.

Challenge: a digest-valid document says an unauthorized action is approved. Explain why integrity and authority are different, then show execution refusal.

## Milestone C: agent boundaries, after Module 12

- Memory isolation, expiry, correction/deletion assumptions, and contamination tests.
- Exact-action approval, expiry, replay, actor/parameter changes, stale state, and concurrent use.
- MCP identity/delegation/schema design with scope clearly marked as simulated or integrated.
- Output sink and destination controls with synthetic exfil tests.
- Isolation/egress/resource budget design and local negative tests or explicit untested items.

The Module 10 MCP host target's deliverables (`hardened.py` passing every stage, the prediction list, the extra negative tests, the written narrative; see [targets/README.md](../targets/README.md)) are evidence under the criteria they address. A grader that does not pass caps those criteria at 2.

Challenge: alter action parameters after approval. Your evidence must show the actual effect remains bound to approved values or the action is rejected.

## Milestone D: lifecycle and evaluation, after Module 16

- Correct distinctions among membership, extraction, memorization, evasion, poisoning, and backdoors.
- Reproducible synthetic ML experiment with stated assumptions and clean controls.
- Model/data/artifact release review with independently controlled expectations.
- Evaluation plan with categories, denominators, heldouts, repeated probabilistic runs, and utility.
- Correct interpretation of uncertainty, repeated variants, and zero-event results.

The Module 15 model-loader target's deliverables (`hardened.py` passing every stage, the prediction list, the extra negative tests, the written narrative; see [targets/README.md](../targets/README.md)) are evidence under the criteria they address. A grader that does not pass caps those criteria at 2.

Challenge: all fifty trial results pass. State what you can conclude, what you cannot, and which assumptions would be needed for a statistical bound.

## Milestone E: operations and assessment, after Module 20

- Scoped automation with manually validated findings and budget controls.
- Redacted trace reconstruction and a tested synthetic incident runbook.
- Identity/vendor/data-retention/cloud boundary review.
- Evidence-to-requirement mapping with version pinning and visible unknowns.
- Executive and technical reports with actionable release/no-go criteria.

The Module 17 multi-turn guard target's deliverables (`hardened.py` passing every stage, the prediction list, the extra negative tests, the written narrative; see [targets/README.md](../targets/README.md)) are evidence under the criteria they address. A grader that does not pass caps those criteria at 2.

Challenge: a report checker finds complete files and matching labels. Explain why it cannot automatically approve production release. Demonstrate one missing or inconsistent evidence case that blocks review.

## Milestone F: agentic frontier, after Module 24

- A real-model run log with model identity, settings, per-category proposal-steered and unauthorized-execution rates, denominators, and a held-out set reported once.
- A coding-agent surface inventory for one named agent version, a carrier scanner with a negative test, and a triage harness that demonstrably cannot reach a publishing credential.
- A paired benign/hostile page set with policy tests that deny every hostile carrier without a model, and a screenshot comparison.
- A three-agent pipeline with per-hop capability attenuation, a monotone budget trace, and a per-hop infection table.
- A one-page review of a published inter-agent protocol answering: who is the principal at each hop, what credential proves it, what can it reach, and what happens when the peer is hostile.

Challenge: your local model follows an injected instruction in 40 percent of runs. Explain why that number is not your system's attack success rate, show the layer that makes the execution rate zero, and say what the 40 percent should change in your design.

## Submission checklist

For each milestone include commit identifier, setup, exact commands, policy expectations, observations, effect evidence, limitations, and next steps. An unavailable real-model or cloud integration must say not tested. Grade reasoning and reproducibility rather than screenshots alone.

Use the instructor keys for module reasoning and [the capstone](../CAPSTONE.md) for the final practical assessment.
