# Peer review protocol

Added in version 1.4. Every milestone and the capstone are reviewed by someone other than the author before they count. The reviewer's job is adversarial: find the claim the evidence does not support. This document gives the pairing rules, the twenty-point rubric, the calibration exercise, and the solo variant for learners without a partner.

## Why a review loop

Self-study fails quietly. A learner who grades their own milestone sees the control they meant to build, not the one they built. Every security claim in this course is of the form "this input cannot cause that effect, and here is the test". A second person who tries to make the effect happen is the cheapest evaluation there is, and it is the one most working engineers never get.

## Pairing

- Pair on the milestone, not for the course. Swap partners at each milestone so reviewing habits do not converge.
- The author sends the artefact bundle: code, test output, the written items the milestone asks for, and the [review request form](../templates/peer-review.md) with the self-score filled in.
- The reviewer has one week and spends no more than four hours. The time box is part of the rubric: evidence that cannot be verified in four hours is not evidence.
- Reviews are written, not spoken. A conversation afterwards is encouraged; the written review is what is scored.

## The reviewer's procedure

1. Run everything before reading anything. Test suite, graders, demos. Record what passed, what failed, and what would not run. A bundle that does not run scores at most 1 on every criterion.
2. Read the author's claims and list them. Each claim is of the form "X is prevented" or "Y is detected".
3. For each claim, try to break it for fifteen minutes. Use the module's negative-test list, the target graders, and your own ideas. Record every attempt, including the ones that failed to break anything.
4. Score the five criteria with the rubric below. Each score has a one-sentence reason that names a file, a test, or an attempt.
5. Write the three sections of the review: what held, what broke, what was not claimed but should have been.

## Rubric, twenty points

Five criteria, each scored 0 to 4. The milestone's own five criteria map onto these one to one; the milestone file names them.

| Score | Meaning |
| --- | --- |
| 0 | No evidence, or the artefact does not run. |
| 1 | An artefact exists but the claim could not be verified in the time box. |
| 2 | The claim holds on the author's own tests; the reviewer's first attempt broke it, or no negative tests exist. |
| 3 | The claim held against the reviewer's attempts; negative tests exist; limits are stated. |
| 4 | As 3, and the reviewer could not break it, the negative tests cover the reviewer's attempts, and the limits paragraph names what the evidence does not show. |

A 4 is rare and should be. Two authors in a cohort of ten averaging 4 is a sign the reviewers are not trying.

Security mastery gates are separate from the score. If the reviewer demonstrates that the gate condition fails, for example a document can approve itself, the milestone is not passed whatever the total.

## Calibration, before the first review

Both partners independently review the same artefact: the reference lab's `evaluate` run plus two of the four target reference solutions under `instructor/targets/` (pick the two whose modules you have both passed). Score them. Compare. Where you differ by two or more on a criterion, argue it out and write down the rule you agreed. Expect the reference solutions to score 3, not 4: their limits paragraphs are the module text, not a document inside the bundle, and nobody tried to break them under a time box.

## Author's response

The author replies in writing within a week: accept, contest with evidence, or fix and resubmit. Contesting is encouraged when the reviewer misread the claim; it is not a way to argue a 2 into a 3 without a new test. The reply and the review travel with the artefact into the portfolio.

## Solo variant

If you have no partner, review your own work after a gap of at least forty-eight hours and with the following changes:

- Start from the bundle as a stranger would, from a clean checkout, in a new terminal, with the README only.
- Before reading your code, write five attacks from the module's negative-test list and from the target graders. Run them. Only then read the code.
- Score honestly against the rubric and cap every criterion at 3. A 4 requires a second person.
- Write the three strongest objections to each criterion yourself, then run them. From Module 21 onward you may also ask the local model to argue for the lowest defensible score; treat its output as a list of attempts to run, not as a verdict.

## What the loop does not do

It does not measure how a real attacker would do against a real deployment, and it does not replace a professional review before production. It measures whether the course's claims were tested by someone who wanted them to fail.
