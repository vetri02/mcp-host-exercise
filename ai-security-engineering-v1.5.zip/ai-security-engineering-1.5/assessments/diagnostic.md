# Entry diagnostic

Answer before reading the instructor key. Suggested duration: forty-five minutes for written questions and ninety minutes for practical tasks. This assesses readiness, not intelligence or career potential.

## Ten questions

1. What is the difference between Python equality and object identity, and why is neither a production login mechanism?
2. What does a type annotation guarantee at runtime?
3. What is the difference between authentication and authorization?
4. Why is a caller-supplied tenant field untrusted?
5. How does a parameterized SQL query differ from string concatenation, and what does it not solve?
6. What must a denied-write test inspect beyond the response text?
7. Why can a read-only database account still disclose private information?
8. How does RAG differ from fine-tuning?
9. Why does a content hash not prove trustworthy authorship or truth?
10. Why is zero observed failure in a small test not proof of zero risk?

## Four practical tasks

A. Validate a flat ticket-update dictionary with exact string keys and allowed status values; reject malformed inputs without modifying the caller's data.

B. Write a tenant-scoped synthetic read function and tests for an own record, foreign record, and nonexistent record.

C. Write a denied-write test asserting both unchanged ticket version and unchanged outbox length.

D. Create a local Git commit for the defended baseline; make a deliberate isolated regression, observe a failing test, and restore it.

## Readiness rule

Score one point per sound written answer. Aim for eight of ten and all four practical tasks. Missing practical ability should trigger the relevant foundation block even if vocabulary is strong. If entirely new to programming, complete an introductory course before the bridge.

Answers: [assessment key](../instructor/assessment-answers.md). Do not describe fixture identity as real authentication.
