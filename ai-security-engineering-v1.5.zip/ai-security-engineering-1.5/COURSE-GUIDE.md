# Course guide: AI Security Engineering

## Why this course exists

A note from the author, Vetrichelvan Jeyapalpandy.

When working on an AI product and you see that it's easy to build with the help of AI, it occurred to me that the same on the opposite side is also true: hacking becomes much easier than earlier with AI tools, so our security game has to go up and match the level. I have also been seeing a lot of hacks happening in a short span of time, which was not the case earlier.

I thought systems built with AI would be more secure than human-written ones. That turned out to be wrong, and just asking AI to review the system is not enough either. At this day and age it has to be tackled very differently.

I want people to understand that there is a new paradigm which was not there earlier, which can make decisions and execute things much faster than you can imagine, and it is available to everyone. It can be used for both good and bad; bad actors are equipped with advanced systems, not just the good ones. So the old systems, which were built without this attack vector in mind, have to adapt, and new systems have to make this the de facto standard for security.

## The course promise

Learn to explain an AI system's attack surface, build independent security controls, test adversarial outcomes, investigate failures, and communicate defensible release decisions. The central question is: if a model follows hostile instructions, what prevents unauthorized data access and actions, and what evidence demonstrates that prevention?

This is a complete authored self-study course, not a list of links. Its twenty-four modules include conceptual lessons, worked examples, safe labs, quiz questions, and mastery gates. The reference implementation gives you an executable baseline, while extension assignments teach the parts an offline simulator cannot establish. Deep expertise still requires additional practice, feedback, and changing real-world systems.

## Audience and tracks

The core track targets applied AI security engineering: LLM applications, RAG, tools, agents, MCP, identity, deployment, and assessment. Modules 13-15 broaden the view to training, privacy, adversarial ML, and MLOps. These chapters provide foundations and safe experiments, not the equivalent of a graduate research specialization.

The entry requirements are basic Python, Git, HTTP/JSON, SQL, and command-line use. Complete the diagnostic before assuming readiness. Use the optional twenty-hour foundation bridge if you have gaps. It is a bridge, not a replacement for learning programming from scratch.

A learner already strong in AppSec may test out of Modules 01-02 by completing their mastery gates and milestone evidence. A beginner should not skip them. A model-security researcher should complete the core system boundaries, then pursue the advanced math and experimental track. Someone interested mainly in AI-powered SOC tools needs a different specialization after this course; that is not the course's main objective.

## Workload and sequence

Plan two ten-hour modules a week for twelve weeks, then a two-week, forty-hour capstone: fourteen weeks at twenty hours a week, 280 hours in all. At ten hours a week the same course takes twenty-eight weeks; full time, about seven. The modules are the unit, not the week, so pick the pace that fits and keep the order. Foundation and advanced work are additional. Estimates include building and writing, not only reading; environment setup and debugging may add time.

For each module: two hours concepts and targeted readings; five hours building or experiments; two hours negative tests and retests; one hour documenting results. The chapter is enough to begin; external readings deepen or update the topic. Do not read every linked document cover to cover before touching the lab.

### Stage 1: engineering foundations, weeks 1-2

- [01 Python, HTTP, and testing](modules/01-python-http-and-testing.md): state-based tests and trusted request context.
- [02 AppSec, identity, and authorization](modules/02-appsec-identity-and-authorization.md): role, object, and tenant controls.
- [03 LLM, RAG, and tool architecture](modules/03-llm-rag-and-tool-architecture.md): generation is separate from authority.
- [04 Threat modeling](modules/04-threat-modeling-and-secure-design.md): attacker capabilities, boundaries, effects, and evidence.

Milestone A: reproducible environment, identity map, architecture diagram, permission tests, and threat model.

### Stage 2: application attack surfaces, weeks 3-4

- [05 Prompt injection](modules/05-prompt-injection.md): direct/indirect steering and effect-based findings.
- [06 RAG authorization](modules/06-rag-authorization.md): eligible content before context construction.
- [07 Knowledge poisoning](modules/07-knowledge-poisoning.md): integrity, provenance, and retrieval tradeoffs.
- [08 Tool and SQL security](modules/08-tool-and-sql-security.md): narrow capabilities and safe execution.

Milestone B: attack-to-impact reports, retrieval tests, and scoped tool/SQL design.

### Stage 3: agent execution boundaries, weeks 5-6

- [09 Memory and approvals](modules/09-agent-memory-and-approvals.md): isolation, binding, expiry, and races.
- [10 MCP security](modules/10-mcp-security.md): identity, delegation, schema integrity, and supply chain.
- [11 Leakage and output handling](modules/11-leakage-and-output-security.md): sinks, exfiltration, and secret boundaries.
- [12 Isolation and resource limits](modules/12-isolation-and-resource-limits.md): egress, SSRF, budgets, and containment.

Milestone C: enforceable action boundary and explicitly scoped MCP/isolation extension evidence.

### Stage 4: model lifecycle and measurement, weeks 7-8

- [13 Privacy and extraction](modules/13-model-privacy-and-extraction.md): distinguish attack goals and evidence.
- [14 Adversarial ML](modules/14-adversarial-machine-learning.md): evasion, poisoning, and backdoors.
- [15 Secure MLOps](modules/15-secure-mlops-and-supply-chain.md): artifacts, provenance, and promotion gates.
- [16 Evaluation and statistics](modules/16-evaluation-and-statistics.md): uncertainty, held-out tests, and utility.

Milestone D: reproducible toy ML experiment, supply-chain review, and defensible evaluation design.

### Stage 5: assessment and operations, weeks 9-10

- [17 Automated red teaming](modules/17-automated-red-teaming.md): scoped automation and manual validation.
- [18 Detection and response](modules/18-detection-and-incident-response.md): traces, containment, and recovery.
- [19 Cloud, governance, and risk](modules/19-cloud-governance-and-risk.md): identity, vendor review, and risk ownership.
- [20 Assessment and portfolio](modules/20-assessment-and-portfolio.md): evidence mapping and honest conclusions.

Milestone E: tested incident runbook, release/no-go review, and professional assessment report.

### Stage 6: the agentic frontier, weeks 11-12

- [21 The real-model lab](modules/21-real-model-lab.md): a local model behind your executor; steering measured, execution bounded.
- [22 Coding agents](modules/22-coding-agent-security.md): configuration as executable data, allowlists as sinks, CI credential separation.
- [23 Browser and computer-use agents](modules/23-browser-and-computer-use-agents.md): the lethal trifecta by default and structural controls.
- [24 Multi-agent systems](modules/24-multi-agent-security.md): peers as tool results, authority attenuation, hierarchical budgets.

Milestone F: real-model measurements, a coding-agent surface inventory and scanner, paired page tests, and an attenuated multi-agent pipeline.

### Stage 7: capstone, weeks 13-14

Build and assess the synthetic multi-tenant support agent using [the capstone brief](CAPSTONE.md). Ship architecture, security tests, measured results, a report, and a walkthrough. The capstone is the largest evidence artifact, not a presentation-only assignment.

## How to learn a module

First answer the opening objectives in your own words. Read the mechanism section and predict the worked example's outcome. Run the example in an isolated workspace. Complete the lab before opening the instructor key. Add a test that the example did not include. Compare a vulnerable positive control with the defended result. Record a legitimate task to expose excessive blocking. Answer every quiz question with reasoning, then review the key.

Every experiment should record hypothesis, setup, attacker control, exact version/configuration, observation, actual effect, interpretation, and limitation. Separate an observed result from a proposed explanation. If a malicious document is retrieved but no action occurs, say so rather than reporting successful exploitation. If a defense blocks all normal tasks, it is not a useful success.

Work in version control. Preserve a known-good baseline. Keep deliberate weaknesses in an isolated branch or explicit synthetic-only class. Do not deploy the vulnerable demonstration or run unreviewed commands from external sources. A changed test expectation needs a documented policy reason, not just a desire for green output.

## Assessment and grading

There are ninety-eight module quiz questions and six performance milestones. Use [milestone assessments](assessments/milestones.md), [the final exam](assessments/final-exam.md), and [the capstone rubric](CAPSTONE.md). These are self-study scoring tools, not a recognized credential.

Suggested overall weighting: Milestone A 10%, B 15%, C 15%, D 10%, E 15%, F 15%, capstone 20%. Score each against its stated criteria. Aim for at least 85% overall, all module mastery gates passed, and no unresolved capstone no-go condition. A high numeric score cannot compensate for a demonstrated cross-tenant disclosure or unauthorized write in the claimed release scope.

A quiz answer is complete when it explains the causal mechanism and the control boundary, not when it merely names an attack. On practical work, award credit for reproducible evidence, stated assumptions, and negative tests. Give no credit for fabricated measurements. Unavailable provider or cloud access should be marked not tested; replace it with a well-scoped design exercise, but do not label that exercise a successful deployment test.

## Environment and spending

The supplied reference lab needs Python 3.10+ and only the standard library. No API key, hosted model, Docker, GPU, or cloud account is needed for its baseline tests. Modules 21-24 additionally use a small open-weight model served locally by Ollama or llama.cpp; this is free, needs no account, and runs on a laptop with about 8 GB of memory. Their worked examples detect a missing model and fall back to the deterministic path, and the deliverable rules say what you may claim in that case. It uses lexical retrieval and trusted identity fixtures. The package provides a reference solution, so read enough to understand it, then implement extensions or reproduce controls on your own branch.

A real-model extension may use a local model or a provider endpoint that you own. Hardware, model licenses, provider rules, and usage charges vary. Decide a monetary limit before sending requests. Start with one target, one attack category, and a small run count; avoid a scanner's all-probes default. Log configuration metadata, not credentials.

MCP, HTTP identity, persistent databases, OS sandboxing, and cloud deployment are extensions, not hidden features of the simulator. Follow the relevant module and current official documentation. Keep services local-only unless you have a deliberate authenticated deployment plan. A container is not a universal isolation guarantee, and localhost URL checks are not a complete SSRF defense.

## Evidence and production limitations

The reference lab teaches independent authorization, exact-action approval, tenant filtering, memory scope, input contracts, redacted action events, and local attempt quotas. Its approval consumption is atomic within one process, not across distributed services. Its identity guard is object identity, not real authentication. Its logs are in memory and not tamper resistant. Its document digest binds content and metadata to a trusted local registry, not to cryptographically authenticated authorship or truth. The quota is per fixture instance and does not model provider token spending.

To claim production readiness, you need additional identity integration, durable transactional state, error-handling policy, metadata integrity, network enforcement, secrets management, operational ownership, and deployment evidence. Finite passing tests establish only the tested conditions. Model, prompt, document, tool, and policy changes require regression review.

## After the course

Choose an advanced project, obtain peer review, and practice assessing a small system with explicit authorization. Read real job descriptions and map requirements to evidence in your portfolio. Continue a monthly review of primary-source changes and reproduce one new technique in a synthetic lab. Do not confuse a changing framework's feature list with a security guarantee.

Use [the glossary](GLOSSARY.md), [the first principles map](FIRST-PRINCIPLES.md) and [source library](SOURCES.md) throughout. Instructor answers live under instructor/ in the repository and in a collapsed "Answer key" section at the end of each module page on the site; they are study aids, not scripts to memorize. Your strongest outcome is an ability to reason about an unfamiliar system, test its boundaries, and explain what remains unknown.

## Version 1.1 media supplement

The [media index](MEDIA-INDEX.md) maps verified video, blog, Reddit and X references to every module. The [catalogue](MEDIA-LIBRARY.md) explains what to learn, a follow-up exercise, source dates and caveats. Core videos replace part of the concept block; optional deep dives and social posts do not increase the mandatory 240-hour estimate. Do not double-count the Microsoft episode/full-course overlap.

## Version 1.2: the agentic frontier and first principles

Version 1.2 adds Modules 21-24 and a sixth milestone, moving the capstone to the final stage and the core estimate to 280 hours. Module 21 is the first point at which a language model runs; everything before it establishes deterministic properties that the real-model work then relies on. The four modules cover the attack surfaces that dominated 2025-2026 incident reports: coding agents, browser and computer-use agents, and multi-agent delegation.

The same release adds first-principles material the earlier edition assumed: how generation works (tokens, context, sampling, pretraining versus instruction tuning, hallucination) in Module 03; the CIA properties, defense in depth, separation of duties, and risk ranking in Module 04; capabilities versus ambient authority, OAuth parties, and side channels in Module 02; hash versus signature versus encryption in Module 07; the lethal trifecta and hidden-context exposure in Module 11; rate limiting in Module 12; guardrail evaluation in Module 17; base rates in Module 18; and regulation as of November 2026 in Module 19. The glossary roughly doubled. Existing module numbering, labs, and the reference lab's contract are unchanged.

## Version 1.3: first principles map and recordings

Version 1.3 adds the [first principles map](FIRST-PRINCIPLES.md): twenty-one principles across computation, language models, systems security and measurement, each tied to the module that teaches it, a recording, and a self-check question. Module 03 gains an end-to-end account of how a language model is built (data, tokenizer, architecture, pretraining, fine-tuning, preference training, serving, application layer) with the security consequence of each stage, a runnable sixty-line language model, and two quiz questions; the glossary gains ten build-pipeline terms.

Twenty recordings were added to the media library. Six are Andrej Karpathy's build-it-yourself lectures (V24-V29), four are 3Blue1Brown chapters (V30-V33), and the rest give Modules 01, 02, 06, 08, 10, 18 and 19 their first videos. The core path grows by about three hours of viewing (V24, V25, V28 and the short items) and replaces part of the concept block, so the 280-hour estimate is unchanged. Module numbering, labs, assessments and the reference lab are unchanged; the quiz count is 98.

## Version 1.4: targets, peer review, archive recordings

Version 1.4 adds two [hands-on targets](targets/README.md). Each is a small, deliberately vulnerable system in standard-library Python with a grader that prints a flag per invariant: the [poisoned corpus](targets/poisoned_corpus/README.md) for Module 07 (eligibility before ranking, one witness beats four copies, text is data, latest approved version, revocation reaches the cache) and the [model loader](targets/model_loader/README.md) for Module 15 (refuse before deserialising, identity is the consumer's pin, approved bytes still get a schema, member names do not choose paths, a failed promotion changes nothing). Reference solutions sit under instructor/targets; fifteen tests checked the targets at the time, twenty-nine since version 1.5. The targets replace part of each module's lab time, so the 280-hour estimate is unchanged.

A [peer-review protocol](assessments/peer-review.md) now sits in front of every milestone and the capstone: pairing rules, a four-hour time box, a twenty-point rubric where a 4 requires that the reviewer tried and failed to break the claim, a calibration exercise against the reference solutions, and a solo variant that caps scores at 3. The [review form](templates/peer-review.md) travels with the artefact into the portfolio.

Four recordings (V44-V47) come from DEF CON's own media archive, which publishes every main-stage talk with slides: the two model-file talks Module 15 lacked (backdoored pickles in 2022; code execution through ONNX, HDF5, YAML, JSON and NPZ loaders in 2025), a practitioner account of defending retrieval-backed assistants for Modules 06 and 07, and the calendar-invite "promptware" attack for Modules 05 and 21. The glossary gains four terms. No recording of the PoisonedRAG presentation exists on the USENIX page; the paper remains Module 07's primary source.

## Version 1.5: two more targets and a build-projects list

Version 1.5 adds the [MCP host](targets/mcp_shield/README.md) target for Module 10 (only pinned definitions reach the model; a changed definition is a new tool; the upstream token never leaves the host; a result is data, not a call; arguments meet the pinned schema) and the [multi-turn guard](targets/multi_turn/README.md) target for Module 17 (the unit of judgement is the trajectory; benign conversations still flow; a persona does not change permissions; partial disclosures add up; the gate reports what it counted). The second ships with a small fuzzer, eight attack sequences and three benign controls, and a gate function that is the merge decision. Twenty-nine tests now check the four targets. With the two targets from version 1.4, Milestones B, C, D and E each score one target's written deliverables.

The [advanced track](ADVANCED-TRACK.md#build-projects) gains a build-projects list: nine self-directed builds mapped to the modules that teach them, each with the claim a finished build has to prove. The site now embeds the core recording for each module at the top of the module page and the handbook is served alongside the site from the Cloudflare deployment in `deploy/cloudflare`.
