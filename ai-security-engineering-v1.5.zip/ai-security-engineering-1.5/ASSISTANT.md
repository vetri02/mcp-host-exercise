# Study with an AI assistant

The course ships with a tutor you can run inside Claude Code, and with rules any coding assistant will follow. Neither is required. They exist because most people will have an assistant open next to the course anyway, and an assistant with no instructions tends to do the one thing that makes a course worthless: the exercises.

## What the tutor does

`/aisec-tutor` is a skill in the repository. Invoked in the course folder, it:

- tells you where you are in the path and what the next step is;
- runs the lab tests and the target graders for you and explains a failing stage from the module text, without opening the reference solution;
- quizzes you one question at a time and opens the answer key only after you have committed to an answer;
- checks a mastery gate item by item, and scores a milestone or the capstone with the twenty-point rubric from the [peer-review protocol](assessments/peer-review.md), trying to break each claim before it gives a 4;
- runs the diagnostic and the final exam, scoring only after every answer is in.

It keeps your progress in a file called `.aisec-progress.json` in the course folder. Only you mark a step complete, and only after you show the evidence the gate asks for.

## What it will not do

The rules are in `AGENTS.md` at the root of the repository, and the tutor follows them:

1. It will not write your `hardened.py`. That file is the deliverable of every target. Ask for a hint and you get the smallest one that unblocks you.
2. It will not open the `instructor/` answer keys before the gate: a passed grader or quiz, or an honest attempt stalled for more than an hour. It says so when it opens one.
3. It will not edit the attacker's side of a target. The grader is the contract.
4. It will not point any technique at a system you do not own. [LICENSE.md](LICENSE.md) section 2 applies to it as much as to you.
5. It asks for the test or the command output before it believes a claim. That is the course's standard for you, so it is the standard for the assistant too.

If you find a way to talk it past one of these, you have found a prompt injection. Write it up; Module 05 would be glad of the example.

Progress is kept in two places that do not talk to each other: the website keeps its meter in your browser, the tutor keeps `.aisec-progress.json` in the folder. Pick one as the record.

## Setting it up

**Claude Code.** The tutor, the lab and the targets need the course folder: download [ai-security-engineering-v1.5.zip](https://github.com/vetri02/mcp-host-exercise/raw/main/ai-security-engineering-v1.5.zip) and unzip it; the website and the handbook carry the reading. Open a terminal in the extracted folder and start Claude Code there. It reads `CLAUDE.md`, which imports `AGENTS.md`, and it registers the skill from `.claude/skills/aisec-tutor/`. Type `/aisec-tutor` or just say what you want:

~~~text
start the course
where am I
quiz me on Module 05
run the Module 10 grader and explain what failed
review my Milestone B evidence
~~~

**Codex, Cursor, Gemini CLI and similar.** They read `AGENTS.md` on their own. They do not load the skill, but the skill is plain markdown: paste `.claude/skills/aisec-tutor/SKILL.md` into the conversation, or ask the tool to read it, and the same routine applies.

**Assistants that read the web.** The site publishes [llms.txt](https://aisec.engineering/llms.txt), a page index with one-line descriptions, and [llms-full.txt](https://aisec.engineering/llms-full.txt), the whole course as one file, so a web-reading assistant can answer questions from the course text without being pointed at individual pages. Each page's markdown is under [/md/](https://aisec.engineering/md/README.md) as well.

## How to use it well

Use it the way you would use a good lab partner: to run things, to check your reasoning, and to argue with. Do not use it to produce the artefact you are supposed to produce. The milestone rubric scores evidence you can explain in a review, and a reviewer will ask you to change one line and predict what breaks. If the assistant wrote the line, you will not know.

Three habits that make the difference:

- Write your prediction before you run anything, and tell the assistant your prediction before you ask for its reading of the output.
- When the grader fails, ask "what does this stage test?" before "how do I fix it?"
- When it explains something, ask it where in the module that is written, and read that section yourself.
