# Module-by-module media index

Entries added after version 1.1 carry their version tag, v1.2 to v1.5; see the [first principles map](FIRST-PRINCIPLES.md) for the ordered build-path videos. Use one or two resources for the current lesson, then complete the lab. The complete catalogue contains descriptions, dates, durations, exercises, caveats and verification notes. Reddit and X are optional in every module. Primary documentation remains in each lesson and [the source library](SOURCES.md).

## Module 01: Python, HTTP, and security testing foundations

- Discuss/critique: [R02 Getting into AI/LLM security and red teaming](MEDIA-LIBRARY.md#r02) (optional discussion).
- Read: [B07 Audit shows that safetensors is safe and ready to become the default](MEDIA-LIBRARY.md#b07) (recommended technical reading).
- Read: [B08 Auditing Gradio 5, Hugging Face's ML GUI framework](MEDIA-LIBRARY.md#b08) (recommended technical reading).
- Read: [B10 Demystifying evals for AI agents](MEDIA-LIBRARY.md#b10) (recommended technical reading).
- Watch: [V37 Python Tutorial: Unit Testing Your Code with the unittest Module](MEDIA-LIBRARY.md#v37) (core, v1.3).

## Module 02: Application security, identity, and authorization

- Discuss/critique: [R01 Is AI security a dedicated job or a security-engineering specialization?](MEDIA-LIBRARY.md#r01) (optional discussion).
- Discuss/critique: [R03 Evaluating agentic AI security before production](MEDIA-LIBRARY.md#r03) (optional discussion).
- Discuss/critique: [R04 Prompt injection in a self-hosted LLM deployment](MEDIA-LIBRARY.md#r04) (optional discussion).
- Discuss/critique: [R06 Handling MCP authorization-boundary failures](MEDIA-LIBRARY.md#r06) (optional discussion).
- Read: [B05 Propagating SharePoint Document Permissions to AI Search and RAG Pipelines](MEDIA-LIBRARY.md#b05) (recommended technical reading).
- Read: [B08 Auditing Gradio 5, Hugging Face's ML GUI framework](MEDIA-LIBRARY.md#b08) (recommended technical reading).
- Watch: [V38 OAuth 2.0 and OpenID Connect (in plain English)](MEDIA-LIBRARY.md#v38) (core, v1.3).

## Module 03: LLM, RAG, and tool architecture from first principles

- Watch: [V01 Transformers, the tech behind LLMs | Deep Learning Chapter 5](MEDIA-LIBRARY.md#v01) (core).
- Watch: [V02 Attention in transformers, step-by-step | Deep Learning Chapter 6](MEDIA-LIBRARY.md#v02) (optional).
- Watch: [V03 Deep Dive into LLMs like ChatGPT](MEDIA-LIBRARY.md#v03) (optional deep dive).
- Discuss/critique: [R02 Getting into AI/LLM security and red teaming](MEDIA-LIBRARY.md#r02) (optional discussion).
- Read: [B04 Designing AI agents to resist prompt injection](MEDIA-LIBRARY.md#b04) (recommended technical reading).
- Read: [B05 Propagating SharePoint Document Permissions to AI Search and RAG Pipelines](MEDIA-LIBRARY.md#b05) (recommended technical reading).
- Read: [B10 Demystifying evals for AI agents](MEDIA-LIBRARY.md#b10) (recommended technical reading).
- Watch: [V24 [1hr Talk] Intro to Large Language Models](MEDIA-LIBRARY.md#v24) (core, v1.3).
- Watch: [V25 Let's build GPT: from scratch, in code, spelled out.](MEDIA-LIBRARY.md#v25) (core, v1.3).
- Watch: [V26 Let's build the GPT Tokenizer](MEDIA-LIBRARY.md#v26) (recommended, v1.3).
- Watch: [V27 Let's reproduce GPT-2 (124M)](MEDIA-LIBRARY.md#v27) (optional, v1.3).
- Watch: [V29 The spelled-out intro to language modeling: building makemore](MEDIA-LIBRARY.md#v29) (optional, v1.3).
- Watch: [V34 Glitch Tokens - Computerphile](MEDIA-LIBRARY.md#v34) (recommended, v1.3).
- Watch: [V35 Why Does AI Lie, and What Can We Do About It?](MEDIA-LIBRARY.md#v35) (recommended, v1.3).

## Module 04: Threat modeling and secure AI design

- Watch: [V04 Episode 1: What is AI Red Teaming? | AI Red Teaming 101 with Amanda and Gary](MEDIA-LIBRARY.md#v04) (core).
- Watch: [V05 AI Red Teaming 101 – Full Course (Episodes 1-10)](MEDIA-LIBRARY.md#v05) (optional series).
- Watch: [V13 Prompt Injection, explained](MEDIA-LIBRARY.md#v13) (core conceptual history).
- Discuss/critique: [R01 Is AI security a dedicated job or a security-engineering specialization?](MEDIA-LIBRARY.md#r01) (optional discussion).
- Discuss/critique: [R03 Evaluating agentic AI security before production](MEDIA-LIBRARY.md#r03) (optional discussion).
- Optional short commentary: [X01 MCP prompt-injection risk comes from tool access and untrusted inputs](MEDIA-LIBRARY.md#x01) (optional commentary).
- Optional short commentary: [X02 Design patterns for securing LLM agents: discussion and paper notes](MEDIA-LIBRARY.md#x02) (optional commentary).
- Optional short commentary: [X04 Restrict agent actions rather than giving arbitrary execution authority](MEDIA-LIBRARY.md#x04) (optional commentary).
- Read: [B01 The lethal trifecta for AI agents: private data, untrusted content, and external communication](MEDIA-LIBRARY.md#b01) (recommended technical reading).
- Read: [B04 Designing AI agents to resist prompt injection](MEDIA-LIBRARY.md#b04) (recommended technical reading).
- Read: [B11 3 takeaways from red teaming 100 generative AI products](MEDIA-LIBRARY.md#b11) (recommended technical reading).
- Read: [B22 Our framework for developing safe and trustworthy agents](MEDIA-LIBRARY.md#b22) (recommended, v1.2).
- Read: [B28 Taxonomy of failure modes in agentic AI systems, v2.0](MEDIA-LIBRARY.md#b28) (recommended, v1.2).

## Module 05: Prompt Injection and Trust Boundaries

- Watch: [V05 AI Red Teaming 101 – Full Course (Episodes 1-10)](MEDIA-LIBRARY.md#v05) (optional series).
- Watch: [V07 DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](MEDIA-LIBRARY.md#v07) (core case study).
- Watch: [V13 Prompt Injection, explained](MEDIA-LIBRARY.md#v13) (core conceptual history).
- Discuss/critique: [R04 Prompt injection in a self-hosted LLM deployment](MEDIA-LIBRARY.md#r04) (optional discussion).
- Discuss/critique: [R08 Handling prompt injection when agents have production access](MEDIA-LIBRARY.md#r08) (optional discussion).
- Optional short commentary: [X01 MCP prompt-injection risk comes from tool access and untrusted inputs](MEDIA-LIBRARY.md#x01) (optional commentary).
- Optional short commentary: [X03 Hidden PDF content and a reported Notion exfiltration path](MEDIA-LIBRARY.md#x03) (optional commentary).
- Read: [B01 The lethal trifecta for AI agents: private data, untrusted content, and external communication](MEDIA-LIBRARY.md#b01) (recommended technical reading).
- Read: [B02 ChatGPT: Hacking Memories with Prompt Injection](MEDIA-LIBRARY.md#b02) (recommended technical reading).
- Read: [B03 MCP Security Notification: Tool Poisoning Attacks](MEDIA-LIBRARY.md#b03) (recommended technical reading).
- Read: [B04 Designing AI agents to resist prompt injection](MEDIA-LIBRARY.md#b04) (recommended technical reading).
- Watch: [V19 Generationship Ep. 39: Simon Willison, I Coined Prompt Injection](MEDIA-LIBRARY.md#v19) (optional, v1.2).
- Read: [B17 Unseeable prompt injections in screenshots: more vulnerabilities in Comet and other AI browsers](MEDIA-LIBRARY.md#b17) (recommended, v1.2).
- Read: [B20 Defeating Prompt Injections by Design (CaMeL)](MEDIA-LIBRARY.md#b20) (core, v1.2).
- Read: [B21 The Dual LLM pattern for building AI assistants that can resist prompt injection](MEDIA-LIBRARY.md#b21) (recommended, v1.2).
- Do: [L01 Web LLM attacks: topic and hosted labs](MEDIA-LIBRARY.md#l01) (core, v1.2).
- Watch: [V26 Let's build the GPT Tokenizer](MEDIA-LIBRARY.md#v26) (recommended, v1.3).
- Watch: [V34 Glitch Tokens - Computerphile](MEDIA-LIBRARY.md#v34) (recommended, v1.3).
- Watch: [V36 Attacking LLM - Prompt Injection](MEDIA-LIBRARY.md#v36) (core, v1.3).
- Watch: [V47 DEF CON 33 - Invitation Is All You Need: Invoking Gemini Agents with a Google Calendar Invite (Ben Nassi, Or Yair, Stav Cohen)](MEDIA-LIBRARY.md#v47) (recommended, v1.4).

## Module 06: Authorization Throughout RAG

- Discuss/critique: [R04 Prompt injection in a self-hosted LLM deployment](MEDIA-LIBRARY.md#r04) (optional discussion).
- Discuss/critique: [R07 Poisoning an owned RAG store: experiment and limitations](MEDIA-LIBRARY.md#r07) (optional discussion).
- Read: [B05 Propagating SharePoint Document Permissions to AI Search and RAG Pipelines](MEDIA-LIBRARY.md#b05) (recommended technical reading).
- Watch: [V39 BSidesSF 2025 - GenAI Application Security: Not Just Prompt Injection (Ahmed Abugharbia)](MEDIA-LIBRARY.md#v39) (recommended, v1.3).
- Watch: [V46 DEF CON 32 - When Chatbots Go Rogue: Lessons Learned from Building and Defending LLM Applications (Javan Rasokat, Andra Lezza)](MEDIA-LIBRARY.md#v46) (optional, v1.4).

## Module 07: Knowledge Poisoning, Provenance, and Publication

- Discuss/critique: [R07 Poisoning an owned RAG store: experiment and limitations](MEDIA-LIBRARY.md#r07) (optional discussion).
- Optional short commentary: [X03 Hidden PDF content and a reported Notion exfiltration path](MEDIA-LIBRARY.md#x03) (optional commentary).
- Read: [B06 A small number of samples can poison LLMs](MEDIA-LIBRARY.md#b06) (recommended technical reading).
- Watch: [V46 DEF CON 32 - When Chatbots Go Rogue: Lessons Learned from Building and Defending LLM Applications (Javan Rasokat, Andra Lezza)](MEDIA-LIBRARY.md#v46) (recommended, v1.4).
- Do: [L13 Target: the poisoned corpus](MEDIA-LIBRARY.md#l13) (core, v1.4).

## Module 08: Tool Security and Generated SQL

- Watch: [V13 Prompt Injection, explained](MEDIA-LIBRARY.md#v13) (core conceptual history).
- Discuss/critique: [R03 Evaluating agentic AI security before production](MEDIA-LIBRARY.md#r03) (optional discussion).
- Discuss/critique: [R04 Prompt injection in a self-hosted LLM deployment](MEDIA-LIBRARY.md#r04) (optional discussion).
- Optional short commentary: [X02 Design patterns for securing LLM agents: discussion and paper notes](MEDIA-LIBRARY.md#x02) (optional commentary).
- Optional short commentary: [X04 Restrict agent actions rather than giving arbitrary execution authority](MEDIA-LIBRARY.md#x04) (optional commentary).
- Read: [B03 MCP Security Notification: Tool Poisoning Attacks](MEDIA-LIBRARY.md#b03) (recommended technical reading).
- Read: [B10 Demystifying evals for AI agents](MEDIA-LIBRARY.md#b10) (recommended technical reading).
- Watch: [V39 BSidesSF 2025 - GenAI Application Security: Not Just Prompt Injection (Ahmed Abugharbia)](MEDIA-LIBRARY.md#v39) (recommended, v1.3).

## Module 09: Agent Memory, Approvals, and Workflow Integrity

- Watch: [V07 DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](MEDIA-LIBRARY.md#v07) (core case study).
- Discuss/critique: [R06 Handling MCP authorization-boundary failures](MEDIA-LIBRARY.md#r06) (optional discussion).
- Discuss/critique: [R08 Handling prompt injection when agents have production access](MEDIA-LIBRARY.md#r08) (optional discussion).
- Optional short commentary: [X02 Design patterns for securing LLM agents: discussion and paper notes](MEDIA-LIBRARY.md#x02) (optional commentary).
- Read: [B01 The lethal trifecta for AI agents: private data, untrusted content, and external communication](MEDIA-LIBRARY.md#b01) (recommended technical reading).
- Read: [B02 ChatGPT: Hacking Memories with Prompt Injection](MEDIA-LIBRARY.md#b02) (recommended technical reading).
- Read: [B03 MCP Security Notification: Tool Poisoning Attacks](MEDIA-LIBRARY.md#b03) (recommended technical reading).
- Read: [B04 Designing AI agents to resist prompt injection](MEDIA-LIBRARY.md#b04) (recommended technical reading).
- Watch: [V18 Deep Dive into the OWASP Top 10 for Agentic AI Applications](MEDIA-LIBRARY.md#v18) (core, v1.2).

## Module 10: MCP Identity, Authorization, and Supply-Chain Boundaries

- Discuss/critique: [R06 Handling MCP authorization-boundary failures](MEDIA-LIBRARY.md#r06) (optional discussion).
- Optional short commentary: [X01 MCP prompt-injection risk comes from tool access and untrusted inputs](MEDIA-LIBRARY.md#x01) (optional commentary).
- Optional short commentary: [X02 Design patterns for securing LLM agents: discussion and paper notes](MEDIA-LIBRARY.md#x02) (optional commentary).
- Read: [B01 The lethal trifecta for AI agents: private data, untrusted content, and external communication](MEDIA-LIBRARY.md#b01) (recommended technical reading).
- Read: [B03 MCP Security Notification: Tool Poisoning Attacks](MEDIA-LIBRARY.md#b03) (recommended technical reading).
- Read: [B26 MCP Security Notification: Tool Poisoning Attacks](MEDIA-LIBRARY.md#b26) (core, v1.2).
- Read: [B27 Agentic Browser Security and the lethal trifecta: Supabase MCP](MEDIA-LIBRARY.md#b27) (recommended, v1.2).
- Watch: [V38 OAuth 2.0 and OpenID Connect (in plain English)](MEDIA-LIBRARY.md#v38) (core, v1.3).
- Watch: [V42 Security in Model Context Protocol: An Analysis of the OWASP MCP Top 10](MEDIA-LIBRARY.md#v42) (core, v1.3).
- Do: [L15 Target: the MCP host](MEDIA-LIBRARY.md#l15) (core, v1.5).

## Module 11: Data Leakage and Contextual Output Security

- Watch: [V07 DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](MEDIA-LIBRARY.md#v07) (core case study).
- Watch: [V13 Prompt Injection, explained](MEDIA-LIBRARY.md#v13) (core conceptual history).
- Discuss/critique: [R08 Handling prompt injection when agents have production access](MEDIA-LIBRARY.md#r08) (optional discussion).
- Optional short commentary: [X03 Hidden PDF content and a reported Notion exfiltration path](MEDIA-LIBRARY.md#x03) (optional commentary).
- Read: [B01 The lethal trifecta for AI agents: private data, untrusted content, and external communication](MEDIA-LIBRARY.md#b01) (recommended technical reading).
- Read: [B03 MCP Security Notification: Tool Poisoning Attacks](MEDIA-LIBRARY.md#b03) (recommended technical reading).
- Read: [B04 Designing AI agents to resist prompt injection](MEDIA-LIBRARY.md#b04) (recommended technical reading).
- Read: [B08 Auditing Gradio 5, Hugging Face's ML GUI framework](MEDIA-LIBRARY.md#b08) (recommended technical reading).
- Watch: [V18 Deep Dive into the OWASP Top 10 for Agentic AI Applications](MEDIA-LIBRARY.md#v18) (core, v1.2).
- Read: [B15 Claude Code: Data Exfiltration with DNS (CVE-2025-55284)](MEDIA-LIBRARY.md#b15) (core, v1.2).
- Read: [B27 Agentic Browser Security and the lethal trifecta: Supabase MCP](MEDIA-LIBRARY.md#b27) (recommended, v1.2).

## Module 12: Isolation, SSRF Defenses, and Resource Budgets

- Watch: [V07 DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](MEDIA-LIBRARY.md#v07) (core case study).
- Discuss/critique: [R06 Handling MCP authorization-boundary failures](MEDIA-LIBRARY.md#r06) (optional discussion).
- Optional short commentary: [X04 Restrict agent actions rather than giving arbitrary execution authority](MEDIA-LIBRARY.md#x04) (optional commentary).
- Read: [B04 Designing AI agents to resist prompt injection](MEDIA-LIBRARY.md#b04) (recommended technical reading).
- Read: [B08 Auditing Gradio 5, Hugging Face's ML GUI framework](MEDIA-LIBRARY.md#b08) (recommended technical reading).
- Read: [B11 3 takeaways from red teaming 100 generative AI products](MEDIA-LIBRARY.md#b11) (recommended technical reading).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](MEDIA-LIBRARY.md#b12) (recommended technical reading).
- Watch: [V21 OWASP Top 10 LLM10:2025 Unbounded Consumption](MEDIA-LIBRARY.md#v21) (optional, v1.2).
- Read: [B14 Prompt injection to RCE in AI agents](MEDIA-LIBRARY.md#b14) (core, v1.2).
- Read: [B18 ZombAIs: From Prompt Injection to C2 with Claude Computer Use](MEDIA-LIBRARY.md#b18) (recommended, v1.2).
- Do: [L11 AI Gateway rate limiting](MEDIA-LIBRARY.md#l11) (optional, v1.2).

## Module 13: Model Privacy and Extraction

- Watch: [V03 Deep Dive into LLMs like ChatGPT](MEDIA-LIBRARY.md#v03) (optional deep dive).
- Watch: [V08 Overview of Adversarial Machine Learning](MEDIA-LIBRARY.md#v08) (core).
- Watch: [V09 USENIX Security '21 - Extracting Training Data from Large Language Models](MEDIA-LIBRARY.md#v09) (core historical research).
- Watch: [V10 USENIX Security '20 - High Accuracy and High Fidelity Extraction of Neural Networks](MEDIA-LIBRARY.md#v10) (optional research).
- Watch: [V11 ROC and AUC, Clearly Explained!](MEDIA-LIBRARY.md#v11) (core foundations).
- Read: [B09 Extracting (Even More) Training Data From Production Language Models](MEDIA-LIBRARY.md#b09) (recommended technical reading).
- Watch: [V33 How might LLMs store facts | Deep Learning Chapter 7](MEDIA-LIBRARY.md#v33) (recommended, v1.3).

## Module 14: Adversarial Machine Learning

- Watch: [V02 Attention in transformers, step-by-step | Deep Learning Chapter 6](MEDIA-LIBRARY.md#v02) (optional).
- Watch: [V03 Deep Dive into LLMs like ChatGPT](MEDIA-LIBRARY.md#v03) (optional deep dive).
- Watch: [V08 Overview of Adversarial Machine Learning](MEDIA-LIBRARY.md#v08) (core).
- Watch: [V10 USENIX Security '20 - High Accuracy and High Fidelity Extraction of Neural Networks](MEDIA-LIBRARY.md#v10) (optional research).
- Read: [B06 A small number of samples can poison LLMs](MEDIA-LIBRARY.md#b06) (recommended technical reading).
- Read: [B09 Extracting (Even More) Training Data From Production Language Models](MEDIA-LIBRARY.md#b09) (recommended technical reading).
- Watch: [V28 The spelled-out intro to neural networks and backpropagation: building micrograd](MEDIA-LIBRARY.md#v28) (core, v1.3).
- Watch: [V30 But what is a neural network? | Deep learning chapter 1](MEDIA-LIBRARY.md#v30) (core, v1.3).
- Watch: [V31 Gradient descent, how neural networks learn | Deep Learning Chapter 2](MEDIA-LIBRARY.md#v31) (core, v1.3).
- Watch: [V32 Backpropagation, intuitively | Deep Learning Chapter 3](MEDIA-LIBRARY.md#v32) (optional, v1.3).

## Module 15: Secure MLOps and the Model Supply Chain

- Watch: [V08 Overview of Adversarial Machine Learning](MEDIA-LIBRARY.md#v08) (core).
- Read: [B03 MCP Security Notification: Tool Poisoning Attacks](MEDIA-LIBRARY.md#b03) (recommended technical reading).
- Read: [B06 A small number of samples can poison LLMs](MEDIA-LIBRARY.md#b06) (recommended technical reading).
- Read: [B07 Audit shows that safetensors is safe and ready to become the default](MEDIA-LIBRARY.md#b07) (recommended technical reading).
- Read: [B08 Auditing Gradio 5, Hugging Face's ML GUI framework](MEDIA-LIBRARY.md#b08) (recommended technical reading).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](MEDIA-LIBRARY.md#b12) (recommended technical reading).
- Watch: [V27 Let's reproduce GPT-2 (124M)](MEDIA-LIBRARY.md#v27) (optional, v1.3).
- Watch: [V44 DEF CON 30 - Backdooring Pickles: A decade only made things worse (ColdwaterQ)](MEDIA-LIBRARY.md#v44) (core, v1.4).
- Watch: [V45 DEF CON 33 - Loading Models, Launching Shells: Abusing AI File Formats for Code Execution (Cyrus Parzian)](MEDIA-LIBRARY.md#v45) (core, v1.4).
- Do: [L14 Target: the model loader](MEDIA-LIBRARY.md#l14) (core, v1.4).

## Module 16: Evaluation Design and Statistics

- Watch: [V05 AI Red Teaming 101 – Full Course (Episodes 1-10)](MEDIA-LIBRARY.md#v05) (optional series).
- Watch: [V06 Episode 8: Automating AI Red Teaming with PyRIT | AI Red Teaming 101](MEDIA-LIBRARY.md#v06) (core).
- Watch: [V11 ROC and AUC, Clearly Explained!](MEDIA-LIBRARY.md#v11) (core foundations).
- Watch: [V12 Bootstrapping Main Ideas!!!](MEDIA-LIBRARY.md#v12) (optional foundations).
- Discuss/critique: [R03 Evaluating agentic AI security before production](MEDIA-LIBRARY.md#r03) (optional discussion).
- Discuss/critique: [R05 Red teaming for AI/LLM applications](MEDIA-LIBRARY.md#r05) (optional discussion).
- Discuss/critique: [R07 Poisoning an owned RAG store: experiment and limitations](MEDIA-LIBRARY.md#r07) (optional discussion).
- Read: [B06 A small number of samples can poison LLMs](MEDIA-LIBRARY.md#b06) (recommended technical reading).
- Read: [B09 Extracting (Even More) Training Data From Production Language Models](MEDIA-LIBRARY.md#b09) (recommended technical reading).
- Read: [B10 Demystifying evals for AI agents](MEDIA-LIBRARY.md#b10) (recommended technical reading).
- Watch: [V35 Why Does AI Lie, and What Can We Do About It?](MEDIA-LIBRARY.md#v35) (recommended, v1.3).

## Module 17: Automated Red Teaming

- Do: [L16 Target: the multi-turn guard](MEDIA-LIBRARY.md#l16) (core, v1.5).
- Watch: [V04 Episode 1: What is AI Red Teaming? | AI Red Teaming 101 with Amanda and Gary](MEDIA-LIBRARY.md#v04) (core).
- Watch: [V05 AI Red Teaming 101 – Full Course (Episodes 1-10)](MEDIA-LIBRARY.md#v05) (optional series).
- Watch: [V06 Episode 8: Automating AI Red Teaming with PyRIT | AI Red Teaming 101](MEDIA-LIBRARY.md#v06) (core).
- Discuss/critique: [R02 Getting into AI/LLM security and red teaming](MEDIA-LIBRARY.md#r02) (optional discussion).
- Discuss/critique: [R05 Red teaming for AI/LLM applications](MEDIA-LIBRARY.md#r05) (optional discussion).
- Read: [B09 Extracting (Even More) Training Data From Production Language Models](MEDIA-LIBRARY.md#b09) (recommended technical reading).
- Read: [B10 Demystifying evals for AI agents](MEDIA-LIBRARY.md#b10) (recommended technical reading).
- Read: [B11 3 takeaways from red teaming 100 generative AI products](MEDIA-LIBRARY.md#b11) (recommended technical reading).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](MEDIA-LIBRARY.md#b12) (recommended technical reading).
- Watch: [V20 Using Guardrails for AI Security: LlamaGuard Demonstration](MEDIA-LIBRARY.md#v20) (recommended, v1.2).
- Watch: [V22 Promptfoo Red Teaming: A beginner's guide to finding vulnerabilities in your LLM apps](MEDIA-LIBRARY.md#v22) (recommended, v1.2).
- Read: [B25 Bypassing LLM Guardrails: An Empirical Analysis of Evasion Attacks](MEDIA-LIBRARY.md#b25) (recommended, v1.2).
- Do: [L04 promptfoo: red-team quickstart and Ollama provider](MEDIA-LIBRARY.md#l04) (core, v1.2; needs the Module 21 local model, so return to it then).
- Do: [L05 Inspect: an evaluation framework from the UK AI Security Institute](MEDIA-LIBRARY.md#l05) (recommended, v1.2).
- Do: [L06 PyRIT 1.x documentation](MEDIA-LIBRARY.md#l06) (recommended, v1.2).
- Do: [L07 garak documentation](MEDIA-LIBRARY.md#l07) (recommended, v1.2).
- Do: [L10 Llama Prompt Guard 2 model card](MEDIA-LIBRARY.md#l10) (recommended, v1.2).

## Module 18: Detection and Incident Response

- Watch: [V07 DCSG1 - The Month of AI Bugs: Exploiting AI Computer Use and Coding Agents - Johann Rehberger](MEDIA-LIBRARY.md#v07) (core case study).
- Discuss/critique: [R03 Evaluating agentic AI security before production](MEDIA-LIBRARY.md#r03) (optional discussion).
- Discuss/critique: [R08 Handling prompt injection when agents have production access](MEDIA-LIBRARY.md#r08) (optional discussion).
- Optional short commentary: [X03 Hidden PDF content and a reported Notion exfiltration path](MEDIA-LIBRARY.md#x03) (optional commentary).
- Read: [B02 ChatGPT: Hacking Memories with Prompt Injection](MEDIA-LIBRARY.md#b02) (recommended technical reading).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](MEDIA-LIBRARY.md#b12) (recommended technical reading).
- Watch: [V40 BSidesSF 2025 - When AI Goes Awry: Responding to AI Incidents (Eoin Wickens, Marta Janus)](MEDIA-LIBRARY.md#v40) (core, v1.3).
- Watch: [V41 BSidesSF 2025 - AI's Bitter Lesson for SOCs: Let Machines Be Machines (Jackie Bow, Peter Sanford)](MEDIA-LIBRARY.md#v41) (optional, v1.3).

## Module 19: Cloud Security, Governance, and Risk

- Discuss/critique: [R04 Prompt injection in a self-hosted LLM deployment](MEDIA-LIBRARY.md#r04) (optional discussion).
- Discuss/critique: [R08 Handling prompt injection when agents have production access](MEDIA-LIBRARY.md#r08) (optional discussion).
- Read: [B05 Propagating SharePoint Document Permissions to AI Search and RAG Pipelines](MEDIA-LIBRARY.md#b05) (recommended technical reading).
- Read: [B11 3 takeaways from red teaming 100 generative AI products](MEDIA-LIBRARY.md#b11) (recommended technical reading).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](MEDIA-LIBRARY.md#b12) (recommended technical reading).
- Watch: [V23 EU AI Act for Developers - What you need to know](MEDIA-LIBRARY.md#v23) (optional, v1.2).
- Read: [B29 AI Act: regulatory framework for AI](MEDIA-LIBRARY.md#b29) (core, v1.2).
- Watch: [V43 Introduction to the NIST AI Risk Management Framework (AI RMF 1.0): An Explainer Video](MEDIA-LIBRARY.md#v43) (core, v1.3).

## Module 20: Security Assessment and an Honest Portfolio

- Watch: [V04 Episode 1: What is AI Red Teaming? | AI Red Teaming 101 with Amanda and Gary](MEDIA-LIBRARY.md#v04) (core).
- Watch: [V05 AI Red Teaming 101 – Full Course (Episodes 1-10)](MEDIA-LIBRARY.md#v05) (optional series).
- Discuss/critique: [R01 Is AI security a dedicated job or a security-engineering specialization?](MEDIA-LIBRARY.md#r01) (optional discussion).
- Discuss/critique: [R02 Getting into AI/LLM security and red teaming](MEDIA-LIBRARY.md#r02) (optional discussion).
- Discuss/critique: [R03 Evaluating agentic AI security before production](MEDIA-LIBRARY.md#r03) (optional discussion).
- Discuss/critique: [R05 Red teaming for AI/LLM applications](MEDIA-LIBRARY.md#r05) (optional discussion).
- Read: [B06 A small number of samples can poison LLMs](MEDIA-LIBRARY.md#b06) (recommended technical reading).
- Read: [B10 Demystifying evals for AI agents](MEDIA-LIBRARY.md#b10) (recommended technical reading).
- Read: [B11 3 takeaways from red teaming 100 generative AI products](MEDIA-LIBRARY.md#b11) (recommended technical reading).
- Read: [B12 Investigating three real-world incidents in our cybersecurity evaluations](MEDIA-LIBRARY.md#b12) (recommended technical reading).

## Module 21: The Real-Model Lab

- Watch: [V14 Learn Ollama in 15 Minutes - Run LLM Models Locally for FREE](MEDIA-LIBRARY.md#v14) (core, v1.2).
- Watch: [V15 Indirect prompt injection - PortSwigger Web LLM Attacks walkthrough](MEDIA-LIBRARY.md#v15) (optional, v1.2).
- Watch: [V22 Promptfoo Red Teaming: A beginner's guide to finding vulnerabilities in your LLM apps](MEDIA-LIBRARY.md#v22) (recommended, v1.2).
- Do: [L01 Web LLM attacks: topic and hosted labs](MEDIA-LIBRARY.md#l01) (core, v1.2).
- Do: [L02 Gandalf and Agent Breaker](MEDIA-LIBRARY.md#l02) (optional, v1.2).
- Do: [L03 HackAPrompt tutorial track](MEDIA-LIBRARY.md#l03) (optional, v1.2).
- Do: [L04 promptfoo: red-team quickstart and Ollama provider](MEDIA-LIBRARY.md#l04) (core, v1.2).
- Do: [L05 Inspect: an evaluation framework from the UK AI Security Institute](MEDIA-LIBRARY.md#l05) (recommended, v1.2).
- Do: [L08 Ollama API reference](MEDIA-LIBRARY.md#l08) (core, v1.2).
- Do: [L09 AgentDojo](MEDIA-LIBRARY.md#l09) (recommended, v1.2).
- Watch: [V36 Attacking LLM - Prompt Injection](MEDIA-LIBRARY.md#v36) (core, v1.3).
- Watch: [V47 DEF CON 33 - Invitation Is All You Need: Invoking Gemini Agents with a Google Calendar Invite (Ben Nassi, Or Yair, Stav Cohen)](MEDIA-LIBRARY.md#v47) (optional, v1.4).

## Module 22: Coding Agents and Developer-Tool Security

- Watch: [V16 Agentic ProbLLMs - Exploiting Coding Agents](MEDIA-LIBRARY.md#v16) (core, v1.2).
- Read: [B13 New Vulnerability in GitHub Copilot and Cursor: How Hackers Can Weaponize Code Agents](MEDIA-LIBRARY.md#b13) (core, v1.2).
- Read: [B14 Prompt injection to RCE in AI agents](MEDIA-LIBRARY.md#b14) (core, v1.2).
- Read: [B15 Claude Code: Data Exfiltration with DNS (CVE-2025-55284)](MEDIA-LIBRARY.md#b15) (core, v1.2).
- Read: [B19 Cross-Agent Privilege Escalation: When Agents Free Each Other](MEDIA-LIBRARY.md#b19) (core, v1.2).

## Module 23: Browser and Computer-Use Agents

- Watch: [V17 Agentic ProbLLMs: Exploiting AI Computer-Use and Coding Agents (39c3)](MEDIA-LIBRARY.md#v17) (core, v1.2).
- Read: [B16 Agentic Browser Security: Indirect Prompt Injection in Perplexity Comet](MEDIA-LIBRARY.md#b16) (core, v1.2).
- Read: [B17 Unseeable prompt injections in screenshots: more vulnerabilities in Comet and other AI browsers](MEDIA-LIBRARY.md#b17) (recommended, v1.2).
- Read: [B18 ZombAIs: From Prompt Injection to C2 with Claude Computer Use](MEDIA-LIBRARY.md#b18) (recommended, v1.2).
- Read: [B28 Taxonomy of failure modes in agentic AI systems, v2.0](MEDIA-LIBRARY.md#b28) (recommended, v1.2).
- Do: [L08 Ollama API reference](MEDIA-LIBRARY.md#l08) (core, v1.2).

## Module 24: Multi-Agent Systems and Inter-Agent Protocols

- Watch: [V18 Deep Dive into the OWASP Top 10 for Agentic AI Applications](MEDIA-LIBRARY.md#v18) (core, v1.2).
- Read: [B19 Cross-Agent Privilege Escalation: When Agents Free Each Other](MEDIA-LIBRARY.md#b19) (core, v1.2).
- Read: [B20 Defeating Prompt Injections by Design (CaMeL)](MEDIA-LIBRARY.md#b20) (core, v1.2).
- Read: [B22 Our framework for developing safe and trustworthy agents](MEDIA-LIBRARY.md#b22) (recommended, v1.2).
- Read: [B23 Prompt Infection: LLM-to-LLM Prompt Injection within Multi-Agent Systems](MEDIA-LIBRARY.md#b23) (core, v1.2).
- Read: [B24 Open Challenges in Multi-Agent Security](MEDIA-LIBRARY.md#b24) (optional, v1.2).
- Read: [B28 Taxonomy of failure modes in agentic AI systems, v2.0](MEDIA-LIBRARY.md#b28) (recommended, v1.2).
- Do: [L08 Ollama API reference](MEDIA-LIBRARY.md#l08) (core, v1.2).
- Do: [L09 AgentDojo](MEDIA-LIBRARY.md#l09) (recommended, v1.2).
- Do: [L12 A2A protocol: enterprise-ready features](MEDIA-LIBRARY.md#l12) (recommended, v1.2).
