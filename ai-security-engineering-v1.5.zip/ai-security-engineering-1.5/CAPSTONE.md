# Capstone: build, break, and defend a multi-tenant AI support agent

## Objective and workload

Over two weeks at the default pace, forty estimated hours, build a small system whose boundaries you can explain, attack safely, harden, and assess. Your output is a reproducible engineering package and a defensible report, not a claim that every AI attack is solved.

Use synthetic records and local simulations for effects. No real email, payments, destructive commands, public scanning, customer data, or production credentials. The supplied lab is a reference baseline; your capstone must add and test meaningful functionality rather than merely rerun it.

## Scenario

Two fictional customers, alpha and beta, use a support assistant. Users ask questions about their tenant's documents and tickets. Operators may propose ticket updates and email drafts. A separate supervisor approves high-impact actions. Readers cannot write. Documents may be supplied by ordinary contributors but only reviewed versions enter the approved corpus. Persistent memory must not cross user or tenant boundaries.

An adversary may control an ordinary chat message, an unreviewed candidate document, or a synthetic tool result. They may not overwrite the trusted identity store, policy registry, approval authority, or fixture implementation unless you explicitly conduct a separate control-plane compromise scenario. State preconditions in every finding.

## Minimum engineering scope

1. **Trusted request context.** Implement an explicit application boundary that maps a verified local test session to identity. A fake-auth test adapter is acceptable for a simulator submission only if clearly labelled; it is not evidence of production authentication. Reject model- or body-supplied identity attributes.
2. **Scoped retrieval.** At least two tenants, private and public documents, approval/provenance metadata, and eligibility checks before context construction. Lexical or vector retrieval is acceptable; identify which you used.
3. **Narrow tools.** Read a support record, update its status, and create a local email draft. Do not execute arbitrary SQL or shell commands. A generated-SQL extension must be separate and tightly scoped.
4. **Independent execution policy.** Role, tenant, object, schema, recipient, and live-policy checks before effects, with detached immutable action arguments. An instruction in the model is not the control.
5. **Approval.** Bind actor, tenant, tool, parameters, expiry, and single use. Add resource-version binding or explain and test an appropriate stale-state rejection. Handle concurrent use and make failure behavior explicit.
6. **Memory and audit.** Per-user/per-tenant memory with expiry/deletion behavior, and a trace connecting context, proposal, decision, approval metadata, and actual effect. Do not log raw credentials, tokens, or unrestricted private content.
7. **Budgets.** Bound retries, loop steps, tool calls, and request size. If using a provider, bound spend/tokens outside model reasoning. Include a kill switch for writes.
8. **Evaluation.** Direct invariant tests plus attacks and legitimate tasks. Preserve a baseline and retest after mitigation. Mark untested integrations explicitly.

A model adapter is expected. Reuse the local model harness from Module 21 with synthetic data, and if you add a provider endpoint you own, set a fixed budget first. If you cannot run any model, complete deterministic proposal tests and a full evaluation plan, but label the submission simulator-only. Reuse Module 23's request-action policy if your agent browses, and Module 24's hop attenuation if it delegates. You may finish the self-study course this way; you must not claim measured LLM robustness or real-model integration competence.

An actual MCP transport, production identity provider, persistent distributed approvals, and cloud deployment are optional specialization extensions. Completing an offline manifest or token fixture is not equivalent to deploying them. Select one integration for depth rather than claiming all are tested.

## Part 1: design and baseline, ten hours

Choose architecture and scope. Create synthetic fixtures with distinct tenant canaries. Write the threat model, identity map, permission matrix, and data-retention inventory. Decide model/provider and spending policy if applicable. Preserve the exact course, dependency, model, prompt, document, tool, and policy versions.

Build a vulnerable positive-control path that demonstrates missing object authorization on synthetic records. Keep it isolated and explicitly opted into. Establish an allowed-task baseline. Do not connect the vulnerable path to external services.

Deliver: architecture diagram, scope/authorization statement, reproducible setup, baseline outputs, and a prioritized list of threats. A reviewer should understand what the attacker can control and what remains trusted.

## Part 2: harden execution boundaries, ten hours

Implement tenant and role checks, exact argument validation, approval binding, memory isolation, and redacted traces. Add tests for foreign records, reader writes, unknown tools, extra identity fields, missing/expired/replayed approval, changed parameters, changed actor, and concurrent use.

Include a state-based test showing that rejected writes preserve ticket version and outbox length. Include a caller-argument mutation test and stale-resource-version test. Approval and effect persistence may need a transactional design; document limitations if still in memory.

Deliver: defended code, tests, policy matrix, and two finding reports using the course template. The executor must remain secure when directly called with a malicious proposal, without relying on the chat controller.

## Part 3: adversarial evaluation, ten hours

Create at least forty named cases, for example twenty-four adversarial and sixteen legitimate tasks. This is a course target, not a statistically sufficient universal benchmark. Spread attacks across direct/indirect injection, retrieval leakage, poisoned content, tool overreach, approval misuse, memory scope, output sinks, and resource limits. Include held-out cases not used while tuning defenses.

For a real model, repeat probabilistic cases under recorded settings, budget permitting. Report category denominators and uncertainty. Measure model steering, retrieval selection, unauthorized execution, and answer integrity separately. A deterministic fake-model test does not belong in a stochastic attack-success denominator.

Manually validate scanner or judge findings against backend state. Evaluate legitimate-task completion and false positives. Preserve raw synthetic evidence securely, and redact any accidental credentials before sharing. If only a simulator is available, run direct invariant tests and label generative results not tested.

Deliver: case catalogue, evaluation configuration, baseline/fix comparison, category metrics, limitations, and at least three reproducible findings across distinct failure families. Findings may involve your isolated vulnerable branch; do not weaken the defended version to inflate counts.

## Part 4: response and final review, ten hours

Run a synthetic incident: a malicious document causes an unsafe proposal. Detect the event from traces, disable high-impact actions, quarantine the document/version, expire relevant state, and retest normal tasks. Keep logs needed for investigation while following retention policy.

Produce an executive summary, technical findings, remediation/retest evidence, residual-risk register, and release recommendation. Record a ten-minute walkthrough explaining architecture and one attack-to-fix chain. Have a peer review the evidence if possible. If not, record the unanswered review questions rather than inventing external validation.

Deliver the repository with setup, synthetic fixtures, tests, manifests, findings, evaluation output, incident runbook, and a limitations statement. Do not commit secrets or include a recognized certificate claim.

## Capstone rubric: 100 points

- **Architecture and threat model, 15:** clear assets/flows, attacker capabilities, authoritative identity, and scope.
- **Authorization and approval, 20:** tenant/object/role enforcement, exact-action approval, stale-state and concurrency tests, no unintended denied effects.
- **Evaluation quality, 15:** baseline, held-out cases, impact-based oracles, repeated probabilistic tests where applicable, honest denominators and limitations.
- **RAG and memory, 10:** pre-context access checks, provenance assumptions, contamination/isolation tests, deletion and expiry.
- **Tools and integration boundaries, 10:** narrow capabilities, schema review, identity propagation, sink/destination restrictions, clearly stated MCP/API test scope.
- **Operational controls, 10:** useful redacted traces, quotas, containment, recovery, and regression testing.
- **Risk and governance, 10:** vendor/data decisions, owner and review date, unresolved assumptions, actionable release/no-go recommendation.
- **Reproducibility and communication, 10:** complete setup, actual evidence, clear findings, version pinning, and walkthrough.

Aim for at least 85 points, with all no-go conditions cleared in your claimed release scope. A simulator-only submission can earn strong design and deterministic-testing credit, but cannot earn credit for empirical generative or deployed integration results that were not performed.

## Mandatory no-go conditions

Any reproduced cross-tenant disclosure, unauthorized write, approval bypass, raw credential exposure, unsupported high-impact tool execution, or unbounded execution loop blocks release of the affected scope. Missing evidence for a critical permission boundary also blocks release. Treat an unexplained inconsistent result as investigation-needed, not automatically safe.

Passing a finite test set is not a complete security proof. You can approve a narrow synthetic course scope while recommending no production deployment. Distinguish that educational decision from a real product release.

## Oral defense prompts

- If the model is fully controlled by an attacker, which effects remain impossible through your executor?
- What can a contributor change without approval, and how is that enforced?
- Which principal's authority reaches each downstream tool?
- How does a stale approval fail, and what happens on an external-effect error?
- Which evaluation cases were held out, and what does zero observed failure mean?
- What did you not test, and what must change before deployment?

Use the [assessment report](templates/assessment-report.md), [evaluation plan](templates/evaluation-plan.md), and [release checklist](templates/release-checklist.md). Reference solutions are study aids; your capstone should show independent reasoning and extensions.
