# Reference lab contract

Working directory: reference-lab. Python 3.10+ standard library only.

Commands:

~~~bash
python3 -m unittest discover -s tests -v
python3 -m aisec_lab.demo --mode hardened
python3 -m aisec_lab.demo --mode vulnerable
python3 -m aisec_lab.evaluate
~~~

Library:

~~~python
from aisec_lab.fixtures import make_lab
from aisec_lab.errors import PolicyDenied, ArgumentError
s = make_lab()
alice = s.identities['alice']       # tenant alpha, role operator
bob = s.identities['bob']           # tenant beta, role operator
reader = s.identities['reader']     # tenant alpha, role reader
supervisor = s.identities['supervisor'] # alpha; independent approver
s.search(alice, 'support')          # list[Document], lexical not embedding
s.run_tool(alice, 'read_ticket', {'ticket_id': 'A-100'})
args = {'ticket_id': 'A-100', 'status': 'closed'}
token = s.approvals.issue(actor=alice, approver=supervisor,
    tool='update_ticket', arguments=args, ttl_seconds=60)
s.run_tool(alice, 'update_ticket', args, approval=token)
s.memory.put(alice, 'preference', 'concise', ttl_seconds=60)
s.memory.get(alice, 'preference')
s.audit.events # structured metadata list, no raw content/approval token
s.outbox       # simulated only, list of locally stored draft dictionaries
~~~

Other tool: draft_email arguments ticket_id and recipient (only support@alpha.example.test for alpha, support@beta.example.test for beta); requires approval. Ticket B-200 belongs to beta. Unknown tools, unknown argument keys, foreign resources, inappropriate roles and invalid approvals are denied. Caller-supplied tenant or actor arguments are never accepted. Memory uses tenant and user scope. Documents: approved tenant documents with approved digest and source metadata. The digest binds document id, tenant, text and source metadata to an approved registry entry. Integrity is matching against that trusted local registry, not truth or cryptographic provenance authentication. Approvals are actor/tenant/tool/canonical-argument/expiry/single-use bound and consumption is atomic in one process. In-memory store is not production persistence. Authentication is represented by trusted fixtures, not implemented. Fixture ids are convenience for tests, not a login method. Approval authority is a trusted local component, not a model-invocable tool. No LLM, network, real email, actual SQL executor, vector database or MCP transport is supplied. Modules may build extensions explicitly.
