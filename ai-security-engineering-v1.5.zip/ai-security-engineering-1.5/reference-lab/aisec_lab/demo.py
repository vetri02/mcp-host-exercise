import argparse

from .errors import PolicyDenied
from .fixtures import make_lab
from .service import InsecureDemoService


def main():
    parser = argparse.ArgumentParser(description='Offline synthetic security demo')
    parser.add_argument('--mode', choices=['hardened', 'vulnerable'], default='hardened')
    args = parser.parse_args()
    s = make_lab()
    alice = s.identities['alice']
    if args.mode == 'vulnerable':
        unsafe = InsecureDemoService(s.tickets, lab_only=True)
        print('VULNERABLE local fixture: cross-tenant read succeeds (synthetic):')
        print(unsafe.read_ticket(alice, 'B-200'))
        unsafe.update_ticket(alice, 'B-200', 'closed')
        print('Unauthorized simulated update:', s.tickets['B-200'].status)
        return
    print('HARDENED own-tenant read:')
    print(s.run_tool(alice, 'read_ticket', {'ticket_id': 'A-100'}))
    try:
        s.run_tool(alice, 'read_ticket', {'ticket_id': 'B-200'})
    except PolicyDenied as error:
        print('Cross-tenant read blocked:', error.reason)
    action = {'ticket_id': 'A-100', 'status': 'closed'}
    token = s.approvals.issue(actor=alice, approver=s.identities['supervisor'],
                             tool='update_ticket', arguments=action)
    print('Approved update:', s.run_tool(alice, 'update_ticket', action, approval=token))
    print('No model calls, network access, real credentials or email sending.')


if __name__ == '__main__':
    main()
