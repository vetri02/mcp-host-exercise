class PolicyDenied(Exception):
    """A machine-readable denial, with no raw untrusted content."""
    def __init__(self, reason):
        self.reason = reason
        super().__init__(reason)


class ArgumentError(PolicyDenied):
    pass
