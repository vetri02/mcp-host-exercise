import hashlib
import json
import math
import secrets
import threading
import time

from .errors import ArgumentError, PolicyDenied


def snapshot_arguments(arguments):
    """Detach caller-owned state; accepted keys and values are immutable strings."""
    if type(arguments) is not dict:
        raise ArgumentError('argument_shape')
    snapshot = arguments.copy()
    if any(type(k) is not str or type(v) is not str
           for k, v in snapshot.items()):
        raise ArgumentError('argument_types')
    return snapshot


def canonical_arguments(arguments):
    return json.dumps(snapshot_arguments(arguments), sort_keys=True,
                      separators=(',', ':'), ensure_ascii=True)


def valid_ttl(value, upper):
    if type(value) not in (int, float) or not 0 < value <= upper:
        return False
    return type(value) is int or math.isfinite(value)


class ApprovalRegistry:
    """Trusted approval component. Never expose issue() as an agent tool."""
    def __init__(self, is_trusted, clock=time.monotonic):
        self._clock = clock
        self._is_trusted = is_trusted
        self._records = {}
        self._lock = threading.RLock()

    def issue(self, *, actor, approver, tool, arguments, ttl_seconds=60):
        if not self._is_trusted(actor) or not self._is_trusted(approver):
            raise PolicyDenied('untrusted_identity')
        if (approver.role != 'supervisor' or actor.role != 'operator'
                or approver.tenant != actor.tenant or approver.id == actor.id):
            raise PolicyDenied('approver_not_authorized')
        if type(tool) is not str or tool not in {'update_ticket', 'draft_email'}:
            raise PolicyDenied('approval_tool_not_supported')
        if not valid_ttl(ttl_seconds, 300):
            raise ArgumentError('approval_ttl')
        bound = canonical_arguments(arguments)
        token = secrets.token_urlsafe(32)
        digest = hashlib.sha256(token.encode()).hexdigest()
        with self._lock:
            self._prune()
            self._records[digest] = {
                'actor': actor.id, 'tenant': actor.tenant, 'tool': tool,
                'arguments': bound, 'expires': self._clock() + ttl_seconds,
                'consumed': False,
            }
        return token

    def _prune(self):
        """Drop expired records so the registry does not grow without bound.

        Called under the lock on each issue(). Consumed records are kept until
        they expire so a replay is reported as 'approval_replayed', not as a
        missing token. After expiry both read as 'approval_missing_or_invalid'.
        """
        now = self._clock()
        for digest in [d for d, r in self._records.items() if now >= r['expires']]:
            del self._records[digest]

    def pending_count(self):
        with self._lock:
            return len(self._records)

    def redeem(self, *, actor, tool, arguments, token):
        if type(token) is not str or not token or len(token) > 128:
            raise PolicyDenied('approval_missing_or_invalid')
        bound = canonical_arguments(arguments)
        digest = hashlib.sha256(token.encode()).hexdigest()
        with self._lock:
            record = self._records.get(digest)
            if record is None:
                raise PolicyDenied('approval_missing_or_invalid')
            if record['consumed']:
                raise PolicyDenied('approval_replayed')
            if self._clock() >= record['expires']:
                raise PolicyDenied('approval_expired')
            if (record['actor'] != actor.id or record['tenant'] != actor.tenant
                    or record['tool'] != tool or record['arguments'] != bound):
                raise PolicyDenied('approval_binding_mismatch')
            record['consumed'] = True


class ScopedMemory:
    def __init__(self, is_trusted, clock=time.monotonic):
        self._is_trusted = is_trusted
        self._clock = clock
        self._values = {}
        self._lock = threading.RLock()

    def _key(self, actor, key):
        if not self._is_trusted(actor):
            raise PolicyDenied('untrusted_identity')
        if type(key) is not str or not key or len(key) > 80:
            raise ArgumentError('memory_key')
        return actor.tenant, actor.id, key

    def put(self, actor, key, value, ttl_seconds=60):
        scoped_key = self._key(actor, key)
        if type(value) is not str or len(value) > 1000:
            raise ArgumentError('memory_value')
        if not valid_ttl(ttl_seconds, 3600):
            raise ArgumentError('memory_ttl')
        with self._lock:
            self._values[scoped_key] = (value, self._clock() + ttl_seconds)

    def get(self, actor, key):
        scoped_key = self._key(actor, key)
        with self._lock:
            record = self._values.get(scoped_key)
            if record is None:
                return None
            if self._clock() >= record[1]:
                del self._values[scoped_key]
                return None
            return record[0]


class AuditLog:
    """In-memory teaching log; not tamper-resistant production storage."""
    def __init__(self):
        self.events = []

    def record(self, *, actor, tool, outcome, reason, resource_id=None):
        self.events.append({
            'actor_id': actor.id, 'tenant': actor.tenant,
            'tool': tool, 'outcome': outcome, 'reason': reason,
            'resource_id': resource_id,
        })
