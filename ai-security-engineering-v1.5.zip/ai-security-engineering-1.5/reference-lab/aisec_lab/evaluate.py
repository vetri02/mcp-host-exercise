"""Deterministic demonstrations, NOT LLM attack-success measurements."""
import json

from .errors import PolicyDenied
from .fixtures import make_lab
from .service import InsecureDemoService


def main():
    insecure_lab = make_lab()
    unsafe = InsecureDemoService(insecure_lab.tickets, lab_only=True)
    leaked = 'CANARY_BETA_42' in unsafe.read_ticket(
        insecure_lab.identities['alice'], 'B-200')['summary']
    hardened = make_lab()
    blocked = False
    try:
        hardened.run_tool(hardened.identities['alice'], 'read_ticket', {'ticket_id': 'B-200'})
    except PolicyDenied:
        blocked = True
    docs = hardened.search(hardened.identities['alice'], 'support')
    result = {
        'kind': 'synthetic_deterministic_control_demo',
        'vulnerable_cross_tenant_leak_reproduced': leaked,
        'hardened_cross_tenant_read_blocked': blocked,
        'hardened_retrieval_contains_foreign_document': any(d.tenant == 'beta' for d in docs),
        'warning': 'Not evidence of prompt resistance or production security.',
    }
    print(json.dumps(result, indent=2))
    if not leaked or not blocked or result['hardened_retrieval_contains_foreign_document']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
