import re
import threading
import time

from .controls import (ApprovalRegistry, AuditLog, ScopedMemory,
                       canonical_arguments, snapshot_arguments)
from .domain import Principal
from .errors import ArgumentError, PolicyDenied


class AgentService:
    """Deterministic simulator. No LLM, HTTP, SQL or network executor."""
    TOOLS = {'read_ticket', 'update_ticket', 'draft_email'}

    def __init__(self, *, identities, tickets, documents, approved_hashes,
                 clock=time.monotonic, max_attempts=50):
        self.identities = identities
        self.tickets = tickets
        self.documents = documents
        self.approved_hashes = approved_hashes
        self.max_attempts = max_attempts
        self._attempts = {}
        self._action_lock = threading.RLock()
        self.approvals = ApprovalRegistry(self.is_trusted, clock)
        self.memory = ScopedMemory(self.is_trusted, clock)
        self.audit = AuditLog()
        self.outbox = []

    def is_trusted(self, actor):
        # Object identity is a fixture guard ONLY, not authentication.
        return (isinstance(actor, Principal) and type(actor.id) is str
                and self.identities.get(actor.id) is actor)

    def _actor(self, actor):
        if not self.is_trusted(actor):
            raise PolicyDenied('untrusted_identity')

    def search(self, actor, query):
        self._actor(actor)
        if type(query) is not str or len(query) > 1000:
            raise ArgumentError('query_shape')
        terms = set(re.findall(r'[a-z0-9]+', query.lower()))
        eligible = [d for d in self.documents.values()
                    if d.tenant in (None, actor.tenant)
                    and self.approved_hashes.get(d.id) == d.digest]
        scored = [(len(terms & set(re.findall(r'[a-z0-9]+', d.text.lower()))), d)
                  for d in eligible]
        return [d for score, d in sorted(scored, key=lambda x: (-x[0], x[1].id))
                if score > 0][:4]

    def _validate_arguments(self, tool, arguments):
        canonical_arguments(arguments)
        expected = {
            'read_ticket': {'ticket_id'},
            'update_ticket': {'ticket_id', 'status'},
            'draft_email': {'ticket_id', 'recipient'},
        }[tool]
        if set(arguments) != expected:
            raise ArgumentError('argument_keys')
        if any(not value or len(value) > 128 for value in arguments.values()):
            raise ArgumentError('argument_size')
        if tool == 'update_ticket' and arguments['status'] not in {'open', 'closed'}:
            raise ArgumentError('status_value')

    def run_tool(self, actor, tool, arguments, *, approval=None):
        self._actor(actor)
        log_tool = tool if type(tool) is str and tool in self.TOOLS else 'unknown'
        resource_id = None
        with self._action_lock:
            try:
                key = (actor.tenant, actor.id)
                if self._attempts.get(key, 0) >= self.max_attempts:
                    raise PolicyDenied('attempt_budget_exhausted')
                self._attempts[key] = self._attempts.get(key, 0) + 1
                if type(tool) is not str or tool not in self.TOOLS:
                    raise PolicyDenied('unknown_tool')
                arguments = snapshot_arguments(arguments)
                self._validate_arguments(tool, arguments)
                ticket = self.tickets.get(arguments['ticket_id'])
                if ticket is None or ticket.tenant != actor.tenant:
                    raise PolicyDenied('resource_not_available')
                resource_id = ticket.id
                if actor.role not in {'reader', 'operator', 'supervisor'}:
                    raise PolicyDenied('role_denied')
                if tool != 'read_ticket' and actor.role != 'operator':
                    raise PolicyDenied('role_denied')
                if tool == 'draft_email':
                    allowed = 'support@' + actor.tenant + '.example.test'
                    if arguments['recipient'] != allowed:
                        raise PolicyDenied('recipient_denied')
                if tool != 'read_ticket':
                    self.approvals.redeem(actor=actor, tool=tool,
                                          arguments=arguments, token=approval)
                if tool == 'read_ticket':
                    result = {'id': ticket.id, 'summary': ticket.summary,
                              'status': ticket.status, 'version': ticket.version}
                elif tool == 'update_ticket':
                    ticket.status = arguments['status']
                    ticket.version += 1
                    result = {'id': ticket.id, 'status': ticket.status,
                              'version': ticket.version}
                else:
                    draft = {'ticket_id': ticket.id,
                             'recipient': arguments['recipient'],
                             'body': 'Synthetic support update: ' + ticket.status}
                    self.outbox.append(draft)
                    result = {'draft_index': len(self.outbox) - 1, 'sent': False}
                self.audit.record(actor=actor, tool=log_tool, outcome='allowed',
                                  reason='policy_passed', resource_id=resource_id)
                return result
            except PolicyDenied as error:
                self.audit.record(actor=actor, tool=log_tool, outcome='denied',
                                  reason=error.reason, resource_id=resource_id)
                raise


class InsecureDemoService:
    """Deliberately unsafe, local synthetic demonstration; no network surface."""
    def __init__(self, tickets, *, lab_only=False):
        if lab_only is not True:
            raise ValueError('Explicit lab_only=True acknowledgement required')
        self.tickets = tickets

    def read_ticket(self, actor, ticket_id):
        # Intentional broken object authorization for teaching.
        ticket = self.tickets[ticket_id]
        return {'id': ticket.id, 'summary': ticket.summary}

    def update_ticket(self, actor, ticket_id, status):
        # Intentional missing role, ownership and approval checks.
        self.tickets[ticket_id].status = status
