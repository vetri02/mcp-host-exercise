"""Offline synthetic AI application security reference lab."""
__version__ = '1.2.0'
