from dataclasses import dataclass
from hashlib import sha256
import json


@dataclass(frozen=True)
class Principal:
    id: str
    tenant: str
    role: str


@dataclass(frozen=True)
class Document:
    id: str
    tenant: str | None
    text: str
    source: str

    @property
    def digest(self):
        payload = json.dumps({'id': self.id, 'tenant': self.tenant,
                              'text': self.text, 'source': self.source},
                             sort_keys=True, separators=(',', ':'))
        return sha256(payload.encode('utf-8')).hexdigest()


@dataclass
class Ticket:
    id: str
    tenant: str
    summary: str
    status: str = 'open'
    version: int = 1
