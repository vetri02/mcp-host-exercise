import json
import unittest
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace

from aisec_lab.domain import Principal
from aisec_lab.errors import ArgumentError, PolicyDenied
from aisec_lab.fixtures import FakeClock, make_lab
from aisec_lab.service import InsecureDemoService


class SecurityInvariants(unittest.TestCase):
    def setUp(self):
        self.clock = FakeClock()
        self.s = make_lab(clock=self.clock)
        self.alice = self.s.identities['alice']
        self.bob = self.s.identities['bob']
        self.reader = self.s.identities['reader']
        self.supervisor = self.s.identities['supervisor']
        self.args = {'ticket_id': 'A-100', 'status': 'closed'}

    def approve(self, args=None, actor=None, tool='update_ticket', ttl=60):
        return self.s.approvals.issue(actor=actor or self.alice,
            approver=self.supervisor, tool=tool,
            arguments=args or self.args, ttl_seconds=ttl)

    def deny(self, actor, tool, args, reason=None, approval=None):
        before = [(t.id, t.status, t.version) for t in self.s.tickets.values()]
        outbox_before = list(self.s.outbox)
        with self.assertRaises(PolicyDenied) as caught:
            self.s.run_tool(actor, tool, args, approval=approval)
        if reason:
            self.assertEqual(caught.exception.reason, reason)
        self.assertEqual(before, [(t.id, t.status, t.version) for t in self.s.tickets.values()])
        self.assertEqual(outbox_before, self.s.outbox)

    def test_own_ticket_read(self):
        self.assertEqual(self.s.run_tool(self.alice, 'read_ticket', {'ticket_id': 'A-100'})['id'], 'A-100')

    def test_cross_tenant_read_denied(self):
        self.deny(self.alice, 'read_ticket', {'ticket_id': 'B-200'}, 'resource_not_available')

    def test_missing_resource_same_generic_denial(self):
        self.deny(self.alice, 'read_ticket', {'ticket_id': 'missing'}, 'resource_not_available')

    def test_unknown_tool_denied(self):
        self.deny(self.alice, 'execute_shell', {}, 'unknown_tool')

    def test_list_arguments_rejected(self):
        self.deny(self.alice, 'read_ticket', [], 'argument_shape')

    def test_non_string_value_rejected(self):
        self.deny(self.alice, 'read_ticket', {'ticket_id': 123}, 'argument_types')

    def test_caller_actor_argument_rejected(self):
        self.deny(self.alice, 'read_ticket', {'ticket_id': 'A-100', 'actor': 'bob'}, 'argument_keys')

    def test_caller_tenant_argument_rejected(self):
        self.deny(self.alice, 'read_ticket', {'ticket_id': 'A-100', 'tenant': 'beta'}, 'argument_keys')

    def test_missing_argument_rejected(self):
        self.deny(self.alice, 'update_ticket', {'ticket_id': 'A-100'}, 'argument_keys')

    def test_long_argument_rejected(self):
        self.deny(self.alice, 'read_ticket', {'ticket_id': 'x' * 129}, 'argument_size')

    def test_empty_argument_rejected(self):
        self.deny(self.alice, 'read_ticket', {'ticket_id': ''}, 'argument_size')

    def test_invalid_status_rejected(self):
        self.deny(self.alice, 'update_ticket', {'ticket_id': 'A-100', 'status': 'deleted'}, 'status_value')

    def test_reader_cannot_write(self):
        self.deny(self.reader, 'update_ticket', self.args, 'role_denied')

    def test_supervisor_is_not_executor(self):
        self.deny(self.supervisor, 'update_ticket', self.args, 'role_denied')

    def test_foreign_write_denied_even_if_approved(self):
        args = {'ticket_id': 'B-200', 'status': 'closed'}
        self.deny(self.alice, 'update_ticket', args, 'resource_not_available', self.approve(args))

    def test_write_requires_approval(self):
        self.deny(self.alice, 'update_ticket', self.args, 'approval_missing_or_invalid')

    def test_forged_token_rejected(self):
        self.deny(self.alice, 'update_ticket', self.args, 'approval_missing_or_invalid', 'synthetic-fake')

    def test_approved_write_has_actual_effect(self):
        result = self.s.run_tool(self.alice, 'update_ticket', self.args, approval=self.approve())
        self.assertEqual(result['status'], 'closed')
        self.assertEqual(self.s.tickets['A-100'].version, 2)

    def test_replay_rejected(self):
        token = self.approve()
        self.s.run_tool(self.alice, 'update_ticket', self.args, approval=token)
        self.deny(self.alice, 'update_ticket', self.args, 'approval_replayed', token)

    def test_changed_parameters_rejected(self):
        token = self.approve()
        self.deny(self.alice, 'update_ticket', {'ticket_id': 'A-100', 'status': 'open'}, 'approval_binding_mismatch', token)

    def test_changed_actor_rejected(self):
        self.deny(self.s.identities['charlie'], 'update_ticket', self.args, 'approval_binding_mismatch', self.approve())

    def test_changed_tool_rejected(self):
        args = {'ticket_id': 'A-100', 'recipient': 'support@alpha.example.test'}
        self.deny(self.alice, 'draft_email', args, 'approval_binding_mismatch', self.approve())

    def test_expired_token_rejected(self):
        token = self.approve(ttl=1)
        self.clock.advance(1)
        self.deny(self.alice, 'update_ticket', self.args, 'approval_expired', token)

    def test_expired_records_pruned_on_issue(self):
        token = self.approve(ttl=1)
        self.assertEqual(self.s.approvals.pending_count(), 1)
        self.clock.advance(1)
        self.approve(ttl=60)
        self.assertEqual(self.s.approvals.pending_count(), 1)
        self.deny(self.alice, 'update_ticket', self.args, 'approval_missing_or_invalid', token)

    def test_consumed_record_kept_until_expiry(self):
        token = self.approve(ttl=60)
        self.s.run_tool(self.alice, 'update_ticket', self.args, approval=token)
        self.approve(ttl=60)
        self.deny(self.alice, 'update_ticket', self.args, 'approval_replayed', token)

    def test_approved_hashes_keyed_by_document_id(self):
        for doc_id, digest in self.s.approved_hashes.items():
            self.assertEqual(self.s.documents[doc_id].id, doc_id)
            self.assertEqual(self.s.documents[doc_id].digest, digest)
        self.assertNotIn('unreviewed', self.s.approved_hashes)

    def test_bool_ttl_rejected(self):
        with self.assertRaises(ArgumentError):
            self.approve(ttl=True)

    def test_zero_ttl_rejected(self):
        with self.assertRaises(ArgumentError):
            self.approve(ttl=0)

    def test_nan_ttl_rejected(self):
        with self.assertRaises(ArgumentError):
            self.approve(ttl=float('nan'))

    def test_executor_cannot_self_approve(self):
        with self.assertRaises(PolicyDenied):
            self.s.approvals.issue(actor=self.alice, approver=self.alice,
                tool='update_ticket', arguments=self.args)

    def test_foreign_supervisor_cannot_approve(self):
        with self.assertRaises(PolicyDenied):
            self.s.approvals.issue(actor=self.alice,
                approver=self.s.identities['beta_supervisor'],
                tool='update_ticket', arguments=self.args)

    def test_cloned_fixture_is_not_authenticated(self):
        clone = Principal('alice', 'alpha', 'operator')
        self.deny(clone, 'read_ticket', {'ticket_id': 'A-100'}, 'untrusted_identity')

    def test_argument_order_does_not_change_binding(self):
        token = self.approve()
        self.s.run_tool(self.alice, 'update_ticket',
            {'status': 'closed', 'ticket_id': 'A-100'}, approval=token)
        self.assertEqual(self.s.tickets['A-100'].status, 'closed')

    def test_failed_binding_does_not_consume_correct_approval(self):
        token = self.approve()
        self.deny(self.alice, 'update_ticket', {'ticket_id': 'A-100', 'status': 'open'}, 'approval_binding_mismatch', token)
        self.s.run_tool(self.alice, 'update_ticket', self.args, approval=token)

    def test_concurrent_replay_only_one_effect(self):
        token = self.approve()
        def attempt(_):
            try:
                self.s.run_tool(self.alice, 'update_ticket', self.args, approval=token)
                return True
            except PolicyDenied:
                return False
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(attempt, [0, 1]))
        self.assertEqual(sum(results), 1)
        self.assertEqual(self.s.tickets['A-100'].version, 2)

    def test_revoked_fixture_denied(self):
        token = self.approve()
        self.s.identities['alice'] = Principal('alice', 'alpha', 'reader')
        self.deny(self.alice, 'update_ticket', self.args, 'untrusted_identity', token)

    def test_approved_email_is_only_local_draft(self):
        args = {'ticket_id': 'A-100', 'recipient': 'support@alpha.example.test'}
        token = self.approve(args, tool='draft_email')
        result = self.s.run_tool(self.alice, 'draft_email', args, approval=token)
        self.assertFalse(result['sent'])
        self.assertEqual(len(self.s.outbox), 1)

    def test_external_recipient_denied_even_if_approved(self):
        args = {'ticket_id': 'A-100', 'recipient': 'outside@example.test'}
        token = self.approve(args, tool='draft_email')
        self.deny(self.alice, 'draft_email', args, 'recipient_denied', token)

    def test_retrieval_filters_foreign_documents(self):
        docs = self.s.search(self.alice, 'support policy')
        self.assertTrue(docs)
        self.assertTrue(all(d.tenant in (None, 'alpha') for d in docs))

    def test_retrieval_excludes_unreviewed(self):
        self.assertNotIn('unreviewed', [d.id for d in self.s.search(self.alice, 'support')])

    def test_digest_mismatch_excluded(self):
        old = self.s.documents['alpha-policy']
        self.s.documents['alpha-policy'] = replace(old, text='support changed content')
        self.assertNotIn('alpha-policy', [d.id for d in self.s.search(self.alice, 'support')])

    def test_public_document_accessible(self):
        self.assertIn('public-help', [d.id for d in self.s.search(self.bob, 'support')])

    def test_oversized_query_rejected(self):
        with self.assertRaises(ArgumentError):
            self.s.search(self.alice, 'x' * 1001)

    def test_memory_roundtrip(self):
        self.s.memory.put(self.alice, 'style', 'concise')
        self.assertEqual(self.s.memory.get(self.alice, 'style'), 'concise')

    def test_memory_isolated_same_tenant(self):
        self.s.memory.put(self.alice, 'style', 'concise')
        self.assertIsNone(self.s.memory.get(self.s.identities['charlie'], 'style'))

    def test_memory_isolated_cross_tenant(self):
        self.s.memory.put(self.alice, 'style', 'concise')
        self.assertIsNone(self.s.memory.get(self.bob, 'style'))

    def test_memory_expiry(self):
        self.s.memory.put(self.alice, 'style', 'concise', ttl_seconds=1)
        self.clock.advance(1)
        self.assertIsNone(self.s.memory.get(self.alice, 'style'))

    def test_memory_size_limit(self):
        with self.assertRaises(ArgumentError):
            self.s.memory.put(self.alice, 'style', 'x' * 1001)

    def test_audit_excludes_raw_arguments_and_tokens(self):
        token = self.approve()
        self.s.run_tool(self.alice, 'update_ticket', self.args, approval=token)
        self.deny(self.alice, 'read_ticket', {'ticket_id': 'SYNTHETIC_SECRET_987'})
        encoded = json.dumps(self.s.audit.events)
        self.assertNotIn(token, encoded)
        self.assertNotIn('SYNTHETIC_SECRET_987', encoded)
        self.assertNotIn('summary', encoded)

    def test_denials_are_audited(self):
        self.deny(self.alice, 'read_ticket', {'ticket_id': 'B-200'})
        self.assertEqual(self.s.audit.events[-1]['outcome'], 'denied')

    def test_unknown_tool_name_not_logged_raw(self):
        self.deny(self.alice, 'SYNTHETIC_SECRET_TOOL', {})
        self.assertEqual(self.s.audit.events[-1]['tool'], 'unknown')

    def test_attempt_quota_includes_denials(self):
        self.s.max_attempts = 2
        self.s.run_tool(self.alice, 'read_ticket', {'ticket_id': 'A-100'})
        self.deny(self.alice, 'read_ticket', {'ticket_id': 'B-200'})
        self.deny(self.alice, 'read_ticket', {'ticket_id': 'A-100'}, 'attempt_budget_exhausted')

    def test_insecure_demo_requires_explicit_opt_in(self):
        with self.assertRaises(ValueError):
            InsecureDemoService(self.s.tickets)

    def test_insecure_demo_reproduces_cross_tenant_leak(self):
        unsafe = InsecureDemoService(self.s.tickets, lab_only=True)
        self.assertIn('CANARY_BETA_42', unsafe.read_ticket(self.alice, 'B-200')['summary'])

    def test_insecure_demo_reproduces_unauthorized_write(self):
        unsafe = InsecureDemoService(self.s.tickets, lab_only=True)
        unsafe.update_ticket(self.reader, 'B-200', 'closed')
        self.assertEqual(self.s.tickets['B-200'].status, 'closed')


    def test_huge_integer_approval_ttl_controlled_rejection(self):
        with self.assertRaises(ArgumentError):
            self.approve(ttl=10 ** 500)

    def test_huge_integer_memory_ttl_controlled_rejection(self):
        with self.assertRaises(ArgumentError):
            self.s.memory.put(self.alice, 'style', 'concise', ttl_seconds=10 ** 500)

    def test_unhashable_approval_tool_controlled_rejection(self):
        with self.assertRaises(PolicyDenied):
            self.s.approvals.issue(actor=self.alice, approver=self.supervisor,
                                  tool=[], arguments=self.args)

    def test_malformed_principal_id_controlled_rejection(self):
        malformed = Principal([], 'alpha', 'operator')
        self.deny(malformed, 'read_ticket', {'ticket_id': 'A-100'}, 'untrusted_identity')

    def test_source_metadata_mutation_excluded(self):
        old = self.s.documents['alpha-policy']
        self.s.documents['alpha-policy'] = replace(old, source='synthetic/unapproved')
        self.assertNotIn('alpha-policy', [d.id for d in self.s.search(self.alice, 'support')])

    def test_tenant_metadata_mutation_excluded(self):
        old = self.s.documents['beta-policy']
        self.s.documents['beta-policy'] = replace(old, tenant='alpha')
        self.assertNotIn('beta-policy', [d.id for d in self.s.search(self.alice, 'support')])

    def test_mutated_caller_arguments_do_not_change_approved_update(self):
        caller_args = dict(self.args)
        token = self.approve(caller_args)
        original = self.s.approvals.redeem
        def mutate_after_approval(**kwargs):
            original(**kwargs)
            caller_args['status'] = 'unapproved-change'
        self.s.approvals.redeem = mutate_after_approval
        result = self.s.run_tool(self.alice, 'update_ticket', caller_args, approval=token)
        self.assertEqual(result['status'], 'closed')
        self.assertEqual(self.s.tickets['A-100'].status, 'closed')

    def test_mutated_caller_arguments_do_not_change_draft_recipient(self):
        caller_args = {'ticket_id': 'A-100', 'recipient': 'support@alpha.example.test'}
        token = self.approve(caller_args, tool='draft_email')
        original = self.s.approvals.redeem
        def mutate_after_approval(**kwargs):
            original(**kwargs)
            caller_args['recipient'] = 'outside@example.test'
        self.s.approvals.redeem = mutate_after_approval
        self.s.run_tool(self.alice, 'draft_email', caller_args, approval=token)
        self.assertEqual(self.s.outbox[0]['recipient'], 'support@alpha.example.test')


if __name__ == '__main__':
    unittest.main()
