"""Reference lab invariant tests."""
