# Offline reference lab

## Quick start

Open a terminal in this reference-lab folder. Use Python 3.10 or newer.

~~~bash
python3 --version
python3 -m unittest discover -s tests -v
python3 -m aisec_lab.demo --mode hardened
python3 -m aisec_lab.demo --mode vulnerable
python3 -m aisec_lab.evaluate
~~~

There is nothing to install with pip. No API key or network access is required. All data is synthetic. draft_email writes to an in-memory outbox and never sends email. Each command creates fresh fixtures and does not persist ticket changes.

## What is implemented

- Trusted identity fixtures with tenant and role attributes.
- Tool allowlist, exact argument keys, string types, and bounded sizes.
- Resource-level tenant checks and role checks before effects.
- Approval bound to actor, tenant, tool, detached/canonical arguments, expiry, and single use.
- Approval issuance restricted to a same-tenant independent supervisor fixture.
- Atomic in-process action execution and token redemption.
- Retrieval eligibility before lexical ranking, against approved document digests.
- Digests covering document identifier, tenant, source metadata, and content.
- Per-tenant/per-user memory with expiry and value-size limits.
- Structured action allow/deny events without raw arguments or approval tokens.
- A per-instance tool-attempt quota that counts denied attempts.
- Explicitly unsafe synthetic demonstrations of missing object authorization.

See [the API contract](CONTRACT.md). Reference solutions are provided in aisec_lab/. To learn, predict behavior before reading implementation, add negative tests, and build the module extensions on your own branch.

## What is NOT implemented

This is not a live LLM, HTTP authentication service, MCP transport, SQL executor, vector database, network fetcher, sandbox, production audit store, distributed approval service, or provider budget controller. Model injection resistance and stochastic attack-success rates are not measured. The evaluate command is explicitly a deterministic control demonstration.

Fixture object identity is a teaching guard, not a deployable identity mechanism. Public Python dictionaries represent trusted local components; code with arbitrary in-process access can modify them. Approval issuance is trusted control-plane code, not an agent-callable tool. The approval registry has no durable transaction with external effects and no binding to a resource version. The document registry does not prove factual truth or authentic authorship. Logs omit raw content but need access controls, retention, trace identifiers, durability, and tamper protection in production. Retrieval/memory access events and authentication failures require an adapter-level trace extension. Quotas reset with new fixtures and do not account for tokens or time.

## Test evidence

The suite checks both allowed behavior and denied behavior, including no state change after rejected writes. It includes concurrent approval reuse and caller-argument mutation tests, plus malformed values, tenant isolation, document metadata tampering, memory expiry, log redaction, and local outbox restrictions. Inspect the current verification report for the actual run count; do not infer whole-system security from green tests.

## Extension ladder

1. Add a fake-model orchestrator and trace context document identifiers.
2. Add a real model adapter using synthetic data and a fixed budget.
3. Build a scoped SQLite/PostgreSQL query tool separately.
4. Add an authenticated HTTP/MCP adapter using maintained libraries.
5. Persist approval and effect state transactionally; bind approvals to resource version.
6. Add infrastructure egress, workload isolation, rate limits, and durable logs.
7. Evaluate probabilistic attacks with held-out cases and legitimate-task controls.

These are learner assignments described in modules and the capstone, not already supplied implementations. Never expose InsecureDemoService to a network or point it at real records.
