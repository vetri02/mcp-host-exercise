# Primary-source library and version notes

Prepared on 3 November 2026. These links support the authored lessons; the course does not reproduce entire third-party publications or claim endorsement. Use the module's targeted reading instructions rather than reading every source before starting.

## Application and agent security

- [OWASP LLM Top 10 2026](https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026): risk awareness and coverage, not a complete verification procedure.
- [OWASP Agentic Applications Top 10 2026](https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026): autonomous system risks.
- [OWASP AI Agent Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html): tool scope, approval, memory, monitoring, and limits.
- [OWASP MCP Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/MCP_Security_Cheat_Sheet.html): protocol-adjacent tool, identity, and supply-chain risks.
- [MCP security best practices](https://modelcontextprotocol.io/specification/latest/basic/security_best_practices): select and retain the protocol version you actually implement.
- [PortSwigger LLM attack material](https://portswigger.net/web-security/llm-attacks): impact-oriented authorized practice. Academy labs may involve live models and vary across runs.
- [OWASP Authorization](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html), [Authentication](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html), and [OAuth2](https://cheatsheetseries.owasp.org/cheatsheets/OAuth2_Cheat_Sheet.html) cheat sheets.
- [RFC 9700](https://www.rfc-editor.org/rfc/rfc9700): OAuth 2.0 security best current practice.

## Model and lifecycle security

- [NIST adversarial ML taxonomy](https://www.nist.gov/publications/adversarial-machine-learning-taxonomy-and-terminology-attacks-and-mitigations-0): attack goals, attacker knowledge, and ML lifecycle framing.
- [MITRE ATLAS](https://atlas.mitre.org/): adversarial techniques, mitigations, and cases. It is a living knowledge base, not a course certificate.
- [OWASP Secure AI/ML Model Ops](https://cheatsheetseries.owasp.org/cheatsheets/Secure_AI_Model_Ops_Cheat_Sheet.html): development, artifact, serving, isolation, and operational guidance.
- [Hugging Face pickle security](https://huggingface.co/docs/hub/en/security-pickle): risks of untrusted deserialization; a scan does not prove artifact harmlessness.
- [PoisonedRAG](https://arxiv.org/abs/2402.07867): research on knowledge corruption through malicious retrieved texts. Published results depend on experimental conditions; the course does not generalize its numerical results to all deployments.
- [Microsoft lessons from red-teaming 100 products](https://arxiv.org/abs/2501.07238): system context, human testing, automation, and distinction from safety benchmarks.

## Evaluation and learning tools

- [Microsoft PyRIT](https://microsoft.github.io/PyRIT/latest): customizable automated/human-led assessment. The latest documentation can track development; pin a released version and its matching docs.
- [NVIDIA garak](https://github.com/NVIDIA/garak): probe-driven scanner. Current defaults may run all probes; explicitly select scope and budget. Hits need manual impact validation.
- [Hugging Face LLM course](https://huggingface.co/learn/llm-course/chapter1/1): optional model fundamentals; not a security course and expects good Python.
- [Python tutorial](https://docs.python.org/3/tutorial/), [unittest](https://docs.python.org/3/library/unittest.html), and [sqlite3](https://docs.python.org/3/library/sqlite3.html): foundation references.

## Verification and governance

- [OWASP AISVS project](https://owasp.org/www-project-artificial-intelligence-security-verification-standard-aisvs-docs) and [repository](https://github.com/OWASP/AISVS): testable AI security requirements. At the source check, the project page said version 1.0 stable while the repository described 1.01 stable. Preserve one specific released artifact and record the discrepancy; do not silently mix requirement versions. The course does not assert full conformity or unverified requirement IDs.
- [NIST AI RMF Playbook](https://www.nist.gov/itl/ai-risk-management-framework/nist-ai-rmf-playbook): voluntary Govern, Map, Measure, Manage guidance.
- [NIST Generative AI Profile](https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence): companion risk guidance. It is not legal advice or compliance certification.

## How to retain source evidence

Record URL, document title/version, retrieval date, artifact digest when relevant, and the requirement or claim used. A mutable latest page is not a pinned specification. Recheck commands and provider/API settings before running extensions. Follow official errata and release notes.

Reddit inspired the topic selection and practical emphasis, but individual comments are not technical authority, hiring-market statistics, or proof of a defense. The course's primary-source readings and local experiments are the learning foundation.

## Curated secondary formats, version 1.1

The course now includes 13 verified videos, 12 technical blogs/case studies, 8 Reddit discussions and 4 public X posts in [the media library](MEDIA-LIBRARY.md). These formats supplement the primary references. Publication age, vendor bias, anecdotal evidence and historical patch-status limits are explicitly labelled. Use [the module index](MEDIA-INDEX.md) for sequencing.

## Version 1.2 additions: agentic frontier and first principles

Checked 3 November 2026. These support Modules 21-24 and the 2025-2026 update sections in Modules 05, 09, 10, 11, 12, 17, and 19.

- [OWASP Top 10 for LLM Applications 2026](https://github.com/GenAI-Security-Project/GenAI-LLM-Top10): LLM06 unbounded consumption and LLM08 hidden context exposure are mapped in Modules 12 and 11. The 2025 edition numbered unbounded consumption LLM10; cite by edition.
- [OWASP Top 10 for Agentic Applications 2026](https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/): ASI05-ASI10 mapped across Modules 09, 11, 22, 24.
- [Debenedetti et al., CaMeL](https://arxiv.org/abs/2503.18813), [Beurer-Kellner et al., design patterns](https://arxiv.org/abs/2506.08837), [Wallace et al., instruction hierarchy](https://arxiv.org/abs/2404.13208), [Willison, dual LLM](https://simonwillison.net/2023/Apr/25/dual-llm-pattern/): architectural defenses, Module 05.
- [AgentDojo](https://github.com/ethz-spylab/agentdojo), [Ollama](https://github.com/ollama/ollama), [llama.cpp](https://github.com/ggml-org/llama.cpp): the local-model lab, Module 21. Runtimes change their command lines; record the version used.
- [Pillar: rules file backdoor](https://www.pillar.security/blog/new-vulnerability-in-github-copilot-and-cursor-how-hackers-can-weaponize-code-agents), [Embrace The Red: DNS exfiltration](https://embracethered.com/blog/posts/2025/claude-code-exfiltration-via-dns-requests/), [Trail of Bits: prompt injection to RCE](https://blog.trailofbits.com/2025/10/22/prompt-injection-to-rce-in-ai-agents/), [Check Point: project-file flaws](https://blog.checkpoint.com/research/check-point-researchers-expose-critical-claude-code-flaws/), [CSA: Clinejection](https://labs.cloudsecurityalliance.org/research/csa-research-note-clinejection-prompt-injection-cicd-cache-p/), [Schmotz et al., agent skills](https://arxiv.org/abs/2510.26328): Module 22. All describe fixed, historical issues; use them for mechanism, not current status.
- [Brave: Comet](https://brave.com/blog/comet-prompt-injection/) and [unseeable injections](https://brave.com/blog/unseeable-prompt-injections/), [Anthropic: Claude for Chrome](https://www.anthropic.com/news/claude-for-chrome), [OpenAI: understanding prompt injections](https://openai.com/index/prompt-injections/), [EchoLeak](https://arxiv.org/abs/2509.10540), [Microsoft taxonomy v2](https://www.microsoft.com/en-us/security/blog/?p=147942): Module 23. Brave competes with the products it tested; vendor figures are self-reported.
- [A2ABreak](https://arxiv.org/abs/2609.10871), [attacks on agent systems](https://arxiv.org/html/2610.12524), [Lee and Tiwari, prompt infection](https://arxiv.org/abs/2410.07283), [Schroeder de Witt et al., multi-agent security](https://arxiv.org/abs/2505.02077), [A2A enterprise features](https://a2a-protocol.org/latest/topics/enterprise-ready/), [Google's approach to secure agents](https://research.google/pubs/an-introduction-to-googles-approach-for-secure-ai-agents/): Module 24.
- [Invariant: tool poisoning](https://invariantlabs.ai/blog/mcp-security-notification-tool-poisoning-attacks) and [GitHub MCP](https://invariantlabs.ai/blog/mcp-github-vulnerability), [Willison: Supabase MCP](https://simonwillison.net/2025/Jul/06/supabase-mcp-lethal-trifecta/), [Embrace The Red: Gemini memory persistence](https://embracethered.com/blog/posts/2025/gemini-memory-persistence-prompt-injection/), [Willison: the lethal trifecta](https://simonwillison.net/2025/Jun/16/the-lethal-trifecta/): Modules 09-11.
- [Llama Prompt Guard 2 model card](https://huggingface.co/meta-llama/Llama-Prompt-Guard-2-86M), [Hackett et al., bypassing guardrails](https://arxiv.org/abs/2504.11168), [CAPTURE benchmark](https://arxiv.org/html/2505.12368v1): guardrail evaluation, Module 17. Model cards are gated downloads and report vendor-set numbers.
- [OWASP LLM10:2025 unbounded consumption](https://genai.owasp.org/llmrisk/llm102025-unbounded-consumption/), [Cloudflare AI Gateway rate limiting](https://developers.cloudflare.com/ai-gateway/features/rate-limiting/): Module 12.
- [European Commission AI Act page](https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai), [FLI implementation timeline](https://artificialintelligenceact.eu/implementation-timeline/), [NIST AI Agent Standards Initiative](https://www.nist.gov/caisi/ai-agent-standards-initiative), [NIST AI RMF 1.0](https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-ai-rmf-10), [ISO/IEC 42001 overview](https://learn.microsoft.com/en-us/compliance/regulatory/offering-iso-42001): Module 19. Not legal advice; dates were current at the check and the Omnibus shifted them once already.
- Tool status at the check: promptfoo 0.125.1, garak 0.17.1, PyRIT 1.1.0 (repository moved to microsoft/PyRIT; pre-1.0 commands in older videos no longer match), Inspect 0.3.287, Ollama and llama.cpp actively released. LLM Guard's repository was archived in July 2026 and is not recommended as a dependency.
